import { defineConfig } from "vite";
import { tanstackStart } from "@tanstack/react-start/plugin/vite";
import viteReact from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import { nitro } from "nitro/vite";

// Jellyfish runs on your own computer. The server only listens on this machine.
// NITRO_PRESET can pick another build target; the default is a plain Node server,
// which is also what the desktop app packages.
export default defineConfig(({ command, isPreview }) => ({
  server: { host: "127.0.0.1", port: 8080, strictPort: false },
  preview: { host: "127.0.0.1", port: 8081, strictPort: false },
  resolve: { tsconfigPaths: true },
  // Monaco's editor worker is a "?worker" import (see code-editor.tsx). Module
  // workers ("es") are the safe choice: the default "iife" format cannot be
  // used by a worker that is split into chunks or uses a dynamic import.
  worker: { format: "es" },
  plugins: [
    tailwindcss(),
    tanstackStart(),
    ...(command === "build" || isPreview ? [nitro({ preset: process.env.NITRO_PRESET || "node-server" })] : []),
    viteReact(),
  ],
}));
