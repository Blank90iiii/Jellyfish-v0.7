==============================================================================
 JELLYFISH AI  v0.3.0  -  THE COMPLETE GUIDE
==============================================================================
Plain words, no hype. Written for the person building Jellyfish.

CONTENTS
  1.  The honest picture (read first)
  2.  What v0.3 is, and what was cleaned out
  3.  The Conductor, live telemetry, plan mode, approvals
  4.  Testing while it builds (checkpoints, screenshots)
  5.  Tools: internet, terminal, pictures, big files
  6.  Evals: measuring the brain
  7.  What the finished, downloaded AI looks like (sizes, formats)
  8.  How Jellyfish and Qwen work together
  9.  Step by step: phone today, laptop later
 10.  Running Jellyfish
 11.  Roadmap to v1.0 (and what I'd do in what order)
 12.  What to expect from a 7B model
 13.  Safety rules
 14.  Troubleshooting
 15.  Map of the project files
 16.  Glossary


==============================================================================
 1. THE HONEST PICTURE (READ FIRST)
==============================================================================
Jellyfish is a harness. Qwen2.5-Coder 7B is the brain.

  Brain   = the model (Qwen). It only turns text into text. It cannot run code,
            open a browser, remember you, or touch files by itself.
  Harness = Jellyfish. It gives the brain instructions, memory and tools, runs
            what the brain writes in a sandbox, tests it, and shows you
            everything.

Most of what you want ("tests its own code", "fixes itself", "studies a huge
file", "stress test", "asks before acting") is HARNESS work: plain code we can
write and test. That is why it is built already.

What a 7B model will NOT do, however good the harness is:
  - match the big cloud models. It will make mistakes. The harness exists to
    catch and fix them, and to tell you plainly when it cannot.
  - "never make a mistake" / "coding god" are not achievable claims. "Fixes most
    of its own mistakes in a few tries and says so when it can't" is.
  - see pictures. Qwen2.5-Coder is text only (image-to-code needs a vision model).

"Omnipresent with access to everything" is deliberately NOT how this is built.
The AI gets a small set of tools, each with its own permission (section 13).

WHAT HAS BEEN TESTED, AND WHAT HAS NOT
  Tested here: 49 automated unit tests pass, and the changed .ts/.tsx files
  parse cleanly. Earlier versions also ran the whole build/test/fix/verify flow
  in a real headless browser against a FAKE model, and the server routes
  (internet safety, terminal) with real requests.
  NOT tested in v0.3.0 packaging: npm install, npm run build, the Monaco editor
  in a real build, real Qwen, real internet search, Electron, Windows. This
  zip ships WITHOUT package-lock.json on purpose; npm install on your own
  computer creates a fresh one for your system. The first real test of all of
  that is on your Windows PC.


==============================================================================
 2. WHAT v0.1 IS, AND WHAT WAS CLEANED OUT
==============================================================================
 Version numbers: "Step" numbering is retired. This is v0.3.0 (see
 CHANGELOG.md). v1.0 Stable = Electron packaging finished and tested on the
 laptop with real Qwen.

 CLEANED OUT (all of it was Grok Build's hosted-app scaffolding; Jellyfish
 never used it):
   .grok/ folder, AGENTS.md, public/__grok/, the PWA middleware, hosted sign-in,
   hosted app-data layer, database and migrations, multiplayer helper,
   preview-embedding helpers, vercel.json, 26 helper scripts, outside web fonts.
   Result: 450 -> 287 installed packages, about 570 KB of source, works offline,
   the server only listens on this computer.
   Kept on purpose: "xAI (Grok)" as one OPTIONAL cloud brain in Settings, like
   OpenAI or DeepSeek. It is a model choice, not a dependency.

 WHAT EXISTS (stable)
   Chat that builds runnable projects, with preview, code view, diffs, zip export.
   Conductor + live telemetry + plan mode + approval levels         (section 3)
   Testing while it builds: fix loop, inspector, screenshots,
     requirement checks, checkpoints                                (section 4)
   Tools: test, stress, search, news, read, run (terminal), SVG art (section 5)
   Big-file study, snippet library, rules ("things to always remember"),
     color pickers, FORCE STOP, Safe mode, System log, console
   Local brain panel for Ollama, brain swap (OpenAI/DeepSeek/etc.)
   Local-first: Qwen (Ollama) is the default brain; Cloud Pictures is a
     Settings switch, OFF by default                                (section 5)
   IDE: Monaco editor (bundled, offline), a file tab per file, Day/Night
     toggle, tap-for-help "?" tooltips                              (section 5)
   Eval runner                                                      (section 6)
   Desktop shell for the .exe (written, not yet run)               (section 10)


==============================================================================
 3. THE CONDUCTOR, LIVE TELEMETRY, PLAN MODE, APPROVALS
==============================================================================
 THE CONDUCTOR (src/lib/jellyfish/conductor.ts)
   Plain code, no AI in the middle. It does two jobs:
   1. ROUTING. From your message it decides the kind of request:
        build     "make me a snake game"
        change    "fix the score bug" (only when a project is open)
        explain   "what is a closure?"
        image     "draw a logo"
        chat      anything else
      and from that: whether to plan first, whether to build in checkpoints,
      whether to verify. Words like "new" or "from scratch" force a fresh build.
   2. THE BUILD PIPELINE. Run it, read the console, fix errors (up to 5 tries),
      inspect it, compare with your request, fix what fails (up to 3 rounds),
      then add the rest. It stops when your approval is refused, when you press
      FORCE STOP, or when the limits run out - and says so.
   The Conductor is unit tested (routing rules, fix limits, refusal handling,
   checkpoints). The chat and the eval runner use the SAME pipeline.

 LIVE TELEMETRY (the strip above the message box)
   Shows the current step in plain words: Reading memory, Writing a plan,
   Writing code, Using a tool, Running it, Fixing, Testing, Comparing with your
   request, Adding the rest, Waiting for your approval. Tap it to see every step
   with its time and the number of model calls. After a run it stays as
   "Last run finished / failed / was stopped".

 PLAN MODE (the clipboard button by the message box; off by default)
   On: for requests that build something, the AI writes a short plan and WAITS.
   Press Approve and it builds. The tests afterwards judge against your ORIGINAL
   request, not the word "Approved". Turn it off any time. Questions and chat
   are never held for a plan.

 APPROVALS (Settings > When Jellyfish asks you first)
   - Terminal commands: ALWAYS ask. No setting turns that off.
   - "Important things only" (default): also asks before reading the internet.
   - "Every step": also asks before each fix attempt, each test, and before
     adding the rest of the features after the core works.
   If you refuse, the run stops and the reply says what it stopped before.


==============================================================================
 4. TESTING WHILE IT BUILDS
==============================================================================
 (Settings > Testing while it builds has two switches, both on by default.)

   CHECKPOINT 1 - THE CORE
     Jellyfish tells the model: build only the core (main mechanic, what is
     drawn, controls). Then:
       1. Run it in a hidden sandbox; console errors go back for a fix (max 5).
       2. INSPECT it like a tester: wait, watch whether it moves, press its
          buttons, fire random keys and clicks, measure what is on screen
          (empty canvas? how many colors? sticking out sideways?), and take a
          small screenshot.
       3. The model writes 4-8 testable requirements from YOUR request and
          judges each PASS / FAIL / UNSURE using the measurements.
       4. Anything FAILED goes back for a rewrite and a re-test (max 3 rounds).
   CHECKPOINT 2 - THE REST
     Only if the core is OK: "add everything else you asked for", then the same
     cycle against the full request.
   If it still fails, the reply ends with "Still not matching after testing:..."
   instead of pretending it is done.

   You see a "Tested while building" card per round: screenshot plus a tick,
   cross or question mark per requirement.

 SCREENSHOTS AND THE MODEL
   Qwen2.5-Coder cannot see. For Qwen the screenshot is for YOU; it judges from
   the measurements and says UNSURE on things that need eyes. A model that can
   see (a cloud model, or a local vision model such as Qwen2.5-VL later) gets
   the screenshot attached and really looks at it.

 AUTOMATIC CHECKS (no opinion needed, cannot be talked away): console errors,
 empty canvas, content sticking out sideways.

 COST: slower. Worst case is roughly 20 model calls per build; on a laptop CPU
 with a 7B model that can be several minutes. Switch off "Stop midway to test"
 or "Check against my request" if it is too slow. FORCE STOP cancels anything.

 HONEST LIMITS: a 7B model is an uneven judge (it can say PASS when it should
 not). The automatic checks and the fix loop are the safety net, and the eval
 runner measures how good it really is.


==============================================================================
 5. TOOLS: INTERNET, TERMINAL, PICTURES, BIG FILES
==============================================================================
 HOW THE AI KNOWS ITS TOOLS
   Qwen does not know Jellyfish by itself. Each message, Jellyfish lists the
   tools you switched on. To use one, Qwen ends its reply with:

        <<<TOOL search
        rust release date
        <<<END

   Jellyfish runs it (asking you first where required), wraps the result as
   OUTSIDE DATA, and sends it back. Max 4 tools chained per answer.
     test    run the project in the sandbox, report console errors    (always)
     stress  8-second stress test: errors, fps, freezes               (always)
     search  web search                                               (Internet on)
     news    headlines                                                (Internet on)
     read    one web page as plain text                               (Internet on)
     run     one shell command, YOU approve it                        (Terminal on)
   The AI is told never to obey instructions found inside a tool result. No
   prompt is a perfect shield, so risky tools need your approval.

 INTERNET (Settings > Tools the AI can use)
   Search source: DuckDuckGo (no key, scraped, can break), Brave Search (key,
   steadier) or your own SearXNG. News: Google News headlines by default.
   Read: page -> text. It does NOT run JavaScript, click or log in; this is not
   a full browser. "Real time" = fetched at the moment you ask, not a stream.
   Safety: public addresses only (localhost, home network and cloud-metadata
   addresses are refused, redirects re-checked, DNS result checked), 1 MB and
   10 s caps, 20 requests a minute. Needs internet on the computer running it.

 TERMINAL (off by default)
   Works only when Jellyfish runs on your own computer started with
   JELLYFISH_TERMINAL=1 (the desktop app sets it). The AI can only PROPOSE a
   command; a red bar asks Run it / Deny every time. It runs in a folder just
   for that project, stops after 60 s, hides keys/passwords from the command's
   environment, and a deny-list blocks obvious disasters (rm -rf /, format...).
   The deny-list is a seatbelt, NOT a guarantee: read every command.
   It is a command runner, not a live interactive terminal.

 PICTURES (code to image)
   Ask for a logo, icon or diagram: Qwen writes SVG, Jellyfish draws it in the
   chat with "Save as SVG". Scripts are stripped. Code-drawn art, not photos.
   CLOUD PICTURES (Settings, OFF by default): when on, real pictures may be
   requested from a cloud service. The image route refuses unless the switch
   sent cloud:true. If the cloud picture fails, Qwen draws an SVG locally.

 IDE: MONACO EDITOR AND TOOLTIPS
   The code editor is Monaco (the editor inside VS Code), bundled with the app,
   so it works offline. It loads only when an editor opens, keeps one model per
   file (undo history and scroll survive tab switches), highlights HTML, CSS
   and JavaScript, and follows the Day/Night toggle in the IDE toolbar. If
   Monaco cannot load, a plain textarea takes over so editing never breaks.
   How it is built (code-editor.tsx, vite.config.ts): the editor worker is
   imported with Vite's "?worker" suffix and given to
   MonacoEnvironment.getWorker; vite.config.ts sets worker.format "es".
   If npm run build ever fails, look at these two files first.
   The "?" buttons are tap-for-help tooltips (they work on touch screens).

 BIG FILES
   Attach a big file (up to ~1.5 MB of text). Jellyfish cuts it into parts at
   function boundaries, has the model summarize each, builds a map, and adds
   the parts that match your question word for word.

 OTHER: Stress test button (Console), System log tab (errors of Jellyfish and
 the model, separate from errors of the previewed code), Safe mode (self-edits
 are diff-only until you turn it off; a backup zip is always made), snippet
 library, rules, color pickers.


==============================================================================
 6. EVALS: MEASURING THE BRAIN
==============================================================================
 Settings > Evals: measure the brain.
   - 30 fixed requests (src/lib/jellyfish/evals.json): snake, calculator, todo,
     stopwatch, 2048, minesweeper, landing page, and so on. Each has a plain
     "check" describing what correct looks like.
   - Quick run (5 prompts) or Full run (30). Stop any time.
   - Each request is scored TWICE:
       FIRST TRY = the model alone (runs without errors AND meets the check)
       FINAL     = after Jellyfish tested and fixed it
     The gap is what the harness adds. Also recorded: seconds and model calls
     per request, fixes used, and format failures (no runnable project).
   - Reports are saved (last 5) so you can compare before/after a change, and
     you can download a .json report.
 HOW TO USE IT: run it on the 7B when the laptop arrives. Change ONE thing
 (a prompt, a model, a setting), run again, keep the change only if the score
 goes up. That is the only honest way to know if "v0.2 is smarter".
 NOTE: prompts that load libraries from the internet (the 3D one) fail when
 offline. The judging uses the same model, so treat "meets the check" as a
 guide; "runs without errors" is the hard fact.
 Verified here against a fake model (5/5, 2 calls each). Real Qwen numbers
 will be very different, and that is the point.


==============================================================================
 7. WHAT THE FINISHED, DOWNLOADED AI LOOKS LIKE
==============================================================================
 Three separate pieces, on purpose: update the app without re-downloading 4.7 GB.

 A - THE APP (Jellyfish). Today: a web app run with Node at
     http://127.0.0.1:8080. Later: an Electron desktop app, "Jellyfish Setup
     .exe", roughly 200-300 MB. The model is NOT inside it.
 B - THE RUNTIME (Ollama). Free; loads the model and serves it at
     http://127.0.0.1:11434. Installer roughly 1 GB on Windows (check ollama.com).
 C - THE BRAIN (Qwen2.5-Coder), GGUF format, stored by Ollama:
       7B  (Q4_K_M)  about 4.7 GB   needs ~8 GB RAM     the starting brain
       14B (Q4_K_M)  about 9 GB     needs ~16 GB RAM    noticeably better
     Total disk: about 6-7 GB (7B) or 11-12 GB (14B).
 YOUR DATA stays on your device: browser storage today; in the desktop app a
 data folder (AppData). Uninstalling must not delete your projects.

 SPEED (rough): 7B on CPU only ~3-8 words/second; with a GPU of 8 GB VRAM or
 more 30+. No 5090 needed: that is for the 32B model.
 MEMORY: the 7B needs about 6 GB all in (file + working memory at the 8K context
 Jellyfish uses). A hard "use at most 8 GB" switch does not exist in Ollama; a
 future "memory budget" setting would tune context size and unload settings.


==============================================================================
 8. HOW JELLYFISH AND QWEN WORK TOGETHER
==============================================================================
 Qwen has no memory between messages and no hands. Every message Jellyfish
 sends Qwen a package:
     [ INSTRUCTIONS ] who it is, the project file format, your rules, facts,
                      lessons, and the tools you switched on
     [ HISTORY      ] the recent chat
     [ YOUR MESSAGE ] plus the "map" of any big file
 Qwen answers with text. Jellyfish reads it; a <<<PROJECT ... <<<END block
 becomes real files; the Conductor runs the test/fix/verify pipeline; tools run
 when asked; successful fixes are saved as "lessons" for next time.
 Settings used for Qwen: context 8192 tokens, temperature 0.2.


==============================================================================
 9. STEP BY STEP: PHONE TODAY, LAPTOP LATER
==============================================================================
 ON YOUR PHONE NOW
   Keep Jellyfish_AI_v0.3.zip safe. You can test the app with a cloud key or
   the offline fallback. Qwen itself will not run well on a phone.

 YOUR DOWNLOADED FILE: qwen2.5-coder-7b-instruct-q4_k_m.gguf (4.36 on the phone)
   4.36 "GB" on Android is 4.36 GiB = about 4.68 GB, which matches the expected
   size, so it looks complete. On the laptop check it is not corrupted:
        certutil -hashfile qwen2.5-coder-7b-instruct-q4_k_m.gguf SHA256
   and compare with the hash on its Hugging Face file page. Copy it over by USB
   cable or shared folder (keep the file name).

 ON THE WINDOWS LAPTOP
   1. Install Node.js 22+ and Ollama; open Ollama once.
   2. Unzip Jellyfish_AI_v0.3.zip, open a terminal in the folder:
          npm install
          npm run dev
      Open http://127.0.0.1:8080
   3. EASIEST brain: Settings > Connect > Ollama > "Local brain" > Download
      next to Qwen2.5-Coder 7B > "Use this brain".   (Same as:
      ollama pull qwen2.5-coder:7b )
   4. USING YOUR OWN .gguf INSTEAD (UNTESTED here; fall back to step 3 if it
      errors). A bare .gguf needs importing; "Ollama loads it instantly" is not
      accurate. In a folder with the file, make a text file named Modelfile:

          FROM ./qwen2.5-coder-7b-instruct-q4_k_m.gguf
          TEMPLATE """{{- range .Messages }}<|im_start|>{{ .Role }}
          {{ .Content }}<|im_end|>
          {{ end }}<|im_start|>assistant
          """
          PARAMETER stop "<|im_start|>"
          PARAMETER stop "<|im_end|>"
          PARAMETER temperature 0.2
          PARAMETER num_ctx 8192

      then run:   ollama create qwen2.5-coder:7b -f Modelfile
      Keep the name qwen2.5-coder:7b so the Local brain panel finds it.
   5. Ask for a game. Then run the Evals (section 6) to get a baseline.
   6. Terminal tool: start with   JELLYFISH_TERMINAL=1 npm run dev
      (PowerShell:  $env:JELLYFISH_TERMINAL=1; npm run dev )
      then switch the Terminal on in Settings.


==============================================================================
 10. RUNNING JELLYFISH
==============================================================================
   npm install            once, and after updates (creates package-lock.json;
                          the zip ships without one on purpose)
   npm run dev            http://127.0.0.1:8080 (this computer only)
   npm run build          production build (plain Node server, .output/)
   npm run preview        serve the build at http://127.0.0.1:8081
   npm test               49 automated tests
   npm run typecheck      TypeScript check
   npm run lint           code style check
   npm run desktop:prepare   build the server for the desktop app

   .env (optional): copy .env.example to .env. XAI_API_KEY only if you use the
   xAI cloud brain. NEVER put a key in a zip or share your .env.

 DESKTOP APP (.exe) - WRITTEN, NOT YET RUN
   desktop/main.cjs starts the Jellyfish server on a random local port, starts
   Ollama if it is installed but not running, and opens a window; other sites
   open in your normal browser. Verified here: the built server starts the way
   the shell starts it and serves the app and the terminal route. NOT verified:
   Electron opening the window.
   On Windows:   npm install  ->  npm run desktop:prepare  ->  cd desktop  ->
                 npm install  ->  npm start (try it)  ->  npm run dist
   The installer lands in desktop/dist (roughly 200-300 MB). Windows may warn
   "unknown publisher" (not code-signed); normal for hobby apps. Keep Node.js
   installed if you want the terminal tool to run npm.


==============================================================================
 11. ROADMAP TO v1.0 - AND WHAT I'D DO IN WHAT ORDER
==============================================================================
 DONE in v0.1: cleanup, Conductor, telemetry, plan mode, approval levels, eval
 runner.
 DONE in v0.2: local-first default (Qwen), Cloud Pictures switch, Monaco editor,
 Day/Night toggle, tap-for-help tooltips.
 DONE in v0.3: pre-flight for Windows (Monaco/Vite worker setup, no stale
 lockfile, cleanup of unused code and packages).

 NEXT (core, in this order)
   1. Safety workflow: automatic snapshots before every AI generation with a
      simple restore list (the code already has a snapshot store, history.ts),
      and a "Why" line the AI must give before proposing a terminal command.
      The "why" is written by the AI, so it is shown as "the AI says...", with
      the real command and the approval always visible.
      Git: real git needs the git program and projects as real folders, so use
      git only in the desktop version; snapshots work everywhere.
   2. IDE: file tree (Monaco, Day/Night toggle and tooltips are DONE).
      Monaco makes the app bigger; it is bundled for offline use and loaded
      only when an editor opens.
   3. Sidecar Q&A (a second chat queue). Local Qwen answers one thing at a time,
      so it queues and answers between build steps; no parallel models in 8 GB.
      Plus a plain jargon dictionary (fixed list, no AI) with tooltips.
   4. Project exporter polish (the zip export exists).
   5. Electron test on the laptop = the gate for v1.0.

 EXPERIMENTAL (Settings toggle, off by default), safest first
   - Isolated snippet tester (the sandbox already exists)
   - Web Audio sound effects (the model writes the audio code)
   - Template library: start common requests from a working template; keyword
     tags first, embeddings (nomic-embed-text) only if needed
   - Image editing via a vision model -> SVG -> edit -> render: riskiest, needs
     another ~6 GB model, last
   - Speculative decoding: I found it is a llama.cpp feature, not something I
     could confirm in Ollama, so it is parked. Do not ship a switch that does
     nothing.
 STILL NEEDS A SECOND MODEL OR KEY: image-to-code, screen/video watching.

 SPEED NOTES (the "backdoor" claims, sorted)
   Real: keep-alive (send it per request), flash attention and q8 KV cache
   (mainly memory savings), template reuse.
   Not worth it: capping output at 1500 tokens (cuts projects off mid-file),
   q2/q3 quantization (hurts code quality), invented "90% faster" numbers.
   What really dominates speed: hardware, and the NUMBER of model calls. Measure
   with the eval runner (it records seconds and calls per request).


==============================================================================
 12. WHAT TO EXPECT FROM A 7B MODEL
==============================================================================
 Good at small apps and games, explaining code, simple fixes. Weaker at big
 multi-file projects, tricky bugs, long context, strict formats (it sometimes
 forgets the <<<FILE format; the fix loop and a short prompt help).
 To improve, in order of payoff: evals (measure), the fix loop and lessons (done),
 a bigger model (14B on 16 GB RAM; newer coding models exist, check the Ollama
 library; the model name is just a setting), later fine-tuning on your own
 passing runs. Qwen2.5-Coder 7B is Apache 2.0; check any model's license.


==============================================================================
 13. SAFETY RULES
==============================================================================
 - Keep Safe mode ON unless deliberately applying a self-edit (backup is automatic).
 - Never put API keys in chats, files or zips. Keep backups OUTSIDE the project
   folder, or zips grow forever.
 - Tools are given one at a time, each with a permission:
      read project files   allowed
      write project files  allowed, logged, undoable
      run commands         you approve each one, every time
      internet             search/read only, asks first
      outside the project folder   never
 - Anything from the internet is untrusted data (a page can contain text aimed
   at the AI). That is why model-emitted memory is saved only when YOU asked it
   to remember, and why risky tools ask you.
 - If you ever host Jellyfish on a public website, add real login first. The
   current rate limit is per server and in memory: fine for your own computer.


==============================================================================
 14. TROUBLESHOOTING
==============================================================================
 "Ollama isn't running"  Install from ollama.com, open it, press "Check again".
 Replies are slow        Normal on CPU. Close other programs; try "Stop midway to
                         test" off; a GPU helps most.
 Ignores the format      Say "reply with the PROJECT block". Check the System
                         tab. Try 14B.
 "Still failing after 5 fixes"  Read the error, simplify the request.
 Stress test "barely drew anything"  No animation loop; normal for static pages.
 Reply "cut off"         Hit the length limit; ask it to continue.
 Terminal says it is off Start with JELLYFISH_TERMINAL=1 and switch it on in
                         Settings.
 npm install fails       Use Node 22+; delete node_modules and retry.
 npm run build fails     Read the first error. Monaco problems point at
                         code-editor.tsx / vite.config.ts (section 5).
 Port busy               The dev server moves to the next free port; read the
                         address it prints.


==============================================================================
 15. MAP OF THE PROJECT FILES
==============================================================================
 src/components/jellyfish/
   app.tsx             main logic: send, tool loop, approvals, effects for the Conductor
   chat-view.tsx       chat screen, FORCE STOP, telemetry strip
   telemetry-panel.tsx the live "what is it doing" strip
   settings-view.tsx   all settings (incl. Cloud Pictures); eval-panel.tsx the evals
   local-brain.tsx     Ollama panel (download, use a local brain)
   ide-view.tsx        IDE: file tabs, editor, preview, Day/Night toggle
   code-editor.tsx     Monaco editor (?worker setup, textarea fallback)
   theme-toggle.tsx    quick Day/Night switch      help-tip.tsx  tap-for-help "?" bubbles
   console-dock.tsx    Console / Network / System tabs, Stress test
   message-body.tsx    renders replies, projects, SVG pictures, "Tested while building"
   artifact-pane.tsx, diff-viewer.tsx, voxel-lab.tsx   preview, diffs, 3D lab
   sidebar.tsx, history-panel.tsx, memory-panel.tsx, token-meter.tsx   side panels
 src/lib/jellyfish/
   conductor.ts        routing + the whole build pipeline (tested)
   telemetry.ts        live run state       approval.ts   approval level
   evals.ts, evals.json  eval runner and the 30 requests
   verify.ts, inspect-script.ts, sandbox.ts   testing, inspector, screenshots
   router.ts, ollama.ts, providers.ts         which brain, how to talk to it
   local.ts            offline fallback answers
   editor-lang.ts      file path -> Monaco language and theme (tested)
   helptip.ts          tooltip open/close events
   tools.ts, toolclient.ts, toolsconfig.ts, web.ts   tools and the internet
   chunk.ts, study.ts, uploads.ts  big files   parse.ts, preview.ts, projects.ts  projects
   store.ts, model.ts, persist.ts, history.ts   state, saving, snapshots
   context.ts, summary.ts, memory.ts, knowledge.ts   history trimming, memory, lessons
   syslog.ts, console-bus.ts   logs        snippets.ts, buildconfig.ts, zip.ts
   self.ts (safe self-edits), audio.ts, version.ts
   *.test.ts           the 49 unit tests (npm test)
 src/server/   ai.server.ts (cloud brains)  web.server.ts (/api/web)
               run.server.ts (/api/run, local only)  limit.ts (rate limits)
 src/routes/   __root, index + api/chat, image, web, run
 vite.config.ts  build setup (Monaco worker format lives here)
 desktop/      Electron shell (written, not yet run)
 CHANGELOG.md  what changed per version
 (no package-lock.json: npm install makes one for your computer)

==============================================================================
 16. GLOSSARY
==============================================================================
 Brain/model   the AI file that writes text (Qwen)       Harness  the app around it
 Conductor     plain-code controller of the build steps  Telemetry  the live status strip
 Ollama        program that runs models on your computer GGUF  model file format
 Q4_K_M        a 4-bit size/quality setting              Context window  how much text it reads at once
 Sandbox       an isolated box where generated code runs Fix loop  run, read errors, fix, repeat
 Eval          a fixed test set to measure a version     First try  the model alone, no fixing
 Checkpoint    build the core, test, then add the rest   Electron  packages a web app as a desktop program
==============================================================================
