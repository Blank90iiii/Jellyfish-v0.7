export type Snippet = { id: string; name: string; code: string; at: number };

const KEY = "jellyfish.snippets";
const MAX = 100;

export function loadSnippets(): Snippet[] {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return [];
    const data = JSON.parse(raw) as unknown;
    if (!Array.isArray(data)) return [];
    return data
      .filter((item): item is Snippet => !!item && typeof item.id === "string" && typeof item.name === "string" && typeof item.code === "string")
      .slice(0, MAX);
  } catch {
    return [];
  }
}

function save(list: Snippet[]) {
  try {
    localStorage.setItem(KEY, JSON.stringify(list.slice(0, MAX)));
  } catch {
    /* storage full or blocked */
  }
}

export function addSnippet(list: Snippet[], name: string, code: string): Snippet[] {
  const cleanName = name.trim().slice(0, 60);
  const cleanCode = code.slice(0, 20_000);
  if (!cleanName || !cleanCode.trim()) return list;
  const next = [{ id: crypto.randomUUID(), name: cleanName, code: cleanCode, at: Date.now() }, ...list].slice(0, MAX);
  save(next);
  return next;
}

export function removeSnippet(list: Snippet[], id: string): Snippet[] {
  const next = list.filter((item) => item.id !== id);
  save(next);
  return next;
}
