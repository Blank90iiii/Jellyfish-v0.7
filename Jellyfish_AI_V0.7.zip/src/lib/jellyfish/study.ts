import type { Attachment } from "./model";
import { chunkText, relevantChunks } from "./chunk";

export const STUDY_THRESHOLD = 12_000;
const MAX_PARTS = 40;

type Ask = (prompt: string) => Promise<string>;

function plain(text: string) {
  return text.replace(/<thought>[\s\S]*?<\/thought>/gi, "").trim();
}

function partPrompt(name: string, index: number, total: number, startLine: number, endLine: number, body: string) {
  return `You are reading part ${index + 1} of ${total} of the file "${name}" (lines ${startLine}-${endLine}).
Write 3 to 6 short plain bullets: what this part does, the names of the functions, classes or exports in it, and anything that looks like a bug. No code blocks. No preamble.

${body}`;
}

/**
 * Turns attachments into text for the chat. Small files go in as they are.
 * Big files are cut into parts, each part is summarized, and the most relevant parts are added word for word.
 */
export async function packAttachments(
  files: Attachment[],
  question: string,
  ask: Ask,
  onProgress: (note: string) => void,
  signal?: AbortSignal,
): Promise<string> {
  const out: string[] = [];
  for (const file of files) {
    const body = file.full && file.full.length > STUDY_THRESHOLD ? file.full : null;
    if (!body) {
      out.push(file.text ? `\n\n[file ${file.name}]\n${file.text}` : `\n[image ${file.name}]`);
      continue;
    }
    const size = Math.max(6000, Math.ceil(body.length / MAX_PARTS));
    const chunks = chunkText(body, size);
    const notes: string[] = [];
    for (const chunk of chunks) {
      if (signal?.aborted) break;
      onProgress(`Reading ${file.name}: part ${chunk.index + 1} of ${chunks.length}`);
      let summary = "";
      try {
        summary = plain(await ask(partPrompt(file.name, chunk.index, chunks.length, chunk.startLine, chunk.endLine, chunk.text)));
      } catch {
        summary = "(could not summarize this part)";
      }
      notes.push(`Part ${chunk.index + 1} (lines ${chunk.startLine}-${chunk.endLine}): ${summary.replace(/\s*\n\s*/g, " ").slice(0, 600)}`);
    }
    const lineCount = body.split("\n").length;
    const picked = relevantChunks(chunks, question, 2)
      .map((chunk) => `--- part ${chunk.index + 1}, lines ${chunk.startLine}-${chunk.endLine}, word for word ---\n${chunk.text.slice(0, 3000)}`)
      .join("\n");
    out.push(
      `\n\n[file ${file.name}, ${lineCount} lines, studied in ${chunks.length} parts]\nMap of the file:\n${notes.join("\n")}${picked ? `\n\nMost relevant parts:\n${picked}` : ""}`,
    );
  }
  return out.join("");
}
