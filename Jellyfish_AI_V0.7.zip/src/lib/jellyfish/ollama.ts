/** Local brain: talks to Ollama on this device. No cloud key, no outside server. */

import { WHY_RULE } from "./tools.ts";

export const LOCAL_PRESETS: { model: string; label: string; note: string }[] = [
  { model: "qwen2.5-coder:7b", label: "Qwen2.5-Coder 7B", note: "About 4.7 GB. Runs on 8 GB RAM. The starting brain." },
  { model: "qwen2.5-coder:14b", label: "Qwen2.5-Coder 14B", note: "About 9 GB. Wants 16 GB RAM. Noticeably better." },
];

export type LocalModel = { name: string; size: number };

function root(baseUrl: string) {
  return baseUrl.replace(/\/$/, "");
}

/** Lists installed models, or null if Ollama is not running at that address. */
export async function ollamaTags(baseUrl: string, signal?: AbortSignal): Promise<LocalModel[] | null> {
  try {
    const response = await fetch(`${root(baseUrl)}/api/tags`, { signal });
    if (!response.ok) return null;
    const data = (await response.json()) as { models?: { name?: string; size?: number }[] };
    return (data.models ?? [])
      .filter((item): item is { name: string; size?: number } => typeof item.name === "string")
      .map((item) => ({ name: item.name, size: typeof item.size === "number" ? item.size : 0 }));
  } catch {
    return null;
  }
}

/** Downloads a model into Ollama. Calls onProgress with 0..1 when it knows, plus a status line. */
export async function ollamaPull(
  baseUrl: string,
  model: string,
  onProgress: (fraction: number | null, status: string) => void,
  signal?: AbortSignal,
): Promise<string | null> {
  let response: Response;
  try {
    response = await fetch(`${root(baseUrl)}/api/pull`, {
      method: "POST",
      signal,
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ model, name: model, stream: true }),
    });
  } catch {
    return "Ollama isn't running. Start it, then try again.";
  }
  if (!response.ok || !response.body) return `Ollama returned ${response.status}.`;
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let failure: string | null = null;
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() ?? "";
    for (const line of lines) {
      if (!line.trim()) continue;
      try {
        const row = JSON.parse(line) as { status?: string; total?: number; completed?: number; error?: string };
        if (row.error) failure = row.error;
        const fraction = row.total && row.completed ? Math.min(1, row.completed / row.total) : null;
        onProgress(fraction, row.status ?? "");
      } catch {
        /* partial json */
      }
    }
  }
  return failure;
}

/**
 * A short, concrete prompt for a 7B model. Small models follow a tight rule list and one
 * worked example far better than a long essay.
 */
export function localSystemPrompt(rules: string[], facts: string[], lessons: string[]): string {
  const list = (items: string[]) => (items.length ? items.map((item) => `- ${item}`).join("\n") : "(none)");
  return `You are Jellyfish AI, a coding assistant that runs on this device. If asked your name, say Jellyfish AI. If asked which model powers you, say it is the model chosen in Settings and you are not sure of its exact name.

Hard rules. Obey every one, on every reply:
${list(rules)}

How you work:
- Think first inside <thought> ... </thought> in at most 80 words. Never put code or <<< tags inside it.
- If you do not know something, say "I don't actually know that." Do not invent it.
- Code must be complete and runnable. Never write "rest of code here".
- Browser code only, as classic scripts. No import, no export. Load a library with a script tag from https://cdnjs.cloudflare.com and use its global.
- If the person only wants an explanation, answer in normal markdown. No PROJECT block.
- Games need keyboard and on-screen controls, a visible score, and a restart button.
- ${WHY_RULE}

When they want something to run, finish with exactly this block and nothing after it. index.html must load the css and js by these relative paths:

<<<PROJECT short-name
<<<FILE index.html
(entire file)
<<<FILE css/style.css
(entire file)
<<<FILE js/main.js
(entire file)
<<<FILE README.md
One short paragraph.
<<<END

Lessons from earlier fixes:
${list(lessons)}

Facts to keep:
${list(facts)}`;
}
