export type LogLevel = "log" | "info" | "warn" | "error";

export type ConsoleEntry = {
  id: number;
  level: LogLevel;
  text: string;
  at: number;
  source: string;
};

export type NetEntry = {
  id: number;
  method: string;
  url: string;
  status: number;
  ms: number;
  ok: boolean;
};

const logs: ConsoleEntry[] = [];
const nets: NetEntry[] = [];
const listeners = new Set<() => void>();
let seq = 0;
let hooked = false;
let lastError = "";

function emit() {
  for (const listener of listeners) listener();
}

export function getLogs(): ConsoleEntry[] {
  return logs;
}

export function getNets(): NetEntry[] {
  return nets;
}

export function subscribe(listener: () => void) {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

export function peekError(): string {
  return lastError;
}

export function pushLog(level: LogLevel, text: string, source = "app") {
  const line = text.replace(/\s+/g, " ").trim().slice(0, 500);
  if (!line) return;
  logs.push({ id: ++seq, level, text: line, at: Date.now(), source });
  if (logs.length > 200) logs.shift();
  if (level === "error") lastError = line;
  emit();
}

export function clearConsole() {
  logs.length = 0;
  nets.length = 0;
  lastError = "";
  emit();
}

export function installNetHook() {
  if (hooked || typeof window === "undefined") return;
  hooked = true;
  const orig = window.fetch.bind(window);
  window.fetch = async (input: RequestInfo | URL, init?: RequestInit) => {
    const method = (init?.method || (input instanceof Request ? input.method : "GET") || "GET").toUpperCase();
    const url = typeof input === "string" ? input : input instanceof URL ? input.href : input.url;
    const start = performance.now();
    const short = url.replace(location.origin, "").slice(0, 180);
    try {
      const response = await orig(input, init);
      nets.push({
        id: ++seq,
        method,
        url: short,
        status: response.status,
        ms: Math.round(performance.now() - start),
        ok: response.ok,
      });
      if (nets.length > 80) nets.shift();
      emit();
      return response;
    } catch (error) {
      nets.push({
        id: ++seq,
        method,
        url: short,
        status: 0,
        ms: Math.round(performance.now() - start),
        ok: false,
      });
      if (nets.length > 80) nets.shift();
      emit();
      throw error;
    }
  };
}
