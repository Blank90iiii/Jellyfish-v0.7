export type ProviderId = "xai" | "openai" | "anthropic" | "deepseek" | "openrouter" | "ollama";

export type ProviderConfig = {
  active: ProviderId;
  keys: Partial<Record<ProviderId, string>>;
  models: Partial<Record<ProviderId, string>>;
  baseUrls: Partial<Record<ProviderId, string>>;
  ollamaUrl: string;
  /** Cloud image route. OFF unless the person turns it on in Settings. */
  cloudPictures: boolean;
};

/** Bump when stored settings need a one-time migration. */
export const PROVIDERS_SCHEMA = 2;

export const PROVIDERS: { id: ProviderId; label: string; model: string; needsKey: boolean; hint: string }[] = [
  { id: "ollama", label: "Qwen (local)", model: "qwen2.5-coder:7b", needsKey: false, hint: "default, runs on this device via Ollama" },
  { id: "xai", label: "Jellyfish cloud", model: "grok-4.5", needsKey: false, hint: "Built in. No key to paste." },
  { id: "openai", label: "OpenAI", model: "gpt-4o-mini", needsKey: true, hint: "api.openai.com" },
  { id: "anthropic", label: "Anthropic", model: "claude-sonnet-4-5", needsKey: true, hint: "api.anthropic.com" },
  { id: "deepseek", label: "DeepSeek", model: "deepseek-chat", needsKey: true, hint: "api.deepseek.com" },
  { id: "openrouter", label: "OpenRouter", model: "openai/gpt-4o-mini", needsKey: true, hint: "openrouter.ai" },
];

const KEY = "jellyfish.providers.v6";

export const DEFAULT_BASE: Partial<Record<ProviderId, string>> = {
  openai: "https://api.openai.com/v1",
  deepseek: "https://api.deepseek.com",
  openrouter: "https://openrouter.ai/api/v1",
  anthropic: "https://api.anthropic.com",
  xai: "https://api.x.ai/v1",
};

function cleanBase(input: unknown): string {
  if (typeof input !== "string") return "";
  const value = input.trim().slice(0, 200);
  if (!value) return "";
  try {
    const url = new URL(value);
    if (url.protocol !== "https:" && url.protocol !== "http:") return "";
    if (url.protocol === "http:" && url.hostname !== "localhost" && url.hostname !== "127.0.0.1") return "";
    return `${url.origin}${url.pathname}`.replace(/\/$/, "");
  } catch {
    return "";
  }
}

export function defaultProviders(): ProviderConfig {
  return { active: "ollama", keys: {}, models: {}, baseUrls: {}, ollamaUrl: "http://127.0.0.1:11434", cloudPictures: false };
}

/**
 * Turn stored settings (any version) into a clean config.
 * v0.1 data (no schema number): keys, models and URLs are kept,
 * the active brain resets to Qwen, Cloud Pictures starts OFF.
 */
export function migrateProviders(data: unknown): ProviderConfig {
  const base = defaultProviders();
  if (!data || typeof data !== "object") return base;
  const row = data as Partial<ProviderConfig> & { schema?: unknown };
  const current = row.schema === PROVIDERS_SCHEMA;
  const baseUrls: Partial<Record<ProviderId, string>> = {};
  if (row.baseUrls && typeof row.baseUrls === "object") {
    for (const item of PROVIDERS) {
      const cleaned = cleanBase(row.baseUrls[item.id]);
      if (cleaned) baseUrls[item.id] = cleaned;
    }
  }
  const active =
    current && PROVIDERS.some((item) => item.id === row.active) ? (row.active as ProviderId) : "ollama";
  return {
    active,
    keys: row.keys && typeof row.keys === "object" ? row.keys : {},
    models: row.models && typeof row.models === "object" ? row.models : {},
    baseUrls,
    ollamaUrl:
      typeof row.ollamaUrl === "string" && row.ollamaUrl.startsWith("http") ? row.ollamaUrl : base.ollamaUrl,
    cloudPictures: current && row.cloudPictures === true,
  };
}

export function loadProviders(): ProviderConfig {
  if (typeof localStorage === "undefined") return defaultProviders();
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return defaultProviders();
    const parsed = JSON.parse(raw) as { schema?: unknown };
    const config = migrateProviders(parsed);
    if (parsed.schema !== PROVIDERS_SCHEMA) saveProviders(config);
    return config;
  } catch {
    return defaultProviders();
  }
}

export function saveProviders(config: ProviderConfig) {
  try {
    localStorage.setItem(KEY, JSON.stringify({ ...config, schema: PROVIDERS_SCHEMA }));
  } catch {
    /* private mode */
  }
}

export function baseFor(config: ProviderConfig, id: ProviderId): string {
  return config.baseUrls[id] || DEFAULT_BASE[id] || "";
}

export function modelFor(config: ProviderConfig, id: ProviderId): string {
  const custom = config.models[id]?.trim();
  if (custom) return custom.slice(0, 80);
  return PROVIDERS.find((item) => item.id === id)?.model ?? "qwen2.5-coder:7b";
}
