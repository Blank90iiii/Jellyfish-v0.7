import assert from "node:assert/strict";
import { test } from "node:test";
import { dequeueSidecar, enqueueSidecar, SIDECAR_MAX, SIDECAR_TEXT_MAX } from "./sidecar.ts";
import { filesNeedingSnapshot, type Snapshot } from "./history.ts";

test("side questions queue in order and come out first in, first out", () => {
  let queue = enqueueSidecar([], "  what is JSON?  ", "a").queue;
  queue = enqueueSidecar(queue, "what is an array?", "b").queue;
  assert.deepEqual(queue.map((item) => item.text), ["what is JSON?", "what is an array?"]);
  const first = dequeueSidecar(queue);
  assert.equal(first.item?.id, "a");
  assert.equal(first.rest.length, 1);
  assert.equal(dequeueSidecar([]).item, null);
});

test("empty questions are refused, long ones are cut, and the queue has a limit", () => {
  assert.equal(enqueueSidecar([], "   ", "x").accepted, false);
  assert.equal(enqueueSidecar([], "q".repeat(SIDECAR_TEXT_MAX + 100), "x").queue[0].text.length, SIDECAR_TEXT_MAX);
  let queue: { id: string; text: string }[] = [];
  for (let i = 0; i < SIDECAR_MAX; i += 1) queue = enqueueSidecar(queue, `q${i}`, String(i)).queue;
  const full = enqueueSidecar(queue, "one too many", "z");
  assert.equal(full.accepted, false);
  assert.equal(full.queue.length, SIDECAR_MAX);
});

test("a workspace snapshot only saves files that changed since their newest snapshot", () => {
  const rows: Snapshot[] = [
    { id: "1", projectId: "p", path: "index.html", content: "<h1>old</h1>", label: "x", at: 1 },
    { id: "2", projectId: "p", path: "index.html", content: "<h1>new</h1>", label: "x", at: 2 },
    { id: "3", projectId: "other", path: "a.js", content: "let a;", label: "x", at: 3 },
  ];
  const files = [
    { path: "index.html", content: "<h1>new</h1>" },
    { path: "a.js", content: "let a;" },
    { path: "css/style.css", content: "body{}" },
  ];
  assert.deepEqual(filesNeedingSnapshot(rows, "p", files).map((file) => file.path), ["a.js", "css/style.css"]);
  assert.deepEqual(filesNeedingSnapshot(rows, "p", [{ path: "index.html", content: "<h1>edited</h1>" }]).map((file) => file.path), ["index.html"]);
});
