/** Shown in Settings. Keep in step with package.json (a test checks). */
export const APP_VERSION = "0.7.0";
