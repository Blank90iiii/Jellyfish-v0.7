/**
 * Live state of one run: what Jellyfish is doing right now and what it already did.
 * Plain data, no AI. The UI only reads it.
 */
export type Phase =
  | "memory"
  | "planning"
  | "approval"
  | "studying"
  | "generating"
  | "tool"
  | "running"
  | "fixing"
  | "inspecting"
  | "judging"
  | "extending"
  | "done"
  | "failed"
  | "stopped";

export type StepStatus = "active" | "done" | "failed";
export type Step = { id: number; phase: Phase; label: string; detail: string; startedAt: number; endedAt?: number; status: StepStatus };
export type Outcome = "done" | "failed" | "stopped";
export type Run = { id: number; title: string; startedAt: number; endedAt?: number; steps: Step[]; calls: number; outcome?: Outcome };

let run: Run | null = null;
let runSeq = 0;
let stepSeq = 0;
const listeners = new Set<() => void>();

function emit() {
  for (const listener of listeners) listener();
}

export function getRun(): Run | null {
  return run;
}

export function subscribeRun(listener: () => void) {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

export function beginRun(title: string, now = Date.now()) {
  runSeq += 1;
  run = { id: runSeq, title: title.slice(0, 60), startedAt: now, steps: [], calls: 0 };
  emit();
}

function closeActive(status: StepStatus, now: number) {
  if (!run) return;
  const last = run.steps[run.steps.length - 1];
  if (last && last.status === "active") run.steps[run.steps.length - 1] = { ...last, status, endedAt: now };
}

/** Moves to a new step. The step before it is closed as done. Repeating the same label is ignored. */
export function stepTo(phase: Phase, label: string, detail = "", now = Date.now()) {
  if (!run) return;
  const last = run.steps[run.steps.length - 1];
  if (last && last.status === "active" && last.label === label && last.detail === detail) return;
  closeActive("done", now);
  stepSeq += 1;
  run = { ...run, steps: [...run.steps, { id: stepSeq, phase, label: label.slice(0, 80), detail: detail.slice(0, 160), startedAt: now, status: "active" as StepStatus }].slice(-40) };
  emit();
}

export function noteCall() {
  if (!run) return;
  run = { ...run, calls: run.calls + 1 };
  emit();
}

export function endRun(outcome: Outcome, now = Date.now()) {
  if (!run) return;
  closeActive(outcome === "failed" ? "failed" : "done", now);
  run = { ...run, outcome, endedAt: now };
  emit();
}

export function secondsOf(step: { startedAt: number; endedAt?: number }, now = Date.now()) {
  return Math.max(0, Math.round(((step.endedAt ?? now) - step.startedAt) / 1000));
}
