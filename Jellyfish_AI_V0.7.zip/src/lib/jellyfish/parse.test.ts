import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { compactHistory } from "./context.ts";
import { extractFacts } from "./memory.ts";
import { fromLegacy } from "./model.ts";
import { cleanWhy, parseMessage, safeRelPath } from "./parse.ts";
import { parseTools, stripTools, toolsPrompt, WHY_RULE } from "./tools.ts";

const GAME = `Snake is ready.

<<<PROJECT snake
<<<FILE index.html
<!DOCTYPE html>
<html><body><canvas id="c"></canvas></body></html>
<<<FILE js/game.js
console.log("snake");
<<<END
`;

describe("parseMessage", () => {
  it("hides thought tags from the visible reply", () => {
    const parsed = parseMessage("<thought>check the braces twice</thought>\n\nHello.", false);
    assert.equal(parsed.thought, "check the braces twice");
    assert.equal(parsed.text.includes("braces"), false);
    assert.match(parsed.text, /Hello/);
  });
  it("hides file bodies and keeps a downloadable project", () => {
    const parsed = parseMessage(GAME, false);
    assert.equal(parsed.project?.name, "snake");
    assert.deepEqual(
      parsed.project?.files.map((file) => file.path),
      ["index.html", "js/game.js"],
    );
    assert.equal(parsed.text.includes("<<<FILE"), false);
    assert.equal(parsed.text.includes("<!DOCTYPE html>"), false);
    assert.equal(parsed.text.includes("console.log"), false);
    assert.match(parsed.text, /Snake is ready/);
  });

  it("catches FILE tags that never got a PROJECT wrapper", () => {
    const parsed = parseMessage("<<<FILE css/style.css\nbody{margin:0}\n<<<FILE README.md\nHi\n", false);
    assert.equal(parsed.project?.name, "project");
    assert.equal(parsed.project?.files.length, 2);
    assert.equal(parsed.text.includes("body{margin:0}"), false);
  });

  it("does not leak an unfinished file while streaming", () => {
    const raw = "On it.\n<<<PROJECT pong\n<<<FILE index.html\n<!DOCTYPE html><html>";
    const parsed = parseMessage(raw, true);
    assert.equal(parsed.writing, true);
    assert.equal(parsed.project, null);
    assert.equal(parsed.text.includes("<!DOCTYPE html>"), false);
    assert.match(parsed.text, /Writing the project files/);
  });

  it("keeps finished files and hides the one still streaming", () => {
    const raw = "<<<PROJECT pong\n<<<FILE README.md\nPlay it.\n<<<FILE index.html\n<!DOCTYPE html>";
    const parsed = parseMessage(raw, true);
    assert.deepEqual(parsed.project?.files.map((file) => file.path), ["README.md"]);
    assert.equal(parsed.text.includes("<!DOCTYPE html>"), false);
  });

  it("reads memory and actions without showing the tags", () => {
    const parsed = parseMessage('Noted.\n<<<REMEMBER Favorite color is neon orange\n<<<ACTION {"theme":"dark"}\n', false);
    assert.deepEqual(parsed.remembers, ["Favorite color is neon orange"]);
    assert.equal(parsed.actions[0]?.theme, "dark");
    assert.equal(parsed.text.includes("<<<"), false);
  });
});

describe("memory and context", () => {
  it("pins a favorite color from a slangy sentence", () => {
    assert.deepEqual(extractFacts("wsp dawg my favorite color is neon orange"), ["Favorite color is neon orange"]);
  });

  it("replaces old project source with a file list", () => {
    const history = compactHistory([
      { role: "user", content: "make snake" },
      { role: "assistant", content: GAME },
      { role: "user", content: "what is my favorite color?" },
    ]);
    assert.match(history[1].content, /\[Project snake: index.html, js\/game.js\]/);
    assert.equal(history[1].content.includes("<!DOCTYPE html>"), false);
    assert.equal(history[2].content, "what is my favorite color?");
  });
});

describe("legacy restore", () => {
  it("turns a v1 snapshot into one isolated project", () => {
    const state = fromLegacy({
      chats: [{ id: "c1", title: "Snake", messages: [{ id: "m1", role: "user", text: "snake" }] }],
      activeId: "c1",
      facts: ["Favorite color is neon orange"],
      theme: "dark",
      view: "ide",
      files: [{ path: "index.html", content: "<h1>Hi</h1>" }],
      activeFile: "index.html",
    });
    assert.equal(state.projects.length, 1);
    assert.equal(state.projects[0].chats[0].title, "Snake");
    assert.equal(state.projects[0].activeChatId, "c1");
    assert.equal(state.facts[0], "Favorite color is neon orange");
    assert.equal(state.panel, "code");
    assert.equal(state.projects[0].files[0].content, "<h1>Hi</h1>");
  });
});

describe("the <<<WHY note before a terminal command", () => {
  const closed = "I will install the packages first.\n<<<WHY I need to install the packages the project lists.>>>\n<<<TOOL run\nnpm install\n<<<END";

  it("attaches a closed WHY note to the run call that follows it", () => {
    const calls = parseTools(closed);
    assert.equal(calls.length, 1);
    assert.equal(calls[0].name, "run");
    assert.equal(calls[0].arg, "npm install");
    assert.equal(calls[0].why, "I need to install the packages the project lists.");
  });

  it("accepts a multi-line note, brackets around the text, and a one-line note with no closer", () => {
    assert.equal(parseTools("<<<WHY [Check the Node version.]>>>\n<<<TOOL run\nnode -v\n<<<END")[0].why, "Check the Node version.");
    assert.equal(parseTools("<<<WHY line one\nline two>>>\n<<<TOOL run\nls\n<<<END")[0].why, "line one line two");
    assert.equal(parseTools("<<<WHY List the files.\n<<<TOOL run\nls\n<<<END")[0].why, "List the files.");
  });

  it("leaves why empty when there is no note, or when other text sits between the note and the tool", () => {
    assert.equal(parseTools("<<<TOOL run\nls\n<<<END")[0].why, undefined);
    assert.equal(parseTools("<<<WHY old reason>>>\nSome other words.\n<<<TOOL run\nls\n<<<END")[0].why, undefined);
    assert.equal(parseTools("<<<WHY one line\nand then prose\n<<<TOOL run\nls\n<<<END")[0].why, undefined);
  });

  it("gives each of two tool calls its own note", () => {
    const calls = parseTools("<<<WHY first reason>>>\n<<<TOOL run\na\n<<<END\n<<<WHY second reason>>>\n<<<TOOL run\nb\n<<<END");
    assert.deepEqual(calls.map((call) => call.why), ["first reason", "second reason"]);
  });

  it("hides the note and the tool block from the visible reply", () => {
    assert.equal(stripTools(closed), "I will install the packages first.");
    const shown = parseMessage("Okay.\n<<<WHY Because the page needs it.>>>\nDone.", false);
    assert.equal(shown.why, "Because the page needs it.");
    assert.equal(shown.text.includes("<<<"), false);
    assert.match(shown.text, /Okay/);
    assert.match(shown.text, /Done/);
  });

  it("hides a note that is still streaming and caps its length", () => {
    assert.equal(parseMessage("Sure.\n<<<WHY I want to", true).text.includes("WHY"), false);
    assert.equal(cleanWhy("x".repeat(900)).length, 300);
    assert.equal(cleanWhy("[ spaced   out ]"), "spaced out");
  });

  it("is demanded in the prompt only when the terminal tool is on", () => {
    assert.match(toolsPrompt({ web: false, terminal: true }), /<<<WHY/);
    assert.equal(toolsPrompt({ web: false, terminal: false }).includes("<<<WHY"), false);
    assert.match(WHY_RULE, /MUST/);
  });
});

describe("file deduplication and safe paths", () => {
  it("keeps one index.html when the AI writes it twice, and the second one wins", () => {
    const raw = "<<<PROJECT p\n<<<FILE index.html\n<h1>first</h1>\n<<<FILE css/style.css\nbody{}\n<<<FILE index.html\n<h1>second</h1>\n<<<END\n";
    const files = parseMessage(raw, false).project!.files;
    assert.deepEqual(files.map((file) => file.path), ["index.html", "css/style.css"]);
    assert.equal(files[0].content, "<h1>second</h1>");
  });

  it("treats ./index.html, index.html and Index.html as the same file", () => {
    const raw = "<<<FILE ./index.html\n<p>a</p>\n<<<FILE index.html\n<p>b</p>\n<<<FILE Index.html\n<p>c</p>\n";
    const files = parseMessage(raw, false).project!.files;
    assert.equal(files.length, 1);
    assert.equal(files[0].content, "<p>c</p>");
  });

  it("does not let an empty second copy wipe the first", () => {
    const files = parseMessage("<<<FILE a.js\nlet a = 1;\n<<<FILE a.js\n\n", false).project!.files;
    assert.deepEqual(files, [{ path: "a.js", content: "let a = 1;" }]);
  });

  it("rejects empty paths, folders, and trailing-dot names; merges doubled slashes", () => {
    assert.equal(safeRelPath(""), null);
    assert.equal(safeRelPath("   "), null);
    assert.equal(safeRelPath("/"), null);
    assert.equal(safeRelPath("css/"), null);
    assert.equal(safeRelPath("css//"), null);
    assert.equal(safeRelPath("a."), null);
    assert.equal(safeRelPath("..."), null);
    assert.equal(safeRelPath("../secret.txt"), null);
    assert.equal(safeRelPath("a/../b.txt"), null);
    assert.equal(safeRelPath("css//style.css"), "css/style.css");
    assert.equal(safeRelPath("./js/main.js"), "js/main.js");
    assert.equal(safeRelPath("/js/main.js"), "js/main.js");
    assert.equal(safeRelPath("css\\style.css"), "css/style.css");
    assert.equal(safeRelPath(".gitignore"), ".gitignore");
  });

  it("never returns the same path twice, however a long reply repeats files", () => {
    const body = Array.from({ length: 10 }, (_, i) => `<<<FILE js/${i % 3}.js\nlet n = ${i};\n`).join("");
    const paths = parseMessage(body, false).project!.files.map((file) => file.path);
    assert.equal(new Set(paths.map((path) => path.toLowerCase())).size, paths.length);
    assert.equal(paths.length, 3);
  });
});
