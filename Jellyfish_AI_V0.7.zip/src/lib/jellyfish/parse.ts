export type ProjectFile = { path: string; content: string };

export type Project = { name: string; files: ProjectFile[] };

export type Action = { theme?: "dark" | "light"; view?: "chat" | "ide" | "set" | "code" };

const TAG = /^<<<(FILE|PROJECT|END|REMEMBER|ACTION|WHY)\b/;

/** A closed WHY note: <<<WHY text>>> (it may not run into another <<< tag). */
const WHY_CLOSED = /^<<<WHY(?:(?!<<<)[\s\S]){0,600}?>>>/;
/** The same, anywhere in a text. */
export const WHY_CLOSED_ANYWHERE = /<<<WHY(?:(?!<<<)[\s\S]){0,600}?>>>/g;
export const WHY_MAX = 300;

/** One tidy line of "why" text: no brackets around it, no stray >>>, whitespace collapsed, capped. */
export function cleanWhy(raw: string): string {
  let text = raw.replace(/>>>/g, " ").replace(/\s+/g, " ").trim();
  const wrapped = text.match(/^\[(.*)\]$/);
  if (wrapped) text = wrapped[1].trim();
  return text.slice(0, WHY_MAX);
}

/**
 * Turns a model-written path into a safe, relative workspace path, or null.
 * Repeated slashes are merged and a leading "./" or "/" is dropped.
 * Empty paths, folders (trailing slash), "..", odd characters, and names that
 * end in a dot (not allowed on Windows) are refused.
 */
export function safeRelPath(input: string): string | null {
  if (typeof input !== "string") return null;
  let n = input.replace(/\\/g, "/").trim().replace(/\/{2,}/g, "/");
  while (/^(?:\.\/|\/)/.test(n)) n = n.replace(/^(?:\.\/|\/)/, "");
  if (!n || n.endsWith("/") || n.length > 120) return null;
  if (!/^[A-Za-z0-9._\-/]+$/.test(n)) return null;
  const parts = n.split("/");
  if (parts.some((part) => !part || /^\.+$/.test(part) || part.endsWith("."))) return null;
  return n;
}

function pullThoughts(raw: string, streaming: boolean): { text: string; thought: string } {
  const thoughts: string[] = [];
  let text = raw.replace(/<thought>([\s\S]*?)<\/thought>/gi, (_all, body: string) => {
    const line = String(body).trim();
    if (line) thoughts.push(line);
    return "";
  });
  const open = text.match(/<thought>([\s\S]*)$/i);
  if (open && typeof open.index === "number") {
    const line = open[1].trim();
    if (line) thoughts.push(line);
    else if (streaming) thoughts.push("");
    text = text.slice(0, open.index);
  }
  return { text, thought: thoughts.join("\n\n").trim() };
}

function cleanName(name: string): string {
  const clean = name.trim().replace(/[^\w.-]+/g, "-").replace(/^-|-$/g, "") || "project";
  return clean.slice(0, 40);
}

function pushFile(files: ProjectFile[], pathRaw: string, content: string) {
  const path = safeRelPath(pathRaw);
  if (!path) return;
  let body = content;
  if (body.endsWith("\n")) body = body.slice(0, -1);
  if (!body.trim()) return;
  if (body.length > 200_000) body = body.slice(0, 200_000);
  // The same path twice (even with different capitalization, which collides on Windows): the later one wins.
  const key = path.toLowerCase();
  const index = files.findIndex((file) => file.path.toLowerCase() === key);
  if (index >= 0) files[index] = { path, content: body };
  else if (files.length < 24) files.push({ path, content: body });
}

/**
 * Pull every <<<FILE body out of a reply, including files that arrived
 * without a <<<PROJECT wrapper, and return only the prose that should
 * be shown. File contents never stay in `text`.
 */
export function parseMessage(raw: string, streaming = false): {
  text: string;
  project: Project | null;
  remembers: string[];
  actions: Action[];
  writing: boolean;
  thought: string;
  why: string;
} {
  const pulled = pullThoughts(raw, streaming);
  const text = pulled.text.replace(/\r\n/g, "\n");
  const files: ProjectFile[] = [];
  const remembers: string[] = [];
  const actions: Action[] = [];
  let why = "";
  let projectName = "project";
  let sawProject = false;
  let writing = false;
  const visible: string[] = [];
  let i = 0;

  while (i < text.length) {
    const rest = text.slice(i);
    const tagAt = rest.search(/<<<(?:FILE|PROJECT|END|REMEMBER|ACTION|WHY)\b/);
    if (tagAt === -1) {
      visible.push(rest);
      break;
    }
    if (tagAt > 0) visible.push(rest.slice(0, tagAt));
    const from = rest.slice(tagAt);
    if (!TAG.test(from)) {
      visible.push("<<<");
      i += tagAt + 3;
      continue;
    }
    const lineEnd = from.indexOf("\n");
    const line = lineEnd === -1 ? from : from.slice(0, lineEnd);
    const afterLine = lineEnd === -1 ? text.length : i + tagAt + lineEnd + 1;
    const kind = line.match(TAG)?.[1];

    if (kind === "PROJECT") {
      if (sawProject) files.length = 0;
      sawProject = true;
      const name = line.replace(/^<<<PROJECT\s*/, "").trim();
      if (name) projectName = name;
      i = afterLine;
      continue;
    }
    if (kind === "END") {
      i = afterLine;
      continue;
    }
    if (kind === "WHY") {
      // <<<WHY text>>> (may span lines), or a one-line <<<WHY text when the closer was forgotten.
      const closed = from.match(WHY_CLOSED);
      if (closed) {
        const note = cleanWhy(closed[0].slice(6, -3));
        if (note) why = note;
        i += tagAt + closed[0].length;
      } else {
        const note = cleanWhy(line.slice(6));
        if (note) why = note;
        i = afterLine;
      }
      continue;
    }
    if (kind === "REMEMBER") {
      const fact = line.replace(/^<<<REMEMBER\s*/, "").trim().slice(0, 200);
      if (fact) remembers.push(fact);
      i = afterLine;
      continue;
    }
    if (kind === "ACTION") {
      const json = line.replace(/^<<<ACTION\s*/, "").trim();
      try {
        const value = JSON.parse(json) as { theme?: string; view?: string };
        const action: Action = {};
        if (value.theme === "dark" || value.theme === "light") action.theme = value.theme;
        if (value.view === "chat" || value.view === "ide" || value.view === "set" || value.view === "code") {
          action.view = value.view;
        }
        if (action.theme || action.view) actions.push(action);
      } catch {
        if (streaming) writing = true;
      }
      i = afterLine;
      continue;
    }

    const pathRaw = line.replace(/^<<<FILE\s*/, "").trim();
    const after = text.slice(afterLine);
    const stopper = after.search(/(^|\n)<<<(?:FILE|PROJECT|END|REMEMBER|ACTION|WHY)\b/);
    let content = "";
    let consumed = after.length;
    if (stopper === -1) {
      if (streaming) writing = true;
      else content = after;
    } else {
      const cut = after[stopper] === "\n" ? stopper : stopper;
      content = after.slice(0, cut);
      consumed = cut;
    }
    if (!(streaming && stopper === -1)) pushFile(files, pathRaw, content);
    i = afterLine + consumed;
  }

  if (streaming && /<<<(?:PROJECT|FILE)\b/.test(text) && !/<<<END\b/.test(text)) writing = true;

  let prose = visible
    .join("")
    .replace(/<<<(?:FILE|PROJECT|END|REMEMBER|ACTION|WHY)[^\n]*/g, "")
    .replace(/[ \t]+\n/g, "\n")
    .trim();

  if (writing) {
    const note = "Writing the project files…";
    prose = prose && !prose.endsWith(note) ? `${prose}\n\n${note}` : prose || note;
  }

  const project = files.length ? { name: cleanName(projectName), files } : null;
  return { text: prose, project, remembers, actions, writing, thought: pulled.thought, why };
}

export type TextPart =
  | { type: "text"; value: string }
  | { type: "code"; lang: string; value: string };

export function splitCode(raw: string): TextPart[] {
  const bits = raw.split("```");
  const parts: TextPart[] = [];
  for (let i = 0; i < bits.length; i++) {
    if (i % 2 === 0) {
      if (bits[i]) parts.push({ type: "text", value: bits[i] });
    } else {
      const nl = bits[i].indexOf("\n");
      const lang = (nl === -1 ? bits[i] : bits[i].slice(0, nl)).trim() || "code";
      const value = nl === -1 ? "" : bits[i].slice(nl + 1);
      if (/<<<(?:FILE|PROJECT|END)\b/.test(value)) continue;
      parts.push({ type: "code", lang, value: value.replace(/\n$/, "") });
    }
  }
  return parts;
}
