/** Turns a flat list of file paths into a folder tree. Pure, so the shape can be unit tested. */

export type TreeNode =
  | { kind: "file"; name: string; path: string }
  | { kind: "folder"; name: string; path: string; children: TreeNode[] };

function sortNodes(nodes: TreeNode[]): TreeNode[] {
  return nodes
    .map((node) => (node.kind === "folder" ? { ...node, children: sortNodes(node.children) } : node))
    .sort((a, b) => {
      if (a.kind !== b.kind) return a.kind === "folder" ? -1 : 1;
      return a.name.localeCompare(b.name);
    });
}

/** Folders first, then files, each A to Z. A path like "css/style.css" makes a "css" folder holding "style.css". */
export function buildTree(paths: string[]): TreeNode[] {
  const root: TreeNode[] = [];
  const seen = new Set<string>();
  for (const raw of paths) {
    const path = raw.trim();
    if (!path || seen.has(path)) continue;
    seen.add(path);
    const parts = path.split("/").filter(Boolean);
    let level = root;
    let walked = "";
    parts.forEach((part, index) => {
      walked = walked ? `${walked}/${part}` : part;
      if (index === parts.length - 1) {
        level.push({ kind: "file", name: part, path });
        return;
      }
      let folder = level.find((node): node is Extract<TreeNode, { kind: "folder" }> => node.kind === "folder" && node.name === part);
      if (!folder) {
        folder = { kind: "folder", name: part, path: walked, children: [] };
        level.push(folder);
      }
      level = folder.children;
    });
  }
  return sortNodes(root);
}

/** Every folder path that contains the given file ("css/a/b.css" -> ["css", "css/a"]). */
export function parentFolders(path: string): string[] {
  const parts = path.split("/").filter(Boolean);
  const out: string[] = [];
  for (let i = 1; i < parts.length; i += 1) out.push(parts.slice(0, i).join("/"));
  return out;
}
