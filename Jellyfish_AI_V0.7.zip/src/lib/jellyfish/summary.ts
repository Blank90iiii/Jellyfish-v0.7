export function sessionSummary(messages: { role: string; text: string }[]): string {
  const lines: string[] = [];
  for (const message of messages) {
    let text = message.text.replace(/<thought>[\s\S]*?<\/thought>/gi, " ");
    text = text.replace(/<<<PROJECT[\s\S]*?<<<END/g, " [wrote a project] ");
    text = text.replace(/\s+/g, " ").trim();
    if (!text) continue;
    const who = message.role === "user" ? "You" : "Jellyfish";
    lines.push(`${who}: ${text.slice(0, 110)}`);
  }
  const recent = lines.slice(-8);
  if (!recent.length) return "";
  return `Session recap: ${recent.join(" · ")}`.slice(0, 240);
}

export const CONTEXT_LIMIT = 32_000;

export function estimateTokens(text: string): number {
  const trimmed = text.trim();
  if (!trimmed) return 0;
  return Math.max(1, Math.ceil(trimmed.length / 4));
}
