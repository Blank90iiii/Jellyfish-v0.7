import assert from "node:assert/strict";
import { test } from "node:test";
import { defaultProviders, migrateProviders, PROVIDERS_SCHEMA } from "./providers.ts";

test("fresh install is local-first: Qwen via Ollama, cloud pictures off", () => {
  const config = defaultProviders();
  assert.equal(config.active, "ollama");
  assert.equal(config.cloudPictures, false);
});

test("v0.1 settings keep keys, models and URLs but the brain resets to Qwen", () => {
  const old = {
    active: "openai",
    keys: { openai: "sk-test" },
    models: { openai: "gpt-4o" },
    baseUrls: { openai: "https://example.com/v1" },
    ollamaUrl: "http://localhost:11500",
  };
  const next = migrateProviders(old);
  assert.equal(next.active, "ollama");
  assert.equal(next.keys.openai, "sk-test");
  assert.equal(next.models.openai, "gpt-4o");
  assert.equal(next.baseUrls.openai, "https://example.com/v1");
  assert.equal(next.ollamaUrl, "http://localhost:11500");
  assert.equal(next.cloudPictures, false);
});

test("a v0.1 file cannot switch cloud pictures on", () => {
  assert.equal(migrateProviders({ active: "xai", cloudPictures: true }).cloudPictures, false);
});

test("current-schema settings are kept as chosen", () => {
  const next = migrateProviders({ schema: PROVIDERS_SCHEMA, active: "deepseek", cloudPictures: true });
  assert.equal(next.active, "deepseek");
  assert.equal(next.cloudPictures, true);
});

test("garbage input falls back to defaults", () => {
  assert.deepEqual(migrateProviders(null), defaultProviders());
  assert.equal(migrateProviders("x").active, "ollama");
});
