/** Plain-English meanings for common coding words. A fixed list: no AI, no network. */

export const JARGON: Record<string, string> = {
  API: "A set of rules that lets one program ask another program for something, like a waiter taking your order to the kitchen.",
  JSON: "A simple text format for storing data as names and values, such as {\"name\": \"Sam\", \"age\": 12}. Programs use it to pass data around.",
  Array: "An ordered list of things in one variable, like [\"red\", \"green\", \"blue\"]. You get items by their position, starting at 0.",
  DOM: "The browser's live map of a web page. JavaScript uses it to find, change, add, or remove things on the page.",
  Function: "A named block of code you can run again whenever you need it, often with inputs and an output.",
  Variable: "A named box that holds a value, like score = 10. You can read it or change it later.",
  Object: "A bundle of related values stored under names, like a player with a name, a score, and a position.",
  Loop: "Code that repeats the same steps many times, either a set number of times or until something changes.",
  Boolean: "A value that is only true or false. Programs use it to make yes-or-no decisions.",
  String: "Text in code, like \"hello\". It is a string of characters.",
  Bug: "A mistake in code that makes it behave wrongly or crash.",
  Console: "The browser's message window for developers. Errors and messages from your code show up there.",
  Sandbox: "A sealed box where code can run safely without touching your files or the rest of your computer.",
  Framework: "A ready-made starting structure for building apps, so you do not write everything from scratch.",
  Library: "Code someone else wrote that you can load and use, such as a 3D library or a chart library.",
  CDN: "A fast public server that hosts popular libraries so your page can load them with one script tag.",
  Canvas: "A blank drawing area on a web page that JavaScript can paint shapes, images, and animation onto.",
  Event: "Something that happens that code can react to, like a click, a key press, or a page finishing loading.",
  Async: "Code that starts a slow job, like loading data, and carries on instead of waiting. The result arrives later.",
  Terminal: "A text window where you type commands for your computer to run instead of clicking buttons.",
};

function norm(term: string): string {
  return term.trim().toLowerCase().replace(/[^a-z]/g, "");
}

const LOOKUP: Record<string, string> = Object.fromEntries(Object.keys(JARGON).map((key) => [norm(key), key]));

/** The plain-English meaning of a term (any capitalization, surrounding spaces or punctuation), or null if it is not in the list. */
export function getJargon(term: string): string | null {
  const key = LOOKUP[norm(term)];
  return key ? JARGON[key] : null;
}

/** All terms, A to Z, for a future glossary screen. */
export function jargonTerms(): string[] {
  return Object.keys(JARGON).sort((a, b) => a.localeCompare(b));
}
