import type { Project } from "./parse";
import {
  clickerProject,
  labProject,
  pongProject,
  sketchProject,
  snakeProject,
  twoSumProject,
} from "./projects";

export type LocalAnswer = { text: string; project?: Project };

const OFFLINE = "Couldn't reach the cloud brain. On-device answer:";

export function offline(answer: LocalAnswer): LocalAnswer {
  return { ...answer, text: `${OFFLINE}\n\n${answer.text}` };
}

const GENZ =
  /\b(wsp|dawg|fr fr|no cap|\bcap\b|\bbet\b|lowkey|highkey|\bngl\b|bussin|cooked|sheesh|buns|iykyk)\b/i;

function slang(query: string): boolean {
  return GENZ.test(query);
}

export function localAnswer(query: string): LocalAnswer {
  const q = query.trim();
  const z = slang(q);
  if (/^(hi|hey|hello|yo|sup|gm|gn|wsp)\b/i.test(q) || /how are you/i.test(q)) {
    return { text: z ? "Wsp bro. What are we building?" : "Hey. What do you need?" };
  }
  if (/what('?s| is) your name|who are you|what are you|your name/i.test(q)) {
    return {
      text: z
        ? "I'm Jellyfish AI, fr. I write code, drop games you can download, and run them in the workspace. Not gonna look up a movie because you asked my name."
        : "I'm Jellyfish AI. I write code, build games you can download, and run them in the workspace. I won't go look up a movie because you asked my name.",
    };
  }
  if (/thank/i.test(q)) return { text: z ? "Bet. Anytime." : "Anytime." };
  if (/what can you do|help|capabilities/i.test(q)) {
    return {
      text: z
        ? "I write code, build playable games, run them here, and zip the files. Snake, pong, a clicker, two-sum, the 3D lab, or a picture. Say the word."
        : "I write code, build playable games, run them in the workspace, and zip the files for you. I keep chats and facts on this device. Ask for snake, pong, a clicker, a two-sum, a 3D lab, or a picture.",
    };
  }
  if (/snake/i.test(q)) {
    return {
      text: "Snake is ready. Open it in the workspace or download the zip. Arrow keys, or the buttons on a phone.",
      project: snakeProject(),
    };
  }
  if (/pong/i.test(q)) {
    return {
      text: "Pong is ready. You play the left paddle. First to 7.",
      project: pongProject(),
    };
  }
  if (/clicker|idle/i.test(q)) {
    return { text: "Clicker is ready. Buy a helper once you can afford it.", project: clickerProject() };
  }
  if (/two[-\s]?sum/i.test(q)) {
    return {
      text: "Two-sum is in the workspace with three checks. Open it and press Run.",
      project: twoSumProject(),
    };
  }
  if (/\b(3d|4d|simulation|webgl|wireframe)\b/i.test(q)) {
    return {
      text: "The 3D lab is a pair of spinning cubes. Drag to orbit. Pause when you want it still.",
      project: labProject(),
    };
  }
  if (/\b(draw|image|picture|photo|illustrat)\b/i.test(q)) {
    return {
      text: "I can't render a photo while the cloud brain is unreachable. Here's a canvas sketch instead.",
      project: sketchProject(q),
    };
  }
  if (/\bzip\b/i.test(q)) {
    return {
      text: "When a project is ready, Download zip gives you a folder with index.html, css, js, and a readme. Ask for snake if you want one right now.",
    };
  }
  if (/\b(code|function|script|bug|error|fix)\b/i.test(q)) {
    return {
      text: "The cloud brain writes the larger stuff. On this device I can still hand you snake, pong, a clicker, two-sum, or the 3D lab. Say which.",
    };
  }
  return {
    text: slang(q)
      ? "I'm here. Ask for code, a game, or a picture. Name the language and what it should do."
      : "I'm here. Ask for code, a game, a picture, or say my name. If you want something specific, name the language and the behaviour.",
  };
}

export function isImageAsk(query: string): boolean {
  const q = query.trim();
  if (/\b(snake|pong|clicker|game|function|zip|workspace|simulation|two[-\s]?sum)\b/i.test(q)) return false;
  if (/^(draw|paint|sketch|illustrate)\b/i.test(q)) return true;
  return (
    /\b(image|picture|photo|illustration|logo|icon|portrait|wallpaper)\b/i.test(q) &&
    /\b(draw|paint|illustrat|render|generate|make|create|design)\b/i.test(q)
  );
}

export function wantsSearch(query: string): boolean {
  if (/\byour name\b|\bwho are you\b|\bwhat are you\b/i.test(query)) return false;
  return /\b(search the web|look up|latest news|in the news|who is|what happened|weather|stock price)\b/i.test(
    query,
  );
}
