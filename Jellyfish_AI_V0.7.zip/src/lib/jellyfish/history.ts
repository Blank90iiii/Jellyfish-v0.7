export type Snapshot = {
  id: string;
  projectId: string;
  path: string;
  content: string;
  label: string;
  at: number;
};

const KEY = "jellyfish.history";
const MAX = 60;

function read(): Snapshot[] {
  if (typeof localStorage === "undefined") return [];
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return [];
    const data = JSON.parse(raw) as unknown;
    if (!Array.isArray(data)) return [];
    const rows: Snapshot[] = [];
    for (const item of data) {
      if (!item || typeof item !== "object") continue;
      const row = item as Partial<Snapshot>;
      if (typeof row.path !== "string" || typeof row.content !== "string" || typeof row.projectId !== "string") continue;
      rows.push({
        id: typeof row.id === "string" ? row.id : crypto.randomUUID(),
        projectId: row.projectId,
        path: row.path.slice(0, 120),
        content: row.content.slice(0, 200_000),
        label: typeof row.label === "string" ? row.label.slice(0, 80) : row.path,
        at: typeof row.at === "number" ? row.at : 0,
      });
    }
    return rows.slice(-MAX);
  } catch {
    return [];
  }
}

function write(rows: Snapshot[]) {
  try {
    localStorage.setItem(KEY, JSON.stringify(rows.slice(-MAX)));
  } catch {
    /* quota: drop the oldest half and try once */
    try {
      localStorage.setItem(KEY, JSON.stringify(rows.slice(-Math.ceil(MAX / 2))));
    } catch {
      /* ignore */
    }
  }
  if (typeof window !== "undefined") window.dispatchEvent(new Event("jellyfish-history"));
}

export function loadSnapshots(projectId?: string): Snapshot[] {
  const rows = read();
  const scoped = projectId ? rows.filter((row) => row.projectId === projectId) : rows;
  return scoped.slice().reverse();
}

export function pushSnapshot(input: Omit<Snapshot, "id" | "at">): Snapshot {
  const snap: Snapshot = {
    id: crypto.randomUUID(),
    projectId: input.projectId,
    path: input.path,
    content: input.content,
    label: input.label,
    at: Date.now(),
  };
  const rows = read();
  const last = rows[rows.length - 1];
  if (last && last.projectId === snap.projectId && last.path === snap.path && last.content === snap.content) return last;
  write([...rows, snap]);
  return snap;
}

/** Which workspace files differ from their newest saved snapshot (or have none yet). Pure: easy to test. */
export function filesNeedingSnapshot(rows: Snapshot[], projectId: string, files: { path: string; content: string }[]): { path: string; content: string }[] {
  const out: { path: string; content: string }[] = [];
  for (const file of files) {
    let latest: Snapshot | undefined;
    for (let i = rows.length - 1; i >= 0; i -= 1) {
      if (rows[i].projectId === projectId && rows[i].path === file.path) {
        latest = rows[i];
        break;
      }
    }
    if (!latest || latest.content !== file.content) out.push(file);
  }
  return out;
}

/**
 * Saves the whole workspace as it is right now, before the AI changes anything.
 * Files that have not changed since their last snapshot are skipped, so this does not fill the list.
 * Returns how many files were saved.
 */
export function pushWorkspaceSnapshot(projectId: string, files: { path: string; content: string }[], label = "Auto: before AI request"): number {
  if (!files.length) return 0;
  const rows = read();
  const changed = filesNeedingSnapshot(rows, projectId, files);
  if (!changed.length) return 0;
  const at = Date.now();
  const added: Snapshot[] = changed.map((file) => ({
    id: crypto.randomUUID(),
    projectId,
    path: file.path,
    content: file.content,
    label,
    at,
  }));
  write([...rows, ...added]);
  return added.length;
}
