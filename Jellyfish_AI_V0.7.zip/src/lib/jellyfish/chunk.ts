/** Splits a big file into readable pieces so a small model can study it one piece at a time. */

export type Chunk = { index: number; startLine: number; endLine: number; text: string };

const BOUNDARY =
  /^\s{0,2}(export\s|async\s|function\s|class\s|def\s|fn\s|pub\s|impl\s|struct\s|interface\s|type\s|public\s|private\s|protected\s|static\s|package\s|namespace\s|#include|using\s|func\s|const\s+\w+\s*=\s*(async\s*)?\(|\/\/\s*[-=#]{3,}|#\s*[-=]{3,})/;

export function chunkText(input: string, maxChars = 6000): Chunk[] {
  const limit = Math.max(500, maxChars);
  const lines = input.split("\n");
  const chunks: Chunk[] = [];
  let buffer: string[] = [];
  let size = 0;
  let start = 1;

  const flush = (endLine: number) => {
    if (!buffer.length) return;
    chunks.push({ index: chunks.length, startLine: start, endLine, text: buffer.join("\n") });
    buffer = [];
    size = 0;
    start = endLine + 1;
  };

  for (let i = 0; i < lines.length; i += 1) {
    let line = lines[i];
    const lineNo = i + 1;
    // A single huge line (minified code) is cut by characters.
    while (line.length > limit) {
      flush(lineNo - 1);
      chunks.push({ index: chunks.length, startLine: lineNo, endLine: lineNo, text: line.slice(0, limit) });
      line = line.slice(limit);
      start = lineNo;
    }
    const cost = line.length + 1;
    const nearlyFull = size >= limit * 0.6;
    if (buffer.length && size + cost > limit) flush(lineNo - 1);
    else if (buffer.length && nearlyFull && (BOUNDARY.test(line) || (line.trim() === "" && size >= limit * 0.85))) flush(lineNo - 1);
    buffer.push(line);
    size += cost;
  }
  flush(lines.length);
  return chunks;
}

const STOP = new Set(["the", "and", "for", "that", "this", "with", "what", "does", "how", "can", "you", "are", "why", "where", "file", "code", "from", "into", "have", "make", "fix"]);

function words(input: string): string[] {
  return (input.toLowerCase().match(/[a-z_][a-z0-9_]{2,}/g) ?? []).filter((word) => !STOP.has(word));
}

/** Picks the pieces whose words overlap most with the question. */
export function relevantChunks(chunks: Chunk[], question: string, count = 2): Chunk[] {
  const wanted = new Set(words(question));
  if (!wanted.size) return [];
  const scored = chunks
    .map((chunk) => {
      const have = new Set(words(chunk.text));
      let score = 0;
      for (const word of wanted) if (have.has(word)) score += 1;
      return { chunk, score };
    })
    .filter((item) => item.score > 0)
    .sort((a, b) => b.score - a.score || a.chunk.index - b.chunk.index);
  return scored.slice(0, count).map((item) => item.chunk);
}
