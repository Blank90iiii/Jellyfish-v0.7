/** Pure helpers for reading the internet. Used by the server route; tested without a network. */

export type SearchHit = { title: string; url: string; snippet: string };

function decode(input: string): string {
  return input
    .replace(/&#x([0-9a-f]+);/gi, (_, hex: string) => String.fromCodePoint(parseInt(hex, 16)))
    .replace(/&#(\d+);/g, (_, num: string) => String.fromCodePoint(Number(num)))
    .replace(/&nbsp;/g, " ")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&amp;/g, "&");
}

function strip(input: string): string {
  return decode(input.replace(/<[^>]*>/g, " ")).replace(/\s+/g, " ").trim();
}

export function pageTitle(html: string): string {
  const match = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  return match ? strip(match[1]).slice(0, 200) : "";
}

/** Turns a web page into readable text. Drops scripts, styles, menus and footers. */
export function htmlToText(html: string, max = 8000): string {
  const cleaned = html
    .replace(/<!--[\s\S]*?-->/g, " ")
    .replace(/<(script|style|noscript|svg|nav|footer|header|form|iframe)\b[\s\S]*?<\/\1>/gi, " ")
    .replace(/<(br|\/p|\/div|\/li|\/h[1-6]|\/tr)\s*>/gi, "\n");
  const text = decode(cleaned.replace(/<[^>]*>/g, " "))
    .replace(/[ \t\f\v]+/g, " ")
    .replace(/ *\n */g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
  return text.slice(0, max);
}

function realUrl(href: string): string {
  const raw = decode(href);
  const match = raw.match(/[?&]uddg=([^&]+)/);
  if (match) {
    try {
      return decodeURIComponent(match[1]);
    } catch {
      return "";
    }
  }
  return raw.startsWith("//") ? `https:${raw}` : raw;
}

export function parseDuckDuckGo(html: string, max = 8): SearchHit[] {
  const hits: SearchHit[] = [];
  const linkRe = /<a[^>]*class="[^"]*result__a[^"]*"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi;
  const snippetRe = /<a[^>]*class="[^"]*result__snippet[^"]*"[^>]*>([\s\S]*?)<\/a>/gi;
  const snippets: string[] = [];
  let sm: RegExpExecArray | null;
  while ((sm = snippetRe.exec(html))) snippets.push(strip(sm[1]));
  let lm: RegExpExecArray | null;
  let i = 0;
  while ((lm = linkRe.exec(html)) && hits.length < max) {
    const url = realUrl(lm[1]);
    if (/^https?:\/\//i.test(url)) hits.push({ title: strip(lm[2]).slice(0, 160), url, snippet: (snippets[i] ?? "").slice(0, 300) });
    i += 1;
  }
  return hits;
}

export function parseRss(xml: string, max = 8): SearchHit[] {
  const hits: SearchHit[] = [];
  const itemRe = /<item\b[\s\S]*?<\/item>/gi;
  const pick = (block: string, tag: string) => {
    const match = block.match(new RegExp(`<${tag}[^>]*>([\\s\\S]*?)</${tag}>`, "i"));
    if (!match) return "";
    return strip(match[1].replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1"));
  };
  let im: RegExpExecArray | null;
  while ((im = itemRe.exec(xml)) && hits.length < max) {
    const block = im[0];
    const url = pick(block, "link");
    const date = pick(block, "pubDate");
    const desc = pick(block, "description");
    if (/^https?:\/\//i.test(url)) hits.push({ title: pick(block, "title").slice(0, 200), url, snippet: `${date}${date && desc ? " - " : ""}${desc}`.slice(0, 300) });
  }
  return hits;
}

export function parseBrave(data: unknown, max = 8): SearchHit[] {
  const root = data as { web?: { results?: unknown[] }; results?: unknown[] };
  const rows = (root?.web?.results ?? root?.results ?? []) as { title?: unknown; url?: unknown; description?: unknown; age?: unknown }[];
  return rows
    .filter((row) => typeof row.url === "string" && /^https?:\/\//i.test(row.url as string))
    .slice(0, max)
    .map((row) => ({
      title: strip(String(row.title ?? "")).slice(0, 160),
      url: String(row.url),
      snippet: strip(`${row.age ? `${row.age} - ` : ""}${String(row.description ?? "")}`).slice(0, 300),
    }));
}

export function parseSearx(data: unknown, max = 8): SearchHit[] {
  const rows = ((data as { results?: unknown[] })?.results ?? []) as { title?: unknown; url?: unknown; content?: unknown }[];
  return rows
    .filter((row) => typeof row.url === "string" && /^https?:\/\//i.test(row.url as string))
    .slice(0, max)
    .map((row) => ({ title: strip(String(row.title ?? "")).slice(0, 160), url: String(row.url), snippet: strip(String(row.content ?? "")).slice(0, 300) }));
}

export function isPrivateHost(host: string): boolean {
  const h = host.toLowerCase().replace(/^\[|\]$/g, "");
  if (!h || h === "localhost" || h.endsWith(".localhost") || h.endsWith(".local") || h.endsWith(".internal")) return true;
  if (h === "::1" || h === "::" || /^f[cd][0-9a-f]{2}:/.test(h) || /^fe80:/.test(h) || h.startsWith("::ffff:")) return true;
  const m = h.match(/^(\d+)\.(\d+)\.(\d+)\.(\d+)$/);
  if (m) {
    const a = Number(m[1]);
    const b = Number(m[2]);
    return a === 0 || a === 10 || a === 127 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || a >= 224;
  }
  return false;
}

/** A URL the server may fetch: http or https, no login in the address, not a private address. */
export function publicUrl(input: string, allowPrivate = false): URL | null {
  try {
    const url = new URL(input.trim());
    if (url.protocol !== "https:" && url.protocol !== "http:") return null;
    if (url.username || url.password) return null;
    if (!allowPrivate && isPrivateHost(url.hostname)) return null;
    return url;
  } catch {
    return null;
  }
}

export function formatHits(hits: SearchHit[]): string {
  if (!hits.length) return "No results.";
  return hits.map((hit, i) => `${i + 1}. ${hit.title}\n   ${hit.url}\n   ${hit.snippet}`).join("\n");
}
