import assert from "node:assert/strict";
import { test } from "node:test";
import { autoChecks, canSeeImages, checkPrompt, formatInspection, looksLikeBuild, parseChecks, type Inspection } from "./verify.ts";

const base: Inspection = {
  errors: [],
  title: "",
  text: "Score: 0",
  canvases: [{ w: 300, h: 200, filled: 0.3, colors: 4 }],
  buttons: ["Restart"],
  inputs: 0,
  images: 0,
  animates: true,
  reactsToInput: true,
  overflowX: false,
  shot: null,
};

test("a healthy page passes every automatic check", () => {
  const items = autoChecks(base);
  assert.ok(items.every((item) => item.status === "pass"));
});

test("errors, an empty canvas and sideways overflow are caught without asking the model", () => {
  const items = autoChecks({ ...base, errors: ["x is not defined (line 4)"], canvases: [{ w: 300, h: 200, filled: 0, colors: 1 }], overflowX: true });
  assert.equal(items.filter((item) => item.status === "fail").length, 3);
  assert.ok(items[0].note.includes("x is not defined"));
});

test("the report states the measurements plainly", () => {
  const text = formatInspection({ ...base, canvases: [{ w: 300, h: 200, filled: 0, colors: 1 }], reactsToInput: null });
  assert.ok(text.includes("EMPTY"));
  assert.ok(text.includes("could not tell"));
  assert.ok(text.includes("Buttons: Restart"));
});

test("the model's check reply is parsed, and junk lines are ignored", () => {
  const reply = `<thought>hmm</thought>\nREQ: Snake moves with arrow keys | PASS | score changed\n- REQ: Game over screen | FAIL | never shown\nsome chatter\nREQ: Restart button | unsure\nVERDICT: FAIL`;
  const parsed = parseChecks(reply);
  assert.equal(parsed.items.length, 3);
  assert.deepEqual(parsed.items.map((i) => i.status), ["pass", "fail", "unsure"]);
  assert.equal(parsed.verdict, "fail");
  assert.deepEqual(parseChecks("I think it is fine!"), { items: [], verdict: null });
});

test("the check prompt scopes the core build and attaches the right instructions", () => {
  const core = checkPrompt("make a snake game", null, "report", false, "core");
  assert.ok(core.includes("Only the core") && core.includes("No screenshot"));
  const fixed = checkPrompt("make a snake game", ["Snake moves"], "report", true, "full");
  assert.ok(fixed.includes("- Snake moves") && fixed.includes("screenshot of the running project is attached"));
});

test("build requests are recognized and vision support is decided by model", () => {
  assert.equal(looksLikeBuild("make me a snake game"), true);
  assert.equal(looksLikeBuild("build a landing page for a coffee shop"), true);
  assert.equal(looksLikeBuild("what is a closure?"), false);
  assert.equal(canSeeImages("ollama", "qwen2.5-coder:7b"), false);
  assert.equal(canSeeImages("ollama", "qwen2.5vl:7b"), true);
  assert.equal(canSeeImages("deepseek", "deepseek-chat"), false);
  assert.equal(canSeeImages("xai", "grok"), true);
});
