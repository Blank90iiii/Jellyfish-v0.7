import assert from "node:assert/strict";
import { test } from "node:test";
import { languageFor, monacoThemeFor } from "./editor-lang.ts";
import { nextHelpOpen } from "./helptip.ts";

test("language comes from the file extension", () => {
  assert.equal(languageFor("index.html"), "html");
  assert.equal(languageFor("css/Main.CSS"), "css");
  assert.equal(languageFor("app.js"), "javascript");
  assert.equal(languageFor("lib/x.mjs"), "javascript");
  assert.equal(languageFor("notes.txt"), "plaintext");
  assert.equal(languageFor("README"), "plaintext");
});

test("monaco theme follows the app theme", () => {
  assert.equal(monacoThemeFor("dark"), "vs-dark");
  assert.equal(monacoThemeFor("light"), "vs");
});

test("help button toggles on and off; outside tap and escape close", () => {
  assert.equal(nextHelpOpen(false, "help"), true);
  assert.equal(nextHelpOpen(true, "help"), false);
  assert.equal(nextHelpOpen(true, "outside"), false);
  assert.equal(nextHelpOpen(true, "escape"), false);
  assert.equal(nextHelpOpen(false, "outside"), false);
});
