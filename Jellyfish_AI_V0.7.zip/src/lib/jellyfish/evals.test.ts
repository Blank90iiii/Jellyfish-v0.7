import assert from "node:assert/strict";
import { test } from "node:test";
import { runEvals, summarize, type EvalDef } from "./evals.ts";
import type { Inspection } from "./verify.ts";

const good: Inspection = { errors: [], title: "", text: "ok", canvases: [], buttons: [], inputs: 0, images: 0, animates: null, reactsToInput: null, overflowX: false, shot: null };
const proj = (js: string) => `<<<PROJECT t\n<<<FILE index.html\n<html><body><script src="js/main.js"></script></body></html>\n<<<FILE js/main.js\n${js}\n<<<END\n`;
const defs: EvalDef[] = [
  { id: 1, prompt: "Make A", check: "A works" },
  { id: 2, prompt: "Make B", check: "B works" },
  { id: 3, prompt: "Make C", check: "C works" },
];

test("first try, final pass, and format failures are scored separately", async () => {
  // Prompt A: right first time. B: console error, fixed on the next call. C: model answers with no project.
  const replies: Record<string, string[]> = {
    "Make A": [proj("good()"), "REQ: A works | PASS | ok\nVERDICT: PASS"],
    "Make B": [proj("bad("), proj("good()"), "REQ: B works | PASS | ok\nVERDICT: PASS"],
    "Make C": ["Sure, here is some advice about C."],
  };
  let current = "";
  const queue: string[] = [];
  let tick = 0;
  const report = await runEvals(defs, {
    generate: async (turns, onDelta) => {
      const first = turns[0].content;
      if (turns.length === 1 && first.startsWith("Make ")) {
        current = first;
        queue.splice(0, queue.length, ...replies[first]);
      }
      onDelta(queue.shift() ?? "");
      return null;
    },
    probe: async (files) => (files.some((file) => file.content.includes("bad(")) ? ["SyntaxError"] : []),
    inspect: async () => good,
    aborted: () => false,
    onProgress: () => {},
    meta: { provider: "test", model: "fake" },
    now: () => (tick += 1000),
  });
  void current;
  assert.equal(report.total, 3);
  assert.equal(report.formatOk, 2);
  assert.equal(report.firstTry, 1);
  assert.equal(report.passed, 2);
  const b = report.results.find((r) => r.id === 2)!;
  assert.equal(b.fixes, 1);
  assert.equal(b.passed, true);
  assert.equal(b.firstTry, false);
  const c = report.results.find((r) => r.id === 3)!;
  assert.equal(c.formatOk, false);
  assert.ok(c.note.includes("no runnable project"));
});

test("stopping mid-run keeps what was scored so far", async () => {
  let stop = false;
  const report = await runEvals(defs, {
    generate: async (_t, onDelta) => {
      onDelta("no project");
      stop = true;
      return null;
    },
    probe: async () => [],
    inspect: async () => good,
    aborted: () => stop,
    onProgress: () => {},
    meta: { provider: "x", model: "y" },
  });
  assert.equal(report.total, 1);
});

test("an empty report does not divide by zero", () => {
  const report = summarize([], { provider: "x", model: "y" }, 1);
  assert.equal(report.avgSeconds, 0);
  assert.equal(report.total, 0);
});
