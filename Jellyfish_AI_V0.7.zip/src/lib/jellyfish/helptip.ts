export type HelpEvent = "help" | "outside" | "escape";

/**
 * Open/closed state of one help bubble.
 * The Help button always toggles (so a second tap closes it).
 * A tap anywhere else, or Escape, closes it.
 */
export function nextHelpOpen(open: boolean, event: HelpEvent): boolean {
  if (event === "help") return !open;
  return false;
}
