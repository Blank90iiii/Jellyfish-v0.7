export type EditorLanguage = "html" | "css" | "javascript" | "plaintext";

/** Monaco language for a project file path. */
export function languageFor(path: string): EditorLanguage {
  const ext = path.toLowerCase().split(".").pop() ?? "";
  if (ext === "html" || ext === "htm") return "html";
  if (ext === "css") return "css";
  if (ext === "js" || ext === "mjs" || ext === "cjs") return "javascript";
  return "plaintext";
}

/** Monaco theme name for the app theme. Keeps editor and app in step. */
export function monacoThemeFor(theme: "dark" | "light"): "vs" | "vs-dark" {
  return theme === "light" ? "vs" : "vs-dark";
}
