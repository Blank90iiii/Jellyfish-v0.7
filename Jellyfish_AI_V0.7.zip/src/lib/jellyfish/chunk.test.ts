import assert from "node:assert/strict";
import { test } from "node:test";
import { chunkText, relevantChunks } from "./chunk.ts";

const sample = Array.from({ length: 300 }, (_, i) => (i % 25 === 0 ? `function part${i}() {` : `  const value${i} = ${i}; // filler line for testing`)).join("\n");

test("chunks cover the whole file with no loss and stay under the limit", () => {
  const chunks = chunkText(sample, 1500);
  assert.equal(chunks.map((chunk) => chunk.text).join("\n"), sample);
  assert.ok(chunks.length > 3);
  assert.ok(chunks.every((chunk) => chunk.text.length <= 1500));
  assert.equal(chunks[0].startLine, 1);
  assert.equal(chunks[chunks.length - 1].endLine, 300);
  for (let i = 1; i < chunks.length; i += 1) assert.equal(chunks[i].startLine, chunks[i - 1].endLine + 1);
});

test("a function start is preferred as a split point", () => {
  const chunks = chunkText(sample, 1500);
  const starts = chunks.slice(1).filter((chunk) => /^function part/.test(chunk.text));
  assert.ok(starts.length >= 1);
});

test("a minified single line is split by characters", () => {
  const line = "a".repeat(5000);
  const chunks = chunkText(line, 1000);
  assert.equal(chunks.map((chunk) => chunk.text).join(""), line);
  assert.ok(chunks.every((chunk) => chunk.text.length <= 1000));
});

test("relevantChunks finds the piece that mentions the question's words", () => {
  const text = ["alpha line one", "x ".repeat(400), "function renderBoard() { drawGrid(); }", "y ".repeat(400)].join("\n");
  const chunks = chunkText(text, 700);
  const hit = relevantChunks(chunks, "why does renderBoard fail", 1);
  assert.equal(hit.length, 1);
  assert.ok(hit[0].text.includes("renderBoard"));
  assert.deepEqual(relevantChunks(chunks, "zzzz qqqq", 1), []);
});
