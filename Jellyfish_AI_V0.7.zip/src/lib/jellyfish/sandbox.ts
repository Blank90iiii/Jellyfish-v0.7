import htmlToImageSource from "html-to-image/dist/html-to-image.js?raw";
import { inspectScript } from "./inspect-script";
import type { Inspection } from "./verify";
import type { ProjectFile } from "./parse";
import { buildPreview } from "./preview";
import { pushLog } from "./console-bus";

/** Run a project off-screen and collect console errors. */
export function probeProject(files: ProjectFile[], ms = 1600): Promise<string[]> {
  return new Promise((resolve) => {
    const iframe = document.createElement("iframe");
    iframe.setAttribute("sandbox", "allow-scripts");
    iframe.title = "Jellyfish sandbox";
    iframe.style.cssText = "position:fixed;width:1px;height:1px;left:-10px;top:0;border:0;opacity:0;pointer-events:none";
    const errors: string[] = [];
    const onMessage = (event: MessageEvent) => {
      if (event.source !== iframe.contentWindow) return;
      const data = event.data as { type?: string; msg?: string; level?: string; err?: boolean };
      if (!data || data.type !== "cf-log" || typeof data.msg !== "string") return;
      const level = data.level === "warn" || data.level === "error" || data.level === "log" ? data.level : data.err ? "error" : "log";
      if (level === "error") {
        errors.push(data.msg.slice(0, 300));
        pushLog("error", data.msg, "sandbox");
      } else if (level === "warn") {
        pushLog("warn", data.msg, "sandbox");
      }
    };
    window.addEventListener("message", onMessage);
    iframe.srcdoc = buildPreview(files);
    document.body.appendChild(iframe);
    window.setTimeout(() => {
      window.removeEventListener("message", onMessage);
      iframe.remove();
      resolve(errors.slice(0, 8));
    }, ms);
  });
}

export type StressReport = {
  errors: string[];
  seconds: number;
  frames: number;
  fps: number;
  maxGapMs: number;
  heapGrowthMb: number | null;
  verdict: string[];
};

function stressScript(seconds: number) {
  return `<script>(function(){
var end=Date.now()+${Math.round(seconds * 1000)},keys=["ArrowUp","ArrowDown","ArrowLeft","ArrowRight"," ","Enter","w","a","s","d","Escape"];
var frames=0,last=performance.now(),maxGap=0,start=last;
var heap0=performance.memory?performance.memory.usedJSHeapSize:null;
function rnd(n){return Math.floor(Math.random()*n)}
function key(type){try{var k=keys[rnd(keys.length)];var e=new KeyboardEvent(type,{key:k,code:k,bubbles:true});document.dispatchEvent(e);window.dispatchEvent(e)}catch(x){}}
function mouse(type){try{var x=rnd(innerWidth),y=rnd(innerHeight),t=document.elementFromPoint(x,y)||document.body;t.dispatchEvent(new MouseEvent(type,{clientX:x,clientY:y,bubbles:true}))}catch(x){}}
function frame(now){frames++;var gap=now-last;if(frames>2&&gap>maxGap)maxGap=gap;last=now;if(Date.now()<end)requestAnimationFrame(frame)}
requestAnimationFrame(frame);
var timer=setInterval(function(){
  key("keydown");key("keyup");mouse("mousemove");
  if(Math.random()<0.2){mouse("mousedown");mouse("mouseup");mouse("click")}
  if(Date.now()>=end){clearInterval(timer);
    var heap1=performance.memory?performance.memory.usedJSHeapSize:null;
    parent.postMessage({type:"cf-stress",frames:frames,seconds:(performance.now()-start)/1000,maxGap:maxGap,heapGrowth:(heap0!==null&&heap1!==null)?(heap1-heap0)/1048576:null},"*");
  }
},30);
})();</script>`;
}

/** Runs a project off-screen while firing random keys and clicks, then reports errors, frame rate and freezes. */
export function stressProject(files: ProjectFile[], seconds = 8): Promise<StressReport> {
  return new Promise((resolve) => {
    const iframe = document.createElement("iframe");
    iframe.setAttribute("sandbox", "allow-scripts");
    iframe.title = "Jellyfish stress test";
    iframe.style.cssText = "position:fixed;left:0;top:0;width:480px;height:640px;border:0;opacity:0;pointer-events:none;z-index:-1";
    const errors: string[] = [];
    let done = false;
    const finish = (stats: { frames: number; seconds: number; maxGap: number; heapGrowth: number | null }) => {
      if (done) return;
      done = true;
      window.removeEventListener("message", onMessage);
      window.clearTimeout(guard);
      iframe.remove();
      const fps = stats.seconds > 0 ? stats.frames / stats.seconds : 0;
      const verdict: string[] = [];
      if (errors.length) verdict.push(`${errors.length} error${errors.length === 1 ? "" : "s"} under stress`);
      if (stats.maxGap > 1000) verdict.push(`froze for ${Math.round(stats.maxGap)} ms`);
      if (stats.frames < 5) verdict.push("barely drew anything (is there an animation loop?)");
      else if (fps < 20) verdict.push(`low frame rate (${fps.toFixed(0)} fps)`);
      if (stats.heapGrowth !== null && stats.heapGrowth > 50) verdict.push(`memory grew ${stats.heapGrowth.toFixed(0)} MB (possible leak)`);
      resolve({
        errors: errors.slice(0, 8),
        seconds: stats.seconds,
        frames: stats.frames,
        fps,
        maxGapMs: stats.maxGap,
        heapGrowthMb: stats.heapGrowth,
        verdict,
      });
    };
    const onMessage = (event: MessageEvent) => {
      if (event.source !== iframe.contentWindow) return;
      const data = event.data as { type?: string; msg?: string; level?: string; err?: boolean; frames?: number; seconds?: number; maxGap?: number; heapGrowth?: number | null };
      if (!data) return;
      if (data.type === "cf-log" && typeof data.msg === "string" && (data.level === "error" || data.err)) {
        errors.push(data.msg.slice(0, 300));
        pushLog("error", data.msg, "stress");
      }
      if (data.type === "cf-stress") {
        finish({ frames: data.frames ?? 0, seconds: data.seconds ?? seconds, maxGap: data.maxGap ?? 0, heapGrowth: data.heapGrowth ?? null });
      }
    };
    window.addEventListener("message", onMessage);
    const guard = window.setTimeout(() => finish({ frames: 0, seconds, maxGap: 0, heapGrowth: null }), seconds * 1000 + 4000);
    iframe.srcdoc = buildPreview(files) + stressScript(seconds);
    document.body.appendChild(iframe);
  });
}

/**
 * Runs the project off-screen like a tester would: waits, watches whether it moves, pokes it with keys and clicks,
 * measures what is drawn, and takes a small picture. Returns facts, not opinions.
 */
export function inspectProject(files: ProjectFile[]): Promise<Inspection> {
  return new Promise((resolve) => {
    const iframe = document.createElement("iframe");
    iframe.setAttribute("sandbox", "allow-scripts");
    iframe.title = "Jellyfish inspector";
    iframe.style.cssText = "position:fixed;left:0;top:0;width:480px;height:640px;border:0;opacity:0;pointer-events:none;z-index:-1";
    const errors: string[] = [];
    let done = false;
    const empty: Inspection = {
      errors,
      title: "",
      text: "",
      canvases: [],
      buttons: [],
      inputs: 0,
      images: 0,
      animates: null,
      reactsToInput: null,
      overflowX: false,
      shot: null,
    };
    const finish = (report: Partial<Inspection> & { error?: string }) => {
      if (done) return;
      done = true;
      window.removeEventListener("message", onMessage);
      window.clearTimeout(guard);
      iframe.remove();
      const { error, ...rest } = report;
      resolve({ ...empty, ...rest, errors: errors.slice(0, 8), failed: error });
    };
    const onMessage = (event: MessageEvent) => {
      if (event.source !== iframe.contentWindow) return;
      const data = event.data as { type?: string; msg?: string; level?: string; err?: boolean; report?: Partial<Inspection> & { error?: string } };
      if (!data) return;
      if (data.type === "cf-log" && typeof data.msg === "string" && (data.level === "error" || data.err)) errors.push(data.msg.slice(0, 300));
      if (data.type === "cf-inspect" && data.report) finish(data.report);
    };
    window.addEventListener("message", onMessage);
    const guard = window.setTimeout(() => finish({ error: "The page did not finish loading in time." }), 14_000);
    iframe.srcdoc = buildPreview(files) + inspectScript(htmlToImageSource);
    document.body.appendChild(iframe);
  });
}
