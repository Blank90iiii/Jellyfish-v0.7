import { openDb } from "./persist";

export type Lesson = { id: string; summary: string; pattern: string; at: number };

const LS_KEY = "jellyfish.knowledge";
let cache: Lesson[] | null = null;

function cleanLesson(raw: unknown): Lesson | null {
  if (!raw || typeof raw !== "object") return null;
  const row = raw as Partial<Lesson>;
  if (typeof row.summary !== "string" || !row.summary.trim()) return null;
  return {
    id: typeof row.id === "string" ? row.id : crypto.randomUUID(),
    summary: row.summary.trim().slice(0, 240),
    pattern: typeof row.pattern === "string" ? row.pattern.slice(0, 60) : "note",
    at: typeof row.at === "number" ? row.at : 0,
  };
}

function readLocal(): Lesson[] {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (!raw) return [];
    const data = JSON.parse(raw) as unknown;
    if (!Array.isArray(data)) return [];
    return data.map(cleanLesson).filter((item): item is Lesson => !!item).slice(-40);
  } catch {
    return [];
  }
}

function writeLocal(lessons: Lesson[]) {
  try {
    localStorage.setItem(LS_KEY, JSON.stringify(lessons));
  } catch {
    /* quota */
  }
}

async function readIdb(): Promise<Lesson[] | null> {
  try {
    const db = await openDb();
    return await new Promise((resolve) => {
      const tx = db.transaction("lessons", "readonly");
      const request = tx.objectStore("lessons").get("all");
      request.onsuccess = () => {
        const value = request.result;
        if (!Array.isArray(value)) {
          resolve(null);
          return;
        }
        resolve(value.map(cleanLesson).filter((item): item is Lesson => !!item));
      };
      request.onerror = () => resolve(null);
    });
  } catch {
    return null;
  }
}

async function writeIdb(lessons: Lesson[]) {
  try {
    const db = await openDb();
    await new Promise<void>((resolve) => {
      const tx = db.transaction("lessons", "readwrite");
      tx.objectStore("lessons").put(lessons, "all");
      tx.oncomplete = () => resolve();
      tx.onerror = () => resolve();
    });
  } catch {
    /* ignore */
  }
}

async function readSeed(): Promise<Lesson[]> {
  try {
    const response = await fetch("/knowledge.json");
    if (!response.ok) return [];
    const data = (await response.json()) as { lessons?: unknown };
    if (!Array.isArray(data.lessons)) return [];
    return data.lessons.map(cleanLesson).filter((item): item is Lesson => !!item);
  } catch {
    return [];
  }
}

function merge(seed: Lesson[], local: Lesson[]): Lesson[] {
  const map = new Map<string, Lesson>();
  for (const lesson of seed) map.set(lesson.id, lesson);
  for (const lesson of local) map.set(lesson.id, lesson);
  return [...map.values()].slice(-40);
}

export function lessonLines(): string[] {
  return (cache ?? readLocal()).map((lesson) => lesson.summary).slice(-12);
}

export async function refreshLessons(): Promise<Lesson[]> {
  const seed = await readSeed();
  const idb = await readIdb();
  const local = readLocal();
  const lessons = merge(seed, idb && idb.length ? idb : local);
  cache = lessons;
  writeLocal(lessons);
  void writeIdb(lessons);
  return lessons;
}

export async function addLesson(summary: string, pattern: string): Promise<Lesson[]> {
  const current = cache ?? (await refreshLessons());
  const line = summary.trim().slice(0, 240);
  if (!line) return current;
  if (current.some((item) => item.summary.toLowerCase() === line.toLowerCase())) return current;
  const next = [...current, { id: crypto.randomUUID(), summary: line, pattern: pattern.slice(0, 60), at: Date.now() }].slice(-40);
  cache = next;
  writeLocal(next);
  await writeIdb(next);
  if (typeof window !== "undefined") window.dispatchEvent(new Event("jellyfish-knowledge"));
  return next;
}
