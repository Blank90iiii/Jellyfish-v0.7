import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { test } from "node:test";
import { APP_VERSION } from "./version.ts";

test("the version shown in the app matches package.json and the desktop package", () => {
  const root = JSON.parse(readFileSync(new URL("../../../package.json", import.meta.url), "utf8")) as { version: string };
  const desktop = JSON.parse(readFileSync(new URL("../../../desktop/package.json", import.meta.url), "utf8")) as { version: string };
  assert.equal(APP_VERSION, root.version);
  assert.equal(APP_VERSION, desktop.version);
});
