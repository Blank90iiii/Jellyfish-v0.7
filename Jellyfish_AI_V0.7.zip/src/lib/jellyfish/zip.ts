import { safeRelPath, type ProjectFile } from "./parse";

export async function downloadZip(name: string, files: ProjectFile[]) {
  const { default: JSZip } = await import("jszip");
  const zip = new JSZip();
  const folder = name.replace(/[^\w.-]+/g, "-").replace(/^-|-$/g, "") || "jellyfish-project";
  const root = zip.folder(folder);
  if (!root) return;
  for (const file of files) {
    const path = safeRelPath(file.path);
    if (path) root.file(path, file.content);
  }
  const blob = await zip.generateAsync({ type: "blob" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `${folder}.zip`;
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}
