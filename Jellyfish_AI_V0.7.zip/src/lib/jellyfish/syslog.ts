/**
 * System log: problems in Jellyfish itself or in the model (Ollama down, rate limit, parse trouble).
 * Kept apart from the Console, which only shows errors from the code you are previewing.
 */
export type SysLevel = "info" | "warn" | "error";
export type SysEntry = { id: number; level: SysLevel; source: string; text: string; at: number };

const entries: SysEntry[] = [];
const listeners = new Set<() => void>();
let seq = 0;
let hooked = false;

function emit() {
  for (const listener of listeners) listener();
}

export function getSys(): SysEntry[] {
  return entries;
}

export function subscribeSys(listener: () => void) {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

export function sysLog(level: SysLevel, source: string, text: string) {
  seq += 1;
  entries.push({ id: seq, level, source: source.slice(0, 24), text: String(text).slice(0, 400), at: Date.now() });
  if (entries.length > 200) entries.splice(0, entries.length - 200);
  emit();
}

export function clearSys() {
  entries.length = 0;
  emit();
}

/** Catches errors thrown by the app itself. Errors inside the preview iframe never reach here. */
export function hookSystem() {
  if (hooked || typeof window === "undefined") return;
  hooked = true;
  window.addEventListener("error", (event) => sysLog("error", "app", `${event.message}`));
  window.addEventListener("unhandledrejection", (event) => {
    const reason = event.reason instanceof Error ? event.reason.message : String(event.reason);
    sysLog("error", "app", `Unhandled: ${reason}`);
  });
}
