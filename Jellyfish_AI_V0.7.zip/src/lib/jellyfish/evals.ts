/**
 * Eval runner: gives the model a fixed set of coding requests and scores what comes back.
 * Two scores per request: FIRST TRY (the model alone) and FINAL (after Jellyfish tested and fixed it).
 * The gap between them is what the harness adds. Pure logic; the browser parts are passed in.
 */
import { runBuild, type Effects } from "./conductor.ts";
import { parseMessage } from "./parse.ts";

export type EvalDef = { id: number; prompt: string; check: string };

export type EvalResult = {
  id: number;
  prompt: string;
  formatOk: boolean;
  firstTry: boolean;
  passed: boolean;
  runsClean: boolean;
  fixes: number;
  calls: number;
  seconds: number;
  note: string;
};

export type EvalReport = {
  at: number;
  provider: string;
  model: string;
  total: number;
  formatOk: number;
  firstTry: number;
  passed: number;
  avgSeconds: number;
  avgCalls: number;
  results: EvalResult[];
};

/** A small, mixed set that finishes quickly. */
export const QUICK_IDS = [1, 4, 5, 6, 13];

export type EvalDeps = {
  generate: Effects["generate"];
  probe: Effects["probe"];
  inspect: Effects["inspect"];
  aborted: () => boolean;
  onProgress: (done: number, total: number, current: string, result?: EvalResult) => void;
  meta: { provider: string; model: string };
  now?: () => number;
  fixLimit?: number;
  verifyRounds?: number;
};

export async function runEvals(defs: EvalDef[], deps: EvalDeps): Promise<EvalReport> {
  const now = deps.now ?? Date.now;
  const results: EvalResult[] = [];
  for (let i = 0; i < defs.length && !deps.aborted(); i += 1) {
    const def = defs[i];
    deps.onProgress(i, defs.length, def.prompt);
    const started = now();
    let calls = 0;
    let firstProbe: boolean | null = null;
    let firstRound: boolean | null = null;
    const countedGenerate: Effects["generate"] = (turns, onDelta, opts) => {
      calls += 1;
      return deps.generate(turns, onDelta, opts);
    };
    let full = "";
    const history = [{ role: "user" as const, content: def.prompt }];
    const genError = await countedGenerate(history, (chunk) => {
      full += chunk;
    });
    const project = parseMessage(full, false).project;
    let result: EvalResult;
    if (!project || !project.files.some((file) => /(^|\/)index\.html$/i.test(file.path))) {
      result = { id: def.id, prompt: def.prompt, formatOk: false, firstTry: false, passed: false, runsClean: false, fixes: 0, calls, seconds: (now() - started) / 1000, note: genError ? `model error: ${genError}`.slice(0, 120) : "no runnable project in the reply" };
    } else {
      const fx: Effects = {
        generate: countedGenerate,
        probe: async (files) => {
          const errors = await deps.probe(files);
          if (firstProbe === null) firstProbe = errors.length === 0;
          return errors;
        },
        inspect: deps.inspect,
        confirm: async () => true,
        aborted: deps.aborted,
        step: () => {},
        text: () => {},
        checks: (rounds) => {
          if (firstRound === null && rounds[0]) firstRound = !rounds[0].items.some((item) => item.status === "fail");
        },
        lesson: () => {},
        log: () => {},
      };
      const built = await runBuild(
        { request: def.prompt, history, full, project, checkpointed: false, verify: true, canSee: false, approveEveryStep: false, requirements: [def.check], fixLimit: deps.fixLimit, verifyRounds: deps.verifyRounds },
        fx,
      );
      const finalErrors = await deps.probe(built.project.files);
      const runsClean = finalErrors.length === 0;
      const passed = runsClean && built.stillFailing.length === 0 && !built.stopped;
      result = {
        id: def.id,
        prompt: def.prompt,
        formatOk: true,
        firstTry: firstProbe === true && firstRound === true,
        passed,
        runsClean,
        fixes: built.fixes,
        calls,
        seconds: (now() - started) / 1000,
        note: passed ? "" : (finalErrors[0] ?? built.stillFailing[0] ?? "did not meet the check").slice(0, 120),
      };
    }
    results.push(result);
    deps.onProgress(i + 1, defs.length, def.prompt, result);
  }
  return summarize(results, deps.meta, now());
}

export function summarize(results: EvalResult[], meta: { provider: string; model: string }, at: number): EvalReport {
  const n = results.length || 1;
  return {
    at,
    provider: meta.provider,
    model: meta.model,
    total: results.length,
    formatOk: results.filter((r) => r.formatOk).length,
    firstTry: results.filter((r) => r.firstTry).length,
    passed: results.filter((r) => r.passed).length,
    avgSeconds: Math.round((results.reduce((sum, r) => sum + r.seconds, 0) / n) * 10) / 10,
    avgCalls: Math.round((results.reduce((sum, r) => sum + r.calls, 0) / n) * 10) / 10,
    results,
  };
}
