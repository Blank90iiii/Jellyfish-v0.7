export type SearchProviderId = "ddg" | "brave" | "searx";

export type ToolsConfig = {
  web: boolean;
  terminal: boolean;
  search: { id: SearchProviderId; key: string; url: string };
};

const KEY = "jellyfish.tools";

export const DEFAULT_TOOLS: ToolsConfig = { web: true, terminal: false, search: { id: "ddg", key: "", url: "" } };

export function loadTools(): ToolsConfig {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return DEFAULT_TOOLS;
    const data = JSON.parse(raw) as Partial<ToolsConfig>;
    const id = data.search?.id;
    return {
      web: data.web !== false,
      terminal: data.terminal === true,
      search: {
        id: id === "brave" || id === "searx" ? id : "ddg",
        key: typeof data.search?.key === "string" ? data.search.key.slice(0, 300) : "",
        url: typeof data.search?.url === "string" ? data.search.url.slice(0, 200) : "",
      },
    };
  } catch {
    return DEFAULT_TOOLS;
  }
}

export function saveTools(config: ToolsConfig) {
  try {
    localStorage.setItem(KEY, JSON.stringify(config));
  } catch {
    /* ignore */
  }
}
