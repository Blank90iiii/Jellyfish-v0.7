import { useCallback, useEffect, useState } from "react";
import type { Project, ProjectFile } from "./parse";
import { safeRelPath } from "./parse";
import {
  activeProject,
  applyPalette,
  freshChat,
  initialState,
  makeProject,
  type JellyfishState,
  type Panel,
  type ProjectSpace,
} from "./model";
import { loadState, loadStateSync, saveState } from "./persist";

export type { Attachment, Chat, ChatMessage, JellyfishState, Panel, ProjectSpace } from "./model";
export { activeProject } from "./model";

function mapProject(state: JellyfishState, recipe: (project: ProjectSpace) => ProjectSpace): JellyfishState {
  return {
    ...state,
    projects: state.projects.map((project) => (project.id === state.activeProjectId ? recipe(project) : project)),
  };
}

export function useJellyfish() {
  const [state, setState] = useState<JellyfishState>(initialState);
  const [ready, setReady] = useState(false);
  const [booted, setBooted] = useState(true);

  useEffect(() => {
    let cancel = false;
    const cached = loadStateSync();
    if (cached) {
      document.documentElement.dataset.theme = cached.theme;
      applyPalette(cached.primary, cached.secondary);
      setState(cached);
    }
    setBooted(true);
    loadState()
      .then((loaded) => {
        if (cancel) return;
        document.documentElement.dataset.theme = loaded.theme;
        applyPalette(loaded.primary, loaded.secondary);
        setState(loaded);
        setReady(true);
      })
      .catch(() => {
        if (!cancel) {
          setReady(true);
        }
      });
    return () => {
      cancel = true;
    };
  }, []);

  useEffect(() => {
    if (!ready) return;
    document.documentElement.dataset.theme = state.theme;
    applyPalette(state.primary, state.secondary);
    try {
      localStorage.setItem("jellyfish.theme", state.theme);
      localStorage.setItem(
        "jellyfish.palette",
        JSON.stringify({ primary: state.primary, secondary: state.secondary }),
      );
    } catch {
      /* ignore */
    }
    const timer = window.setTimeout(() => {
      void saveState(state);
    }, 200);
    const flush = () => {
      void saveState(state);
    };
    window.addEventListener("pagehide", flush);
    return () => {
      window.clearTimeout(timer);
      window.removeEventListener("pagehide", flush);
    };
  }, [state, ready]);

  const update = useCallback((recipe: (current: JellyfishState) => JellyfishState) => {
    setState((current) => recipe(current));
  }, []);

  const newChat = useCallback(() => {
    update((current) => ({
      ...mapProject(current, (project) => {
        const active = project.chats.find((chat) => chat.id === project.activeChatId);
        if (active && active.messages.length === 0) return project;
        const chat = freshChat();
        return { ...project, activeChatId: chat.id, chats: [chat, ...project.chats].slice(0, 30) };
      }),
      panel: "chat",
    }));
  }, [update]);

  const selectChat = useCallback(
    (id: string) => {
      update((current) => ({
        ...mapProject(current, (project) =>
          project.chats.some((chat) => chat.id === id) ? { ...project, activeChatId: id } : project,
        ),
        panel: "chat",
      }));
    },
    [update],
  );

  const newProject = useCallback(
    (name: string) => {
      const label = name.trim().slice(0, 40);
      if (!label) return;
      update((current) => {
        const project = makeProject(label);
        return {
          ...current,
          panel: "chat",
          artifactsOpen: false,
          activeProjectId: project.id,
          projects: [project, ...current.projects].slice(0, 20),
        };
      });
    },
    [update],
  );

  const selectProject = useCallback(
    (id: string) => {
      update((current) =>
        current.projects.some((project) => project.id === id)
          ? { ...current, activeProjectId: id, panel: "chat" }
          : current,
      );
    },
    [update],
  );

  const deleteProject = useCallback(
    (id: string) => {
      update((current) => {
        if (current.projects.length < 2) return current;
        const projects = current.projects.filter((project) => project.id !== id);
        return {
          ...current,
          projects,
          activeProjectId: current.activeProjectId === id ? projects[0].id : current.activeProjectId,
        };
      });
    },
    [update],
  );

  const setPalette = useCallback(
    (primary: string, secondary: string) => {
      applyPalette(primary, secondary);
      update((current) => ({ ...current, primary, secondary }));
    },
    [update],
  );

  const addRule = useCallback(
    (rule: string) => {
      const line = rule.trim().slice(0, 240);
      if (!line) return;
      update((current) => {
        if (current.rules.some((item) => item.toLowerCase() === line.toLowerCase())) return current;
        return { ...current, rules: [...current.rules, line].slice(-40) };
      });
    },
    [update],
  );

  const removeRule = useCallback(
    (rule: string) => update((current) => ({ ...current, rules: current.rules.filter((item) => item !== rule) })),
    [update],
  );

  const setTheme = useCallback(
    (theme: "dark" | "light") => {
      document.documentElement.dataset.theme = theme;
      try {
        localStorage.setItem("jellyfish.theme", theme);
      } catch {
        /* ignore */
      }
      update((current) => ({ ...current, theme }));
    },
    [update],
  );

  const setPanel = useCallback(
    (panel: Panel) => update((current) => ({ ...current, panel })),
    [update],
  );

  const setSidebarCollapsed = useCallback(
    (sidebarCollapsed: boolean) => update((current) => ({ ...current, sidebarCollapsed })),
    [update],
  );

  const setArtifactsOpen = useCallback(
    (artifactsOpen: boolean) => update((current) => ({ ...current, artifactsOpen, panel: artifactsOpen ? "chat" : current.panel })),
    [update],
  );

  const remember = useCallback(
    (fact: string) => {
      const line = fact.trim().slice(0, 200);
      if (!line) return;
      update((current) => {
        if (current.facts.some((item) => item.toLowerCase() === line.toLowerCase())) return current;
        return { ...current, facts: [...current.facts, line].slice(-40) };
      });
    },
    [update],
  );

  const removeFact = useCallback(
    (fact: string) => update((current) => ({ ...current, facts: current.facts.filter((item) => item !== fact) })),
    [update],
  );

  const editFact = useCallback(
    (before: string, after: string) => {
      const line = after.trim().slice(0, 200);
      if (!line) return;
      update((current) => {
        if (current.facts.some((item) => item !== before && item.toLowerCase() === line.toLowerCase())) {
          return { ...current, facts: current.facts.filter((item) => item !== before) };
        }
        return { ...current, facts: current.facts.map((item) => (item === before ? line : item)) };
      });
    },
    [update],
  );

  const clearFacts = useCallback(() => update((current) => ({ ...current, facts: [] })), [update]);

  const clearChats = useCallback(() => {
    update((current) => ({
      ...mapProject(current, (project) => {
        const chat = freshChat();
        return { ...project, chats: [chat], activeChatId: chat.id };
      }),
      panel: "chat",
    }));
  }, [update]);

  const showArtifact = useCallback(
    (project: Project) => {
      const files = project.files
        .map((file) => {
          const path = safeRelPath(file.path);
          return path ? { path, content: file.content } : null;
        })
        .filter((file): file is ProjectFile => !!file);
      if (!files.length) return;
      update((current) => ({
        ...mapProject(current, (space) => ({
          ...space,
          artifact: { name: project.name, files },
        })),
        artifactsOpen: true,
        panel: "chat",
      }));
    },
    [update],
  );

  const loadWorkspace = useCallback(
    (project: Project, run: boolean) => {
      const files = project.files
        .map((file) => {
          const path = safeRelPath(file.path);
          return path ? { path, content: file.content } : null;
        })
        .filter((file): file is ProjectFile => !!file);
      if (!files.length) return;
      update((current) => ({
        ...mapProject(current, (space) => ({
          ...space,
          files,
          activeFile: files.some((file) => file.path === "index.html") ? "index.html" : files[0].path,
          artifact: { name: project.name, files },
        })),
        panel: "code",
        runToken: run ? current.runToken + 1 : current.runToken,
      }));
    },
    [update],
  );

  const updateFile = useCallback(
    (path: string, content: string) => {
      update((current) =>
        mapProject(current, (project) => ({
          ...project,
          files: project.files.map((file) => (file.path === path ? { ...file, content } : file)),
        })),
      );
    },
    [update],
  );

  const setActiveFile = useCallback(
    (path: string) => update((current) => mapProject(current, (project) => ({ ...project, activeFile: path }))),
    [update],
  );

  const addFile = useCallback(
    (path: string) => {
      const safe = safeRelPath(path);
      if (!safe) return false;
      let ok = true;
      update((current) =>
        mapProject(current, (project) => {
          if (project.files.some((file) => file.path === safe)) {
            ok = false;
            return { ...project, activeFile: safe };
          }
          return { ...project, files: [...project.files, { path: safe, content: "" }], activeFile: safe };
        }),
      );
      return ok;
    },
    [update],
  );

  const deleteFile = useCallback(
    (path: string) => {
      update((current) =>
        mapProject(current, (project) => {
          if (project.files.length < 2) return project;
          const files = project.files.filter((file) => file.path !== path);
          return {
            ...project,
            files,
            activeFile: project.activeFile === path ? files[0].path : project.activeFile,
          };
        }),
      );
    },
    [update],
  );

  return {
    ready,
    booted,
    state,
    project: activeProject(state),
    update,
    newChat,
    selectChat,
    newProject,
    selectProject,
    deleteProject,
    setTheme,
    setPalette,
    addRule,
    removeRule,
    setPanel,
    setSidebarCollapsed,
    setArtifactsOpen,
    remember,
    removeFact,
    editFact,
    clearFacts,
    clearChats,
    showArtifact,
    loadWorkspace,
    updateFile,
    setActiveFile,
    addFile,
    deleteFile,
  };
}
