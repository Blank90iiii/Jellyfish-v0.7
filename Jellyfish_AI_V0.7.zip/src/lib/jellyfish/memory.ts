function clean(value: string): string {
  return value.replace(/[.!\s]+$/g, "").replace(/\s+/g, " ").trim().slice(0, 200);
}

/** Pull durable facts out of a user message so they survive long coding turns. */
export function extractFacts(input: string): string[] {
  const text = input.trim();
  if (!text) return [];
  const found: string[] = [];
  const remember = text.match(/\bremember(?:\s+that)?\s+(.{3,180})/i);
  if (remember) {
    const line = clean(remember[1]);
    if (line) found.push(line);
  }
  const color = text.match(/\bfavou?rite\s+color\s+is\s+([^.!\n,]{2,40})/i);
  if (color) {
    const line = clean(color[1]);
    if (line) found.push(`Favorite color is ${line}`);
  }
  const name = text.match(/\bmy name is\s+([A-Za-z][\w .'-]{0,40})/i);
  if (name) {
    const line = clean(name[1]);
    if (line) found.push(`Name is ${line}`);
  }
  const seen = new Set<string>();
  return found.filter((fact) => {
    const key = fact.toLowerCase();
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}
