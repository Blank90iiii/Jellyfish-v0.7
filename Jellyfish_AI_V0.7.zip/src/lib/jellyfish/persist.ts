import { sanitize, slimState, type JellyfishState } from "./model";

const DB_NAME = "jellyfish";
const STORE = "kv";
const IDB_KEY = "state";
const LS_KEY = "jellyfish.v6";
const LS_V5 = "jellyfish.v5";
const LS_THEME = "jellyfish.theme";
const LS_V1 = "jellyfish.v1";

type Envelope = { savedAt: number; state: JellyfishState };

function unwrap(raw: unknown, savedAt = 0): Envelope | null {
  if (!raw || typeof raw !== "object") return null;
  const row = raw as { savedAt?: unknown; state?: unknown };
  if (row.state && typeof row.state === "object") {
    return {
      savedAt: typeof row.savedAt === "number" ? row.savedAt : savedAt,
      state: sanitize(row.state),
    };
  }
  return { savedAt, state: sanitize(raw) };
}

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 2);
    request.onupgradeneeded = () => {
      if (!request.result.objectStoreNames.contains(STORE)) request.result.createObjectStore(STORE);
      if (!request.result.objectStoreNames.contains("lessons")) request.result.createObjectStore("lessons");
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export { openDb };

async function idbGet(): Promise<Envelope | null> {
  if (typeof indexedDB === "undefined") return null;
  try {
    const db = await openDb();
    return await new Promise((resolve) => {
      const tx = db.transaction(STORE, "readonly");
      const request = tx.objectStore(STORE).get(IDB_KEY);
      request.onsuccess = () => resolve(unwrap(request.result));
      request.onerror = () => resolve(null);
    });
  } catch {
    return null;
  }
}

async function idbSet(envelope: Envelope): Promise<void> {
  if (typeof indexedDB === "undefined") return;
  try {
    const db = await openDb();
    await new Promise<void>((resolve) => {
      const tx = db.transaction(STORE, "readwrite");
      tx.objectStore(STORE).put(envelope, IDB_KEY);
      tx.oncomplete = () => resolve();
      tx.onerror = () => resolve();
    });
  } catch {
    /* private mode or a full disk — localStorage still tried */
  }
}

function withTimeout<T>(promise: Promise<T>, ms: number): Promise<T | null> {
  return new Promise((resolve) => {
    const timer = setTimeout(() => resolve(null), ms);
    promise.then(
      (value) => {
        clearTimeout(timer);
        resolve(value);
      },
      () => {
        clearTimeout(timer);
        resolve(null);
      },
    );
  });
}

function readLocal(key: string): Envelope | null {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return null;
    return unwrap(JSON.parse(raw));
  } catch {
    return null;
  }
}

function writeLocal(key: string, envelope: Envelope): boolean {
  try {
    localStorage.setItem(key, JSON.stringify(envelope));
    localStorage.setItem(LS_THEME, envelope.state.theme);
    return true;
  } catch {
    return false;
  }
}

export function loadStateSync(): JellyfishState | null {
  if (typeof localStorage === "undefined") return null;
  return (readLocal(LS_KEY) || readLocal(LS_V5) || readLocal(LS_V1))?.state ?? null;
}

export async function loadState(): Promise<JellyfishState> {
  const local = readLocal(LS_KEY) || readLocal(LS_V5) || readLocal(LS_V1);
  const idb = await withTimeout(idbGet(), 800);
  if (idb && local) return (idb.savedAt >= local.savedAt ? idb : local).state;
  if (idb) return idb.state;
  if (local) return local.state;
  return sanitize(null);
}

export async function saveState(state: JellyfishState): Promise<void> {
  const envelope: Envelope = { savedAt: Date.now(), state };
  await idbSet(envelope);
  if (writeLocal(LS_KEY, envelope)) return;
  writeLocal(LS_KEY, { savedAt: envelope.savedAt, state: slimState(state) });
}
