import { parseMessage } from "./parse.ts";

export type ModelTurn = { role: "user" | "assistant"; content: string };

function summarize(content: string): string {
  const parsed = parseMessage(content, false);
  let text = parsed.text;
  if (parsed.project) {
    const names = parsed.project.files.map((file) => file.path).join(", ");
    text = `${text}\n[Project ${parsed.project.name}: ${names}]`.trim();
  }
  if (parsed.remembers.length) {
    text = `${text}\n[Remembered: ${parsed.remembers.join("; ")}]`.trim();
  }
  return text.replace(/\n{3,}/g, "\n\n").trim();
}

/**
 * Keep pinned facts out of the message pile, and replace earlier project
 * source with a one-line file list so a long coding session cannot crowd
 * memory out of the request.
 */
export function compactHistory(messages: ModelTurn[]): ModelTurn[] {
  const recent = messages.slice(-12);
  return recent.map((message, index) => {
    const last = index === recent.length - 1;
    if (last && message.role === "user") {
      return { role: message.role, content: message.content.slice(0, 12000) };
    }
    const content = summarize(message.content).slice(0, 1200);
    return { role: message.role, content: content || "(empty)" };
  });
}
