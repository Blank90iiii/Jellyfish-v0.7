export type BuildConfig = { checkpoints: boolean; verify: boolean };

const KEY = "jellyfish.build";
export const DEFAULT_BUILD: BuildConfig = { checkpoints: true, verify: true };

export function loadBuild(): BuildConfig {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return DEFAULT_BUILD;
    const data = JSON.parse(raw) as Partial<BuildConfig>;
    return { checkpoints: data.checkpoints !== false, verify: data.verify !== false };
  } catch {
    return DEFAULT_BUILD;
  }
}

export function saveBuild(config: BuildConfig) {
  try {
    localStorage.setItem(KEY, JSON.stringify(config));
  } catch {
    /* ignore */
  }
}
