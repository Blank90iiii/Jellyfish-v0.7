import type { ToolsConfig } from "./toolsconfig";

type Reply = { ok?: boolean; text?: string; error?: string };

async function post(path: string, body: unknown, signal?: AbortSignal): Promise<Reply> {
  try {
    const response = await fetch(path, { method: "POST", headers: { "content-type": "application/json" }, signal, body: JSON.stringify(body) });
    return (await response.json()) as Reply;
  } catch (error) {
    if (error instanceof DOMException && error.name === "AbortError") throw error;
    return { ok: false, error: "Couldn't reach the Jellyfish server." };
  }
}

export async function webTool(op: "search" | "news" | "read", arg: string, cfg: ToolsConfig, signal?: AbortSignal): Promise<string> {
  const body = op === "read" ? { op, url: arg } : { op, q: arg, provider: cfg.search };
  const reply = await post("/api/web", body, signal);
  return reply.ok ? (reply.text ?? "") : `Error: ${reply.error ?? "failed"}`;
}

type RunReply = Reply & { code?: number | null; stdout?: string; stderr?: string; timedOut?: boolean; changed?: { path: string; content: string }[] };

export async function runTool(
  command: string,
  projectId: string,
  files: { path: string; content: string }[],
  signal?: AbortSignal,
): Promise<{ text: string; changed: { path: string; content: string }[] }> {
  const reply = (await post("/api/run", { command, projectId, files }, signal)) as RunReply;
  if (!reply.ok) return { text: `Error: ${reply.error ?? "failed"}`, changed: [] };
  const parts = [`exit code: ${reply.code ?? "none"}${reply.timedOut ? " (stopped after 60 seconds)" : ""}`];
  if (reply.stdout?.trim()) parts.push(`stdout:\n${reply.stdout.trim()}`);
  if (reply.stderr?.trim()) parts.push(`stderr:\n${reply.stderr.trim()}`);
  const changed = reply.changed ?? [];
  if (changed.length) parts.push(`files changed or created: ${changed.map((file) => file.path).join(", ")}`);
  return { text: parts.join("\n"), changed };
}
