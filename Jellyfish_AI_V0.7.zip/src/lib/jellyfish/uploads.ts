import type { Attachment } from "./model";

export const MAX_BYTES = 10 * 1024 * 1024;

const TEXT_EXT = /\.(txt|md|json|js|mjs|cjs|ts|tsx|jsx|css|html|htm|csv|svg|xml|py|yml|yaml)$/i;

function shrinkImage(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const image = new Image();
    image.onload = () => {
      const scale = Math.min(1, 1280 / Math.max(image.width, image.height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.max(1, Math.round(image.width * scale));
      canvas.height = Math.max(1, Math.round(image.height * scale));
      const ctx = canvas.getContext("2d");
      if (!ctx) {
        URL.revokeObjectURL(url);
        reject(new Error("canvas"));
        return;
      }
      ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
      URL.revokeObjectURL(url);
      resolve(canvas.toDataURL("image/jpeg", 0.82));
    };
    image.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("image"));
    };
    image.src = url;
  });
}

async function readTextFile(file: File): Promise<Attachment> {
  const whole = await file.text();
  const text = whole.slice(0, 20_000);
  const full = whole.length > 20_000 ? whole.slice(0, 1_500_000) : undefined;
  return { id: crypto.randomUUID(), name: file.name.slice(0, 80), kind: "text", text, full };
}

async function readZip(file: File): Promise<Attachment> {
  const { default: JSZip } = await import("jszip");
  const zip = await JSZip.loadAsync(file);
  const chunks: string[] = [];
  const names = Object.keys(zip.files).filter((name) => !zip.files[name].dir && TEXT_EXT.test(name)).slice(0, 10);
  for (const name of names) {
    const body = (await zip.files[name].async("string")).slice(0, 8_000);
    chunks.push(`--- ${name} ---\n${body}`);
    if (chunks.join("\n").length > 20_000) break;
  }
  const text = chunks.join("\n\n").slice(0, 20_000) || "(No readable text files in that zip.)";
  return { id: crypto.randomUUID(), name: file.name.slice(0, 80), kind: "zip", text };
}

export async function readUpload(file: File): Promise<{ attachment?: Attachment; error?: string }> {
  if (file.size > MAX_BYTES) return { error: `${file.name} is over 10MB.` };
  if (file.type.startsWith("image/")) {
    try {
      const dataUrl = await shrinkImage(file);
      return { attachment: { id: crypto.randomUUID(), name: file.name.slice(0, 80), kind: "image", dataUrl } };
    } catch {
      return { error: `Couldn't read ${file.name}.` };
    }
  }
  if (file.name.toLowerCase().endsWith(".zip") || file.type === "application/zip") {
    try {
      return { attachment: await readZip(file) };
    } catch {
      return { error: `Couldn't open ${file.name}.` };
    }
  }
  if (file.type.startsWith("text/") || TEXT_EXT.test(file.name) || file.type === "") {
    return { attachment: await readTextFile(file) };
  }
  return { error: `${file.name} isn't an image, zip, or text file.` };
}
