import type { CheckRound } from "./verify";
import { safeRelPath, type ProjectFile } from "./parse.ts";
import { blankProject } from "./projects.ts";

export type Role = "user" | "assistant";

export type AttachmentKind = "image" | "text" | "zip";

export type Attachment = {
  id: string;
  name: string;
  kind: AttachmentKind;
  dataUrl?: string;
  text?: string;
  /** Whole text of a big file, kept only until it is sent. Never saved with the chat. */
  full?: string;
};

export type ChatMessage = {
  id: string;
  role: Role;
  text: string;
  imageUrl?: string;
  pending?: boolean;
  attachments?: Attachment[];
  /** Rounds of "run it, look at it, compare to the request", with small screenshots. */
  checks?: CheckRound[];
};

export type Chat = {
  id: string;
  title: string;
  messages: ChatMessage[];
};

export type Artifact = {
  name: string;
  files: ProjectFile[];
};

export type ProjectSpace = {
  id: string;
  name: string;
  chats: Chat[];
  activeChatId: string;
  files: ProjectFile[];
  activeFile: string;
  artifact: Artifact | null;
};

export type Panel = "chat" | "code" | "lab";

export const DEFAULT_PRIMARY = "#E88D72";
export const DEFAULT_SECONDARY = "#C9A394";

/** A question typed while a build is running. It is answered between build steps. */
export type SidecarItem = { id: string; text: string };

export type JellyfishState = {
  projects: ProjectSpace[];
  activeProjectId: string;
  facts: string[];
  rules: string[];
  primary: string;
  secondary: string;
  theme: "dark" | "light";
  panel: Panel;
  sidebarCollapsed: boolean;
  artifactsOpen: boolean;
  runToken: number;
  /** Waiting side questions. Never restored from disk: a reload starts with an empty queue. */
  sidecarQueue: SidecarItem[];
};

type Legacy = {
  chats?: Chat[];
  activeId?: string;
  facts?: string[];
  rules?: string[];
  primary?: string;
  secondary?: string;
  theme?: string;
  view?: string;
  files?: ProjectFile[];
  activeFile?: string;
};

export function applyPalette(primary: string, secondary: string) {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  const nextPrimary = cleanHex(primary, DEFAULT_PRIMARY);
  const nextSecondary = cleanHex(secondary, DEFAULT_SECONDARY);
  root.style.setProperty("--jf-primary", nextPrimary);
  root.style.setProperty("--jf-secondary", nextSecondary);
  root.style.setProperty("--jf-accent", nextPrimary);
  root.style.setProperty("--jf-cute", nextPrimary);
}

export function freshChat(): Chat {
  return { id: crypto.randomUUID(), title: "New chat", messages: [] };
}

export function makeProject(name: string, chats?: Chat[], files?: ProjectFile[]): ProjectSpace {
  const readyChats = chats?.length ? chats : [freshChat()];
  const blank = blankProject();
  const readyFiles = files?.length ? files : blank.files;
  return {
    id: crypto.randomUUID(),
    name: name.slice(0, 40) || "Workspace",
    chats: readyChats,
    activeChatId: readyChats[0].id,
    files: readyFiles,
    activeFile: readyFiles.some((file) => file.path === "index.html") ? "index.html" : readyFiles[0].path,
    artifact: null,
  };
}

export function initialState(): JellyfishState {
  const project = makeProject("Workspace");
  return {
    projects: [project],
    activeProjectId: project.id,
    facts: [],
    rules: [],
    primary: DEFAULT_PRIMARY,
    secondary: DEFAULT_SECONDARY,
    theme: "dark",
    panel: "chat",
    sidebarCollapsed: false,
    artifactsOpen: false,
    runToken: 0,
    sidecarQueue: [],
  };
}

function cleanFiles(input: unknown): ProjectFile[] {
  if (!Array.isArray(input)) return [];
  const files: ProjectFile[] = [];
  for (const file of input) {
    if (!file || typeof file !== "object") continue;
    const row = file as { path?: unknown; content?: unknown };
    if (typeof row.content !== "string") continue;
    const path = safeRelPath(String(row.path || ""));
    if (!path) continue;
    files.push({ path, content: row.content.slice(0, 200_000) });
    if (files.length >= 24) break;
  }
  return files;
}

function cleanChats(input: unknown): Chat[] {
  if (!Array.isArray(input)) return [];
  const chats: Chat[] = [];
  for (const chat of input) {
    if (!chat || typeof chat !== "object") continue;
    const row = chat as Partial<Chat>;
    if (typeof row.id !== "string" || !Array.isArray(row.messages)) continue;
    const messages: ChatMessage[] = [];
    for (const message of row.messages) {
      if (!message || (message.role !== "user" && message.role !== "assistant")) continue;
      if (typeof message.text !== "string") continue;
      messages.push({
        id: typeof message.id === "string" ? message.id : crypto.randomUUID(),
        role: message.role,
        text: message.text.slice(0, 80_000),
        imageUrl:
          typeof message.imageUrl === "string" &&
          (message.imageUrl.startsWith("http") || message.imageUrl.startsWith("data:image/"))
            ? message.imageUrl
            : undefined,
        attachments: cleanAttachments((message as { attachments?: unknown }).attachments),
        checks: cleanChecks((message as { checks?: unknown }).checks),
      });
    }
    chats.push({
      id: row.id,
      title: typeof row.title === "string" && row.title ? row.title.slice(0, 48) : "New chat",
      messages: messages.slice(-80),
    });
    if (chats.length >= 30) break;
  }
  return chats;
}

function cleanChecks(input: unknown): CheckRound[] | undefined {
  if (!Array.isArray(input)) return undefined;
  const rounds: CheckRound[] = [];
  for (const row of input.slice(0, 8)) {
    const round = row as Partial<CheckRound>;
    if (!round || typeof round.label !== "string" || !Array.isArray(round.items)) continue;
    rounds.push({
      label: round.label.slice(0, 80),
      shot: typeof round.shot === "string" && round.shot.startsWith("data:image/") && round.shot.length < 150_000 ? round.shot : undefined,
      errors: Array.isArray(round.errors) ? round.errors.filter((e): e is string => typeof e === "string").slice(0, 3).map((e) => e.slice(0, 200)) : [],
      items: round.items
        .filter((item) => item && typeof item.text === "string" && (item.status === "pass" || item.status === "fail" || item.status === "unsure"))
        .slice(0, 12)
        .map((item) => ({ text: item.text.slice(0, 140), status: item.status, note: typeof item.note === "string" ? item.note.slice(0, 140) : "", auto: item.auto === true })),
    });
  }
  return rounds.length ? rounds : undefined;
}

function cleanAttachments(input: unknown): Attachment[] | undefined {
  if (!Array.isArray(input)) return undefined;
  const items: Attachment[] = [];
  for (const item of input) {
    if (!item || typeof item !== "object") continue;
    const row = item as Partial<Attachment>;
    if (row.kind !== "image" && row.kind !== "text" && row.kind !== "zip") continue;
    if (typeof row.name !== "string" || !row.name.trim()) continue;
    const dataUrl =
      typeof row.dataUrl === "string" && row.dataUrl.startsWith("data:image/") && row.dataUrl.length < 1_500_000
        ? row.dataUrl
        : undefined;
    const text = typeof row.text === "string" ? row.text.slice(0, 20_000) : undefined;
    items.push({
      id: typeof row.id === "string" ? row.id : crypto.randomUUID(),
      name: row.name.slice(0, 80),
      kind: row.kind,
      dataUrl,
      text,
    });
    if (items.length >= 6) break;
  }
  return items.length ? items : undefined;
}

export function cleanRules(input: unknown): string[] {
  if (!Array.isArray(input)) return [];
  const rules: string[] = [];
  for (const rule of input) {
    if (typeof rule !== "string") continue;
    const line = rule.trim().slice(0, 240);
    if (!line) continue;
    if (rules.some((item) => item.toLowerCase() === line.toLowerCase())) continue;
    rules.push(line);
    if (rules.length >= 40) break;
  }
  return rules;
}

export function cleanHex(input: unknown, fallback: string): string {
  if (typeof input !== "string") return fallback;
  const value = input.trim();
  return /^#[0-9a-fA-F]{6}$/.test(value) ? value.toUpperCase() : fallback;
}

function cleanFacts(input: unknown): string[] {
  if (!Array.isArray(input)) return [];
  const facts: string[] = [];
  for (const fact of input) {
    if (typeof fact !== "string") continue;
    const line = fact.trim().slice(0, 200);
    if (!line) continue;
    if (facts.some((item) => item.toLowerCase() === line.toLowerCase())) continue;
    facts.push(line);
    if (facts.length >= 40) break;
  }
  return facts;
}

function asProject(raw: unknown, fallbackName: string): ProjectSpace | null {
  if (!raw || typeof raw !== "object") return null;
  const row = raw as Partial<ProjectSpace>;
  if (typeof row.id !== "string") return null;
  const chats = cleanChats(row.chats);
  const readyChats = chats.length ? chats : [freshChat()];
  const files = cleanFiles(row.files);
  const blank = blankProject();
  const readyFiles = files.length ? files : blank.files;
  const activeChatId = readyChats.some((chat) => chat.id === row.activeChatId)
    ? (row.activeChatId as string)
    : readyChats[0].id;
  const activeFile = readyFiles.some((file) => file.path === row.activeFile)
    ? (row.activeFile as string)
    : readyFiles[0].path;
  let artifact: Artifact | null = null;
  if (row.artifact && typeof row.artifact === "object") {
    const art = row.artifact as Artifact;
    const artFiles = cleanFiles(art.files);
    if (artFiles.length && typeof art.name === "string") {
      artifact = { name: art.name.slice(0, 40) || "project", files: artFiles };
    }
  }
  return {
    id: row.id,
    name: typeof row.name === "string" && row.name.trim() ? row.name.trim().slice(0, 40) : fallbackName,
    chats: readyChats,
    activeChatId,
    files: readyFiles,
    activeFile,
    artifact,
  };
}

export function fromLegacy(raw: Legacy): JellyfishState {
  const base = initialState();
  const chats = cleanChats(raw.chats);
  const files = cleanFiles(raw.files);
  const project = makeProject("Workspace", chats.length ? chats : undefined, files.length ? files : undefined);
  if (typeof raw.activeId === "string" && project.chats.some((chat) => chat.id === raw.activeId)) {
    project.activeChatId = raw.activeId;
  }
  if (typeof raw.activeFile === "string" && project.files.some((file) => file.path === raw.activeFile)) {
    project.activeFile = raw.activeFile;
  }
  return {
    ...base,
    projects: [project],
    activeProjectId: project.id,
    facts: cleanFacts(raw.facts),
    rules: cleanRules(raw.rules),
    primary: cleanHex(raw.primary, DEFAULT_PRIMARY),
    secondary: cleanHex(raw.secondary, DEFAULT_SECONDARY),
    theme: raw.theme === "light" ? "light" : "dark",
    panel: raw.view === "ide" ? "code" : "chat",
  };
}

export function sanitize(raw: unknown): JellyfishState {
  const base = initialState();
  if (!raw || typeof raw !== "object") return base;
  const data = raw as Partial<JellyfishState> & Legacy;
  if (!Array.isArray(data.projects)) return fromLegacy(data);
  const projects = data.projects
    .map((project, index) => asProject(project, `Project ${index + 1}`))
    .filter((project): project is ProjectSpace => !!project)
    .slice(0, 20);
  if (!projects.length) {
    return {
      ...base,
      facts: cleanFacts(data.facts),
      rules: cleanRules(data.rules),
      primary: cleanHex(data.primary, DEFAULT_PRIMARY),
      secondary: cleanHex(data.secondary, DEFAULT_SECONDARY),
      theme: data.theme === "light" ? "light" : "dark",
    };
  }
  const activeProjectId = projects.some((project) => project.id === data.activeProjectId)
    ? (data.activeProjectId as string)
    : projects[0].id;
  return {
    projects,
    activeProjectId,
    facts: cleanFacts(data.facts),
    rules: cleanRules(data.rules),
    primary: cleanHex(data.primary, DEFAULT_PRIMARY),
    secondary: cleanHex(data.secondary, DEFAULT_SECONDARY),
    theme: data.theme === "light" ? "light" : "dark",
    panel: data.panel === "code" ? "code" : data.panel === "lab" ? "lab" : "chat",
    sidebarCollapsed: data.sidebarCollapsed === true,
    artifactsOpen: data.artifactsOpen === true,
    runToken: 0,
    sidecarQueue: [],
  };
}

export function activeProject(state: JellyfishState): ProjectSpace {
  return state.projects.find((project) => project.id === state.activeProjectId) ?? state.projects[0];
}

export function stripPending(state: JellyfishState): JellyfishState {
  return {
    ...state,
    runToken: 0,
    sidecarQueue: [],
    projects: state.projects.map((project) => ({
      ...project,
      chats: project.chats.map((chat) => ({
        ...chat,
        messages: chat.messages.map((message) => ({ ...message, pending: undefined })),
      })),
    })),
  };
}

/** Smaller copy for localStorage when the full snapshot does not fit. */
export function slimState(state: JellyfishState): JellyfishState {
  return {
    ...stripPending(state),
    projects: state.projects.slice(0, 12).map((project) => ({
      ...project,
      chats: project.chats.slice(0, 12).map((chat) => ({
        ...chat,
        messages: chat.messages.slice(-15).map((message) => ({
          ...message,
          imageUrl: undefined,
          pending: undefined,
          attachments: message.attachments?.map((item) => ({ ...item, dataUrl: undefined })),
          checks: message.checks?.map((round) => ({ ...round, shot: undefined })),
        })),
      })),
    })),
  };
}
