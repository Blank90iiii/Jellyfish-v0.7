/** How often Jellyfish asks before acting. Running a terminal command ALWAYS asks, whatever this says. */
export type ApprovalMode = "important" | "every";

const KEY = "jellyfish.approval";

export function loadApproval(): ApprovalMode {
  try {
    return localStorage.getItem(KEY) === "every" ? "every" : "important";
  } catch {
    return "important";
  }
}

export function saveApproval(mode: ApprovalMode) {
  try {
    localStorage.setItem(KEY, mode);
  } catch {
    /* ignore */
  }
}
