/** The sidecar queue: questions typed while a build runs. Pure helpers, no React, no storage. */
import type { SidecarItem } from "./model.ts";

export const SIDECAR_MAX = 5;
export const SIDECAR_TEXT_MAX = 500;

export type EnqueueResult = { queue: SidecarItem[]; accepted: boolean; note: string };

/** Adds a question to the end of the queue (at most SIDECAR_MAX waiting, each at most SIDECAR_TEXT_MAX characters). */
export function enqueueSidecar(queue: SidecarItem[], text: string, id: string): EnqueueResult {
  const clean = text.trim().slice(0, SIDECAR_TEXT_MAX);
  if (!clean) return { queue, accepted: false, note: "Type a question first." };
  if (queue.length >= SIDECAR_MAX) return { queue, accepted: false, note: `${SIDECAR_MAX} questions are already waiting.` };
  return { queue: [...queue, { id, text: clean }], accepted: true, note: "Queued. It is answered between build steps." };
}

/** Takes the first waiting question off the queue. */
export function dequeueSidecar(queue: SidecarItem[]): { item: SidecarItem | null; rest: SidecarItem[] } {
  if (!queue.length) return { item: null, rest: queue };
  return { item: queue[0], rest: queue.slice(1) };
}
