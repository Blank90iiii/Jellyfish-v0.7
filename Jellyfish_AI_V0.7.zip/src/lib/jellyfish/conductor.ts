/**
 * The Conductor: plain code that decides what happens and in what order. There is no AI in the middle.
 * The model only writes and judges text when the Conductor asks it to; everything else (routing, testing,
 * retry limits, stopping, asking you) is deterministic and unit tested.
 */
import { parseMessage, type Project, type ProjectFile } from "./parse.ts";
import type { Turn } from "./router.ts";
import type { Phase } from "./telemetry.ts";
import {
  autoChecks,
  checkPrompt,
  fixPrompt,
  formatInspection,
  looksLikeBuild,
  parseChecks,
  REST_PROMPT,
  type CheckRound,
  type Inspection,
  type Scope,
} from "./verify.ts";

export const MAX_FIX_ATTEMPTS = 5;
export const VERIFY_ROUNDS = 3;

// ---------- routing ----------

export type Intent = "build" | "change" | "explain" | "image" | "chat";
export type Route = { intent: Intent; plan: boolean; checkpoints: boolean; verify: boolean };
export type RouteContext = { hasProject: boolean; planFirst: boolean; imageAsk: boolean; checkpoints: boolean; verify: boolean };

const CHANGE = /\b(fix|change|update|modify|edit|tweak|adjust|add|remove|delete|rename|refactor|make it|make the|make them|doesn'?t work|not working|broken|bug|error|crash)/i;
const FRESH = /\b(new|another|from scratch|start over|different|brand new)\b/i;
const EXPLAIN = /^\s*(what|why|how|when|where|who|explain|define|describe|tell me|can you explain|difference|is it|does)\b/i;

export function route(text: string, ctx: RouteContext): Route {
  const changeLike = ctx.hasProject && CHANGE.test(text) && !FRESH.test(text);
  let intent: Intent = "chat";
  if (ctx.imageAsk) intent = "image";
  else if (looksLikeBuild(text) && !changeLike) intent = "build";
  else if (changeLike) intent = "change";
  else if (EXPLAIN.test(text)) intent = "explain";
  const buildy = intent === "build" || intent === "change";
  const plan = ctx.planFirst && buildy;
  return { intent, plan, checkpoints: ctx.checkpoints && intent === "build" && !plan, verify: ctx.verify && buildy };
}

// ---------- the build pipeline ----------

export type Effects = {
  generate: (turns: Turn[], onDelta: (chunk: string) => void, opts?: { images?: string[]; plain?: boolean }) => Promise<string | null | undefined>;
  probe: (files: ProjectFile[]) => Promise<string[]>;
  inspect: (files: ProjectFile[]) => Promise<Inspection>;
  confirm: (title: string, detail: string) => Promise<boolean>;
  aborted: () => boolean;
  step: (phase: Phase, label: string, detail?: string) => void;
  text: (full: string) => void;
  checks: (rounds: CheckRound[]) => void;
  lesson: (note: string) => void;
  log: (note: string) => void;
  /**
   * Called at the boundary between build steps (before each test run and each round of checks).
   * The app uses it to answer one waiting side question, then the build carries on.
   */
  between?: () => Promise<void>;
};

export type BuildInput = {
  request: string;
  history: Turn[];
  full: string;
  project: Project;
  checkpointed: boolean;
  verify: boolean;
  canSee: boolean;
  approveEveryStep: boolean;
  /** Fixed requirements to judge against (used by the eval runner). Otherwise the model writes them. */
  requirements?: string[];
  fixLimit?: number;
  verifyRounds?: number;
};

export type BuildResult = {
  full: string;
  project: Project;
  checks: CheckRound[];
  stillFailing: string[];
  fixes: number;
  stopped: boolean;
  declined: boolean;
};

export async function runBuild(input: BuildInput, fx: Effects): Promise<BuildResult> {
  const fixLimit = input.fixLimit ?? MAX_FIX_ATTEMPTS;
  const roundLimit = input.verifyRounds ?? VERIFY_ROUNDS;
  const history = input.history;
  let full = input.full;
  let current = input.project;
  let checks: CheckRound[] = [];
  let fixesTotal = 0;
  let declined = false;
  let stillFailing: string[] = [];

  const assistantTurn = (): Turn => ({ role: "assistant", content: full.slice(0, 6000) });
  const stop = () => fx.aborted() || declined;
  const gap = async () => {
    if (!stop() && fx.between) await fx.between();
  };

  const allowed = async (title: string, detail: string) => {
    if (!input.approveEveryStep) return true;
    if (await fx.confirm(title, detail)) return true;
    declined = true;
    full += `\n\n(Stopped by you before: ${title.toLowerCase()})`;
    return false;
  };

  /** Run it, read the console, fix errors. Up to fixLimit tries. */
  const settle = async () => {
    let fixes = 0;
    let firstError = "";
    while (!stop()) {
      await gap();
      if (stop()) return;
      fx.step("running", fixes === 0 ? "Running it" : `Testing fix ${fixes} of ${fixLimit}`);
      const errors = await fx.probe(current.files);
      if (!errors.length) {
        if (fixes > 0) fx.lesson(`Fixed a sandbox error: ${firstError.slice(0, 160)}`);
        return;
      }
      if (!firstError) firstError = errors[0];
      if (fixes >= fixLimit) {
        full += `\n\nStill failing after ${fixes} fixes: ${errors[0]}`;
        return;
      }
      if (!(await allowed("Fix a console error", errors[0].slice(0, 120)))) return;
      fixes += 1;
      fixesTotal += 1;
      fx.log(`fix ${fixes} of ${fixLimit}: ${errors[0].slice(0, 120)}`);
      fx.step("fixing", `Fixing (try ${fixes} of ${fixLimit})`, errors[0].slice(0, 100));
      let repaired = "";
      const error = await fx.generate(
        [
          ...history,
          assistantTurn(),
          {
            role: "user",
            content: `The sandbox console reported:\n${errors.slice(0, 5).join("\n")}\nThis is fix attempt ${fixes} of ${fixLimit}. Rewrite the whole project so that error is gone. Full files only.`,
          },
        ],
        (chunk) => {
          repaired += chunk;
          fx.text(repaired);
        },
      );
      if (error || !repaired.trim()) return;
      const next = parseMessage(repaired, false).project;
      if (!next) return;
      full = repaired;
      current = next;
    }
  };

  await settle();

  if (input.verify && !stop()) {
    const scopes: Scope[] = input.checkpointed ? ["core", "full"] : ["full"];
    for (let s = 0; s < scopes.length && !stop(); s += 1) {
      const scope = scopes[s];
      if (s > 0) {
        if (!(await allowed("Add the rest of the features", "The core works. Next is everything else you asked for."))) break;
        fx.step("extending", "Core works. Adding the rest");
        let more = "";
        const moreError = await fx.generate([...history, assistantTurn(), { role: "user", content: REST_PROMPT }], (chunk) => {
          more += chunk;
          fx.text(more);
        });
        const extended = moreError ? null : parseMessage(more, false).project;
        if (!extended) break;
        full = more;
        current = extended;
        await settle();
      }
      let requirements: string[] | null = input.requirements?.length ? input.requirements : null;
      for (let round = 1; round <= roundLimit && !stop(); round += 1) {
        const label = `${input.checkpointed ? (scope === "core" ? "Checkpoint 1 · core" : "Checkpoint 2 · everything") : "Final check"} · round ${round}`;
        await gap();
        if (stop()) break;
        fx.step("inspecting", `Testing: ${label}`);
        const inspection = await fx.inspect(current.files);
        const report = formatInspection(inspection);
        const useShot = input.canSee && !!inspection.shot;
        fx.step("judging", `Comparing with your request (${label})`);
        let reply = "";
        const checkError = await fx.generate(
          [{ role: "user", content: checkPrompt(input.request, requirements, report, useShot, scope) }],
          (chunk) => {
            reply += chunk;
          },
          { images: useShot ? [inspection.shot as string] : [], plain: true },
        );
        const parsed = checkError ? { items: [], verdict: null } : parseChecks(reply);
        if (!requirements && parsed.items.length) requirements = parsed.items.map((item) => item.text);
        const items = [...autoChecks(inspection), ...parsed.items];
        checks = [...checks, { label, shot: inspection.shot ?? undefined, items, errors: inspection.errors.slice(0, 3) }];
        fx.checks(checks);
        const failed = items.filter((item) => item.status === "fail");
        fx.log(`${label}: ${failed.length} failed of ${items.length}`);
        stillFailing = failed.map((item) => item.text);
        if (!failed.length || round >= roundLimit) break;
        if (!(await allowed("Fix what the test found", failed.map((f) => f.text).join("; ").slice(0, 140)))) break;
        fixesTotal += 1;
        fx.step("fixing", `Fixing what the test found (${label})`, failed[0].text);
        let repaired = "";
        const repairError = await fx.generate([...history, assistantTurn(), { role: "user", content: fixPrompt(failed, report) }], (chunk) => {
          repaired += chunk;
          fx.text(repaired);
        });
        const next = repairError ? null : parseMessage(repaired, false).project;
        if (!next) break;
        full = repaired;
        current = next;
        await settle();
      }
      // A broken core must not get more features piled on top of it.
      if (stillFailing.length && s === 0 && scopes.length > 1) break;
    }
    if (stillFailing.length && !declined) full += `\n\nStill not matching after testing: ${stillFailing.slice(0, 4).join("; ")}.`;
  }

  return { full, project: current, checks, stillFailing, fixes: fixesTotal, stopped: fx.aborted() || declined, declined };
}
