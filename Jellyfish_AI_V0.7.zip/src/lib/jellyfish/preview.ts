import type { ProjectFile } from "./parse";

const BRIDGE = `<script>
window.onerror=function(m,s,l){parent.postMessage({type:"cf-log",msg:String(m)+" (line "+l+")",level:"error",err:true},"*");};
["log","warn","error"].forEach(function(k){
  var old=console[k].bind(console);
  console[k]=function(){
    var msg=Array.prototype.map.call(arguments,function(v){return typeof v==="string"?v:String(v);}).join(" ");
    try{parent.postMessage({type:"cf-log",msg:msg,level:k,err:k==="error"},"*");}catch(e){}
    old.apply(console,arguments);
  };
});
</script>`;

function lookup(map: Map<string, string>, href: string): string | undefined {
  const key = href.replace(/^\.\//, "").split("?")[0];
  return map.get(key);
}

export function buildPreview(files: ProjectFile[]): string {
  const map = new Map(files.map((file) => [file.path, file.content]));
  let html = map.get("index.html");
  if (!html) {
    const first = files[0];
    const body = first
      ? first.content.replace(/&/g, "\u0026amp;").replace(/</g, "\u0026lt;")
      : "Empty workspace";
    html = `<!DOCTYPE html><html><body><pre>${body}</pre></body></html>`;
  }
  // Models often write attributes without quotes (href=css/style.css), so accept both.
  html = html.replace(/<link\b[^>]*?\bhref=(?:"([^"]+)"|'([^']+)'|([^\s>"']+))[^>]*>/gi, (full, a?: string, b?: string, c?: string) => {
    const href = a ?? b ?? c ?? "";
    const css = lookup(map, href);
    if (css == null) return full;
    return `<style>${css.replace(/<\/style/gi, "<\\/style")}</style>`;
  });
  html = html.replace(
    /<script\b[^>]*?\bsrc=(?:"([^"]+)"|'([^']+)'|([^\s>"']+))[^>]*>\s*<\/script>/gi,
    (full, a?: string, b?: string, c?: string) => {
      const src = a ?? b ?? c ?? "";
      const js = lookup(map, src);
      if (js == null) return full;
      return `<script>${js.replace(/<\/script/gi, "<\\/script")}</script>`;
    },
  );
  if (/<head[^>]*>/i.test(html)) html = html.replace(/<head[^>]*>/i, (tag) => tag + BRIDGE);
  else html = BRIDGE + html;
  return html;
}
