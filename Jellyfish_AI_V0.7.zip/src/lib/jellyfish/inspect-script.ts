/**
 * Script that runs INSIDE the sandboxed preview. It looks at the running page the way a tester would:
 * what is on screen, whether it moves, whether it reacts to keys and clicks, then takes a small picture.
 * The result goes to the parent as one "cf-inspect" message.
 */
export function inspectScript(htmlToImageSource: string): string {
  const lib = htmlToImageSource.replace(/<\/script/gi, "<\\/script");
  return `<script>${lib}</script><script>(function(){
function wait(ms){return new Promise(function(r){setTimeout(r,ms)})}
function stats(c){try{var o=document.createElement("canvas");o.width=32;o.height=32;var x=o.getContext("2d");x.drawImage(c,0,0,32,32);var d=x.getImageData(0,0,32,32).data,seen={},n=0,h=0,base=d[0]+","+d[1]+","+d[2]+","+d[3],diff=0;
for(var i=0;i<d.length;i+=4){var k=(d[i]>>4)+","+(d[i+1]>>4)+","+(d[i+2]>>4)+","+(d[i+3]>>4);if(!seen[k]){seen[k]=1;n++}if((d[i]+","+d[i+1]+","+d[i+2]+","+d[i+3])!==base)diff++;h=(h*31+d[i]+d[i+1]*3+d[i+2]*7+d[i+3])|0}
return{w:c.width,h:c.height,filled:diff/1024,colors:n,hash:h}}catch(e){return{w:c.width,h:c.height,filled:0,colors:0,hash:0}}}
function snap(){var t="";try{t=document.body?document.body.innerText.replace(/\\s+/g," ").trim():""}catch(e){}
var cs=[].slice.call(document.querySelectorAll("canvas")).slice(0,3).map(stats);
return{text:t,canvases:cs,sig:t+"|"+cs.map(function(c){return c.hash}).join(",")}}
var keys=["ArrowUp","ArrowDown","ArrowLeft","ArrowRight"," ","Enter","w","a","s","d"];
function rnd(n){return Math.floor(Math.random()*n)}
function poke(){try{var k=keys[rnd(keys.length)];var e1=new KeyboardEvent("keydown",{key:k,code:k,bubbles:true});document.dispatchEvent(e1);window.dispatchEvent(e1);
var e2=new KeyboardEvent("keyup",{key:k,code:k,bubbles:true});document.dispatchEvent(e2);window.dispatchEvent(e2);
var x=rnd(innerWidth),y=rnd(innerHeight),t=document.elementFromPoint(x,y)||document.body;
["mousemove","mousedown","mouseup","click"].forEach(function(n){t.dispatchEvent(new MouseEvent(n,{clientX:x,clientY:y,bubbles:true}))})}catch(e){}}
async function run(){
var out={title:document.title||"",text:"",canvases:[],buttons:[],inputs:0,images:0,animates:null,reactsToInput:null,overflowX:false,shot:null};
await wait(500);
var a=snap();
await wait(700);
var b=snap();
out.animates=a.sig!==b.sig;
[].slice.call(document.querySelectorAll("button,[role=button],input[type=button],input[type=submit]")).slice(0,6).forEach(function(el){try{el.click()}catch(e){}});
for(var i=0;i<40;i++){poke();await wait(30)}
var c=snap();
var textChanged=b.text!==c.text;
if(out.animates){out.reactsToInput=textChanged?true:null}else{out.reactsToInput=(b.sig!==c.sig)}
out.text=c.text.slice(0,400);out.canvases=c.canvases.map(function(x){return{w:x.w,h:x.h,filled:Math.round(x.filled*100)/100,colors:x.colors}});
out.buttons=[].slice.call(document.querySelectorAll("button,[role=button],input[type=button],input[type=submit]")).map(function(el){return(el.innerText||el.value||el.getAttribute("aria-label")||"").trim()}).filter(Boolean).slice(0,12);
out.inputs=document.querySelectorAll("input,textarea,select").length;
out.images=document.images.length;
out.overflowX=document.documentElement.scrollWidth>innerWidth+4;
try{if(window.htmlToImage){out.shot=await Promise.race([htmlToImage.toJpeg(document.documentElement,{quality:0.6,pixelRatio:0.6,width:innerWidth,height:innerHeight,backgroundColor:"#ffffff",skipFonts:true}),wait(4000).then(function(){return null})])}}catch(e){}
parent.postMessage({type:"cf-inspect",report:out},"*")}
function go(){run().catch(function(e){parent.postMessage({type:"cf-inspect",report:{error:String(e)}},"*")})}
if(document.readyState==="complete")go();else window.addEventListener("load",go)
})();</script>`;
}
