let ctx: AudioContext | null = null;

function context(): AudioContext | null {
  if (typeof window === "undefined") return null;
  const Ctor = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!Ctor) return null;
  if (!ctx) ctx = new Ctor();
  if (ctx.state === "suspended") void ctx.resume();
  return ctx;
}

/** Short synthesized tone. No audio files. */
export function tone(freq: number, dur = 0.09, type: OscillatorType = "square", gainAmount = 0.06) {
  const audio = context();
  if (!audio) return;
  const osc = audio.createOscillator();
  const gain = audio.createGain();
  osc.type = type;
  osc.frequency.value = freq;
  const now = audio.currentTime;
  gain.gain.setValueAtTime(gainAmount, now);
  gain.gain.exponentialRampToValueAtTime(0.0001, now + dur);
  osc.connect(gain);
  gain.connect(audio.destination);
  osc.start(now);
  osc.stop(now + dur + 0.02);
}

export function breakSound() {
  tone(140, 0.08, "sawtooth", 0.05);
  tone(90, 0.12, "square", 0.03);
}

export function placeSound() {
  tone(520, 0.07, "triangle", 0.05);
  tone(780, 0.09, "sine", 0.03);
}
