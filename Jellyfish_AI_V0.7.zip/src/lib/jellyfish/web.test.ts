import assert from "node:assert/strict";
import { test } from "node:test";
import { formatHits, htmlToText, isPrivateHost, parseBrave, parseDuckDuckGo, parseRss, parseSearx, publicUrl } from "./web.ts";
import { parseTools, stripTools, toolsPrompt, wrapResult } from "./tools.ts";

test("htmlToText drops scripts and menus and decodes entities", () => {
  const text = htmlToText("<html><head><style>a{}</style></head><body><nav>MENU</nav><script>evil()</script><h1>Title &amp; more</h1><p>Hello&nbsp;world</p></body></html>");
  assert.ok(text.includes("Title & more"));
  assert.ok(text.includes("Hello world"));
  assert.ok(!text.includes("MENU") && !text.includes("evil"));
});

test("DuckDuckGo results are unwrapped to the real link", () => {
  const html = `<a class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fexample.com%2Fa&rut=x">Example &amp; A</a><a class="result__snippet" href="x">A <b>snippet</b></a>`;
  const hits = parseDuckDuckGo(html);
  assert.deepEqual(hits, [{ title: "Example & A", url: "https://example.com/a", snippet: "A snippet" }]);
});

test("RSS, Brave and SearXNG results parse", () => {
  const rss = `<rss><channel><item><title><![CDATA[Big news]]></title><link>https://news.example/1</link><pubDate>Mon, 09 Nov 2026</pubDate><description>&lt;p&gt;Summary&lt;/p&gt;</description></item></channel></rss>`;
  assert.equal(parseRss(rss)[0].title, "Big news");
  assert.equal(parseRss(rss)[0].url, "https://news.example/1");
  assert.equal(parseBrave({ web: { results: [{ title: "T", url: "https://a.b", description: "d" }, { title: "bad", url: "javascript:x" }] } }).length, 1);
  assert.equal(parseSearx({ results: [{ title: "S", url: "https://s.t", content: "c" }] })[0].snippet, "c");
  assert.ok(formatHits([]).includes("No results"));
});

test("private and local addresses are refused", () => {
  for (const host of ["localhost", "127.0.0.1", "10.0.0.5", "192.168.1.9", "172.20.0.1", "169.254.169.254", "[::1]", "printer.local"]) {
    assert.equal(isPrivateHost(host), true, host);
  }
  assert.equal(isPrivateHost("example.com"), false);
  assert.equal(publicUrl("http://127.0.0.1:8080/x"), null);
  assert.equal(publicUrl("file:///etc/passwd"), null);
  assert.equal(publicUrl("https://user:pw@example.com/"), null);
  assert.ok(publicUrl("https://example.com/path"));
  assert.ok(publicUrl("http://127.0.0.1:8888", true));
});

test("tool blocks are parsed, stripped, and unknown tools are ignored", () => {
  const reply = "Let me check.\n<<<TOOL search\nrust 1.90 release date\n<<<END";
  assert.deepEqual(parseTools(reply), [{ name: "search", arg: "rust 1.90 release date" }]);
  assert.equal(stripTools(reply), "Let me check.");
  assert.deepEqual(parseTools("<<<TOOL hack\nrm -rf\n<<<END"), []);
  assert.deepEqual(parseTools("<<<TOOL test\n<<<END"), [{ name: "test", arg: "" }]);
  assert.equal(stripTools("hi <<<TOOL run\nnpm te"), "hi");
});

test("the tool prompt only lists tools that are switched on", () => {
  assert.equal(toolsPrompt(undefined), "");
  const off = toolsPrompt({ web: false, terminal: false });
  assert.ok(off.includes("- test:") && !off.includes("- search:") && !off.includes("- run:"));
  const on = toolsPrompt({ web: true, terminal: true });
  assert.ok(on.includes("- search:") && on.includes("- run:") && on.includes("approve"));
  assert.ok(wrapResult("read", "https://x.y", "body").includes("<<<DATA"));
});
