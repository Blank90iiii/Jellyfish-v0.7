import assert from "node:assert/strict";
import { test } from "node:test";
import { buildTree, parentFolders } from "./filetree.ts";

test("a flat list of paths becomes folders first, then files, A to Z", () => {
  const tree = buildTree(["js/main.js", "index.html", "css/style.css", "README.md", "js/util/math.js", "css/extra.css"]);
  assert.deepEqual(tree.map((node) => `${node.kind}:${node.name}`), ["folder:css", "folder:js", "file:index.html", "file:README.md"]);
  const css = tree[0];
  assert.equal(css.kind, "folder");
  if (css.kind === "folder") assert.deepEqual(css.children.map((node) => node.name), ["extra.css", "style.css"]);
  const js = tree[1];
  if (js.kind === "folder") {
    assert.deepEqual(js.children.map((node) => `${node.kind}:${node.name}`), ["folder:util", "file:main.js"]);
    assert.equal(js.children[0].path, "js/util");
  }
});

test("duplicates and blanks are ignored, and parent folders are listed", () => {
  assert.equal(buildTree(["a.js", "a.js", "", "  "]).length, 1);
  assert.deepEqual(buildTree([]), []);
  assert.deepEqual(parentFolders("css/a/b.css"), ["css", "css/a"]);
  assert.deepEqual(parentFolders("index.html"), []);
});
