import { baseFor, loadProviders, modelFor, type ProviderId } from "./providers.ts";
import { localSystemPrompt } from "./ollama.ts";
import { PICTURE_HINT, toolsPrompt, type ToolFlags } from "./tools.ts";

export type Turn = { role: "user" | "assistant"; content: string };

type StreamOpts = {
  tools?: ToolFlags;
  messages: Turn[];
  facts: string[];
  rules?: string[];
  lessons: string[];
  search?: boolean;
  images?: string[];
  signal?: AbortSignal;
  onDelta: (chunk: string) => void;
  onCite?: (urls: string[]) => void;
};


function activeBody(extra: Record<string, unknown> = {}) {
  const config = loadProviders();
  const id = config.active;
  return {
    provider: {
      id,
      model: modelFor(config, id),
      apiKey: id === "xai" ? "" : (config.keys[id] ?? ""),
      baseUrl: id === "ollama" ? config.ollamaUrl : baseFor(config, id),
    },
    ...extra,
  };
}

async function readSse(response: Response, onDelta: (chunk: string) => void, onCite?: (urls: string[]) => void) {
  const reader = response.body?.getReader();
  if (!reader) return false;
  const decoder = new TextDecoder();
  let buffer = "";
  let saw = false;
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() ?? "";
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed.startsWith("data:")) continue;
      const data = trimmed.slice(5).trim();
      if (!data) continue;
      let event: { t?: string; c?: string; urls?: string[] };
      try {
        event = JSON.parse(data) as typeof event;
      } catch {
        continue;
      }
      if (event.t === "d" && event.c) {
        saw = true;
        onDelta(event.c);
      }
      if (event.t === "cite" && event.urls?.length) onCite?.(event.urls);
      if (event.t === "err") return false;
    }
  }
  return saw;
}

async function streamOllama(opts: StreamOpts, model: string, baseUrl: string): Promise<string | null> {
  const system = localSystemPrompt(opts.rules ?? [], opts.facts, opts.lessons) + PICTURE_HINT + toolsPrompt(opts.tools);
  const messages: { role: string; content: string; images?: string[] }[] = [
    { role: "system", content: system },
    ...opts.messages.map((message) => ({ role: message.role as string, content: message.content })),
  ];
  // Pictures only help a model that can see. Ollama wants raw base64, not a data URL.
  const pictures = (opts.images ?? []).map((url) => url.replace(/^data:[^,]+,/, "")).filter(Boolean).slice(0, 1);
  if (pictures.length) {
    for (let i = messages.length - 1; i >= 0; i -= 1) {
      if (messages[i].role === "user") {
        messages[i] = { ...messages[i], images: pictures };
        break;
      }
    }
  }
  let response: Response;
  try {
    response = await fetch(`${baseUrl.replace(/\/$/, "")}/api/chat`, {
      method: "POST",
      signal: opts.signal,
      headers: { "content-type": "application/json" },
      // keep_alive -1 keeps the model loaded in memory, so only the first reply pays the load time.
      body: JSON.stringify({ model, messages, stream: true, keep_alive: -1, options: { num_ctx: 8192, temperature: 0.2 } }),
    });
  } catch {
    return "Ollama isn't reachable at that address. Start it on this device and allow this site if it asks.";
  }
  if (!response.ok || !response.body) return `Ollama returned ${response.status}.`;
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let saw = false;
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() ?? "";
    for (const line of lines) {
      if (!line.trim()) continue;
      try {
        const row = JSON.parse(line) as { message?: { content?: string } };
        const chunk = row.message?.content;
        if (chunk) {
          saw = true;
          opts.onDelta(chunk);
        }
      } catch {
        /* partial json */
      }
    }
  }
  return saw ? null : "Ollama sent an empty reply.";
}

/** null means the stream finished with text. A string is a user-facing error. */
export async function streamReply(opts: StreamOpts): Promise<string | null> {
  const config = loadProviders();
  if (config.active === "ollama") {
    return streamOllama(opts, modelFor(config, "ollama"), config.ollamaUrl);
  }
  if (config.active !== "xai" && !(config.keys[config.active] || "").trim()) {
    return `${label(config.active)} needs a key in Settings.`;
  }
  let response: Response;
  try {
    response = await fetch("/api/chat", {
      method: "POST",
      headers: { "content-type": "application/json" },
      signal: opts.signal,
      body: JSON.stringify(
        activeBody({
          messages: opts.messages,
          facts: opts.facts,
          rules: opts.rules ?? [],
          lessons: opts.lessons,
          search: opts.search === true,
          images: opts.images?.slice(0, 1) ?? [],
          tools: opts.tools,
        }),
      ),
    });
  } catch (error) {
    if (error instanceof DOMException && error.name === "AbortError") throw error;
    return "Couldn't reach the brain.";
  }
  if (!response.ok || !response.body) {
    let code = "";
    try {
      const data = (await response.json()) as { error?: string };
      code = data.error ?? "";
    } catch {
      code = "";
    }
    if (response.status === 503) return "offline";
    if (code === "missing key") return "That provider needs a key in Settings.";
    if (response.status === 401 || code === "upstream") return "That provider refused the key or the model name.";
    return "offline";
  }
  const ok = await readSse(response, opts.onDelta, opts.onCite);
  return ok ? null : "offline";
}

function label(id: ProviderId): string {
  if (id === "openai") return "OpenAI";
  if (id === "anthropic") return "Anthropic";
  if (id === "deepseek") return "DeepSeek";
  if (id === "openrouter") return "OpenRouter";
  if (id === "ollama") return "Ollama";
  return "Jellyfish cloud";
}
