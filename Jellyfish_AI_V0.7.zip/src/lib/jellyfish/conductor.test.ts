import assert from "node:assert/strict";
import { test } from "node:test";
import { route, runBuild, type Effects } from "./conductor.ts";
import { beginRun, endRun, getRun, noteCall, stepTo } from "./telemetry.ts";
import type { Inspection } from "./verify.ts";

const base = { hasProject: false, planFirst: false, imageAsk: false, checkpoints: true, verify: true };

test("routing is decided by plain rules", () => {
  assert.equal(route("make me a snake game", base).intent, "build");
  assert.equal(route("make me a snake game", base).checkpoints, true);
  assert.equal(route("what is a closure?", base).intent, "explain");
  assert.equal(route("hello", base).intent, "chat");
  assert.equal(route("draw a logo", { ...base, imageAsk: true }).intent, "image");
  const withProject = { ...base, hasProject: true };
  assert.equal(route("fix the score bug", withProject).intent, "change");
  assert.equal(route("fix the score bug", withProject).checkpoints, false);
  assert.equal(route("make me a new snake game", withProject).intent, "build");
});

test("plan mode only applies to things that build, and replaces checkpoints", () => {
  const planned = route("build a todo app", { ...base, planFirst: true });
  assert.equal(planned.plan, true);
  assert.equal(planned.checkpoints, false);
  assert.equal(route("what is a closure?", { ...base, planFirst: true }).plan, false);
  assert.equal(route("what is a closure?", base).verify, false);
});

const good: Inspection = { errors: [], title: "", text: "Score: 0", canvases: [{ w: 300, h: 200, filled: 0.3, colors: 4 }], buttons: [], inputs: 0, images: 0, animates: true, reactsToInput: true, overflowX: false, shot: null };
const blank: Inspection = { ...good, canvases: [{ w: 300, h: 200, filled: 0, colors: 1 }] };
const project = (js: string) => `<<<PROJECT t\n<<<FILE index.html\n<html><body><script src="js/main.js"></script></body></html>\n<<<FILE js/main.js\n${js}\n<<<END\n`;

function fakeEffects(script: { probes: string[][]; inspections: Inspection[]; replies: string[] }, log: string[], opts?: { confirm?: boolean }): Effects {
  let probe = 0;
  let inspect = 0;
  let reply = 0;
  return {
    generate: async (_turns, onDelta) => {
      const next = script.replies[reply++] ?? "";
      onDelta(next);
      return null;
    },
    probe: async () => script.probes[probe++] ?? [],
    inspect: async () => script.inspections[inspect++] ?? good,
    confirm: async (title) => {
      log.push(`confirm:${title}`);
      return opts?.confirm ?? true;
    },
    aborted: () => false,
    step: (phase) => log.push(`step:${phase}`),
    text: () => {},
    checks: () => {},
    lesson: (note) => log.push(`lesson:${note.slice(0, 20)}`),
    log: () => {},
  };
}

async function start(js: string) {
  const { parseMessage } = await import("./parse.ts");
  const full = project(js);
  return { full, project: parseMessage(full, false).project! };
}

test("a console error is fixed, then the build is judged", async () => {
  const first = await start("oops(");
  const log: string[] = [];
  const fx = fakeEffects(
    {
      probes: [["SyntaxError (line 1)"], []],
      inspections: [good],
      replies: [project("ok()"), "REQ: It runs | PASS | fine\nVERDICT: PASS"],
    },
    log,
  );
  const result = await runBuild({ request: "make a thing", history: [], full: first.full, project: first.project, checkpointed: false, verify: true, canSee: false, approveEveryStep: false }, fx);
  assert.equal(result.fixes, 1);
  assert.equal(result.stillFailing.length, 0);
  assert.equal(result.checks.length, 1);
  assert.ok(log.includes("step:fixing") && log.includes("step:inspecting") && log.some((l) => l.startsWith("lesson:")));
});

test("an empty canvas is caught by the automatic check even if the model says PASS", async () => {
  const first = await start("var x=1");
  const fx = fakeEffects(
    {
      probes: [[], []],
      inspections: [blank, good],
      replies: ["REQ: Draws the game | PASS | looks fine\nVERDICT: PASS", project("draw()"), "REQ: Draws the game | PASS | ok\nVERDICT: PASS"],
    },
    [],
  );
  const result = await runBuild({ request: "game", history: [], full: first.full, project: first.project, checkpointed: false, verify: true, canSee: false, approveEveryStep: false }, fx);
  assert.equal(result.checks.length, 2);
  assert.ok(result.checks[0].items.some((item) => item.auto && item.status === "fail"));
  assert.equal(result.stillFailing.length, 0);
});

test("it gives up after the limit and says so", async () => {
  const first = await start("bad(");
  const fx = fakeEffects({ probes: Array(10).fill(["Boom"]), inspections: [], replies: Array(10).fill(project("bad("))}, []);
  const result = await runBuild({ request: "x", history: [], full: first.full, project: first.project, checkpointed: false, verify: false, canSee: false, approveEveryStep: false, fixLimit: 2 }, fx);
  assert.equal(result.fixes, 2);
  assert.ok(result.full.includes("Still failing after 2 fixes"));
});

test("with approval on every step, a refusal stops the build", async () => {
  const first = await start("bad(");
  const log: string[] = [];
  const fx = fakeEffects({ probes: [["Boom"]], inspections: [], replies: [project("fixed()")] }, log, { confirm: false });
  const result = await runBuild({ request: "x", history: [], full: first.full, project: first.project, checkpointed: false, verify: true, canSee: false, approveEveryStep: true }, fx);
  assert.equal(result.declined, true);
  assert.equal(result.fixes, 0);
  assert.ok(log.includes("confirm:Fix a console error"));
  assert.ok(!log.includes("step:inspecting"));
});

test("checkpoints build the core, then ask for the rest, and test both", async () => {
  const first = await start("core()");
  const log: string[] = [];
  const fx = fakeEffects(
    { probes: [[], []], inspections: [good, good], replies: ["REQ: Core works | PASS | ok\nVERDICT: PASS", project("full()"), "REQ: Everything works | PASS | ok\nVERDICT: PASS"] },
    log,
  );
  const result = await runBuild({ request: "game", history: [], full: first.full, project: first.project, checkpointed: true, verify: true, canSee: false, approveEveryStep: false }, fx);
  assert.equal(result.checks.length, 2);
  assert.ok(result.checks[0].label.startsWith("Checkpoint 1") && result.checks[1].label.startsWith("Checkpoint 2"));
  assert.ok(log.includes("step:extending"));
  assert.ok(result.project.files.some((file) => file.content.includes("full()")));
});

test("telemetry records steps, timing and the outcome", () => {
  beginRun("make a game", 1000);
  stepTo("generating", "Writing code", "", 1000);
  noteCall();
  stepTo("running", "Running it", "", 4000);
  stepTo("running", "Running it", "", 4500);
  endRun("done", 9000);
  const run = getRun()!;
  assert.equal(run.steps.length, 2);
  assert.equal(run.steps[0].endedAt, 4000);
  assert.equal(run.steps[1].status, "done");
  assert.equal(run.calls, 1);
  assert.equal(run.outcome, "done");
});

test("the between-steps hook is called during a build and can stop it", async () => {
  const first = await start("ok()");
  const log: string[] = [];
  let gaps = 0;
  const fx = fakeEffects({ probes: [[]], inspections: [good], replies: ["REQ: It runs | PASS | fine\nVERDICT: PASS"] }, log);
  fx.between = async () => {
    gaps += 1;
  };
  await runBuild({ request: "make a thing", history: [], full: first.full, project: first.project, checkpointed: false, verify: true, canSee: false, approveEveryStep: false }, fx);
  assert.ok(gaps >= 2, "once before the first test run and once before the checks");

  let stopped = false;
  const fx2 = fakeEffects({ probes: [[]], inspections: [good], replies: [] }, []);
  fx2.aborted = () => stopped;
  fx2.between = async () => {
    stopped = true;
  };
  const result = await runBuild({ request: "make a thing", history: [], full: first.full, project: first.project, checkpointed: false, verify: true, canSee: false, approveEveryStep: false }, fx2);
  assert.equal(result.stopped, true);
});
