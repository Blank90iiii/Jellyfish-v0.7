import type { Project } from "./parse";

function project(name: string, files: Project["files"]): Project {
  return { name, files };
}

export function blankProject(): Project {
  return project("workspace", [
    {
      path: "index.html",
      content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Workspace</title>
  <link rel="stylesheet" href="css/style.css" />
</head>
<body>
  <main>
    <h1>Workspace</h1>
    <p>Edit the files, then press Run.</p>
    <button type="button" id="go">Click me</button>
    <p id="out"></p>
  </main>
  <script src="js/script.js"></script>
</body>
</html>
`,
    },
    {
      path: "css/style.css",
      content: `* { box-sizing: border-box; }
html, body { margin: 0; min-height: 100%; background: #0c0d10; color: #ececee; font-family: system-ui, sans-serif; }
main { min-height: 100vh; display: grid; place-content: center; gap: 12px; padding: 24px; }
h1 { margin: 0; font-size: 32px; letter-spacing: -0.04em; }
p { margin: 0; color: #9b9ba4; }
button { min-height: 44px; padding: 0 16px; border: 0; border-radius: 10px; background: #3d7ec4; color: #f5f8fc; font: inherit; }
#out { min-height: 1.2em; }
`,
    },
    {
      path: "js/script.js",
      content: `document.getElementById("go").addEventListener("click", function () {
  document.getElementById("out").textContent = "Script ran.";
  console.log("clicked");
});
`,
    },
  ]);
}

export function snakeProject(): Project {
  return project("snake", [
    {
      path: "index.html",
      content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Snake</title>
  <link rel="stylesheet" href="css/style.css" />
</head>
<body>
  <main>
    <header>
      <h1>Snake</h1>
      <p>Score <strong id="score">0</strong></p>
    </header>
    <canvas id="board" width="400" height="400"></canvas>
    <div class="pad" id="pad">
      <button type="button" data-dir="up">Up</button>
      <button type="button" data-dir="left">Left</button>
      <button type="button" data-dir="down">Down</button>
      <button type="button" data-dir="right">Right</button>
    </div>
    <button type="button" id="restart">Restart</button>
    <p class="hint">Arrows or the buttons. Don't hit a wall or yourself.</p>
  </main>
  <script src="js/game.js"></script>
</body>
</html>
`,
    },
    {
      path: "css/style.css",
      content: `* { box-sizing: border-box; }
html, body { margin: 0; min-height: 100%; background: #0c0d10; color: #ececee; font-family: system-ui, sans-serif; }
main { min-height: 100vh; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 12px; padding: 16px; }
h1 { margin: 0; font-size: 22px; letter-spacing: -0.03em; }
header { display: flex; align-items: baseline; gap: 16px; }
p { margin: 0; color: #9b9ba4; }
canvas { width: min(92vw, 420px); height: auto; background: #111318; border: 1px solid #2c3038; border-radius: 12px; touch-action: none; }
.pad { display: grid; grid-template-columns: repeat(3, 72px); grid-template-areas: ". up ." "left down right"; gap: 8px; }
.pad button[data-dir="up"] { grid-area: up; }
.pad button[data-dir="left"] { grid-area: left; }
.pad button[data-dir="down"] { grid-area: down; }
.pad button[data-dir="right"] { grid-area: right; }
button { min-height: 44px; border: 0; border-radius: 10px; background: #1e2128; color: #ececee; font: inherit; }
#restart { background: #3d7ec4; color: #f5f8fc; padding: 0 18px; }
.hint { font-size: 13px; text-align: center; }
`,
    },
    {
      path: "js/game.js",
      content: `(function () {
  var canvas = document.getElementById("board");
  var ctx = canvas.getContext("2d");
  var scoreEl = document.getElementById("score");
  var COLS = 20;
  var SIZE = canvas.width / COLS;
  var snake, dir, queued, food, score, timer, over;

  function spawn() {
    var open = [];
    for (var y = 0; y < COLS; y++) {
      for (var x = 0; x < COLS; x++) {
        var hit = false;
        for (var i = 0; i < snake.length; i++) {
          if (snake[i].x === x && snake[i].y === y) hit = true;
        }
        if (!hit) open.push({ x: x, y: y });
      }
    }
    food = open[Math.floor(Math.random() * open.length)] || { x: 0, y: 0 };
  }

  function setDir(nx, ny) {
    if (dir.x + nx === 0 && dir.y + ny === 0) return;
    queued = { x: nx, y: ny };
  }

  function draw() {
    ctx.fillStyle = "#111318";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "#8fca9b";
    ctx.fillRect(food.x * SIZE + 2, food.y * SIZE + 2, SIZE - 4, SIZE - 4);
    for (var i = 0; i < snake.length; i++) {
      ctx.fillStyle = i === 0 ? "#7eb0e8" : "#3d7ec4";
      ctx.fillRect(snake[i].x * SIZE + 1, snake[i].y * SIZE + 1, SIZE - 2, SIZE - 2);
    }
    if (over) {
      ctx.fillStyle = "rgba(12,13,16,0.72)";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = "#ececee";
      ctx.font = "600 28px system-ui, sans-serif";
      ctx.textAlign = "center";
      ctx.fillText("Game over", canvas.width / 2, canvas.height / 2 - 8);
      ctx.font = "16px system-ui, sans-serif";
      ctx.fillStyle = "#9b9ba4";
      ctx.fillText("Score " + score, canvas.width / 2, canvas.height / 2 + 22);
    }
  }

  function tick() {
    if (over) return;
    dir = queued;
    var head = { x: snake[0].x + dir.x, y: snake[0].y + dir.y };
    var dead = head.x < 0 || head.y < 0 || head.x >= COLS || head.y >= COLS;
    for (var i = 0; i < snake.length; i++) {
      if (snake[i].x === head.x && snake[i].y === head.y) dead = true;
    }
    if (dead) {
      over = true;
      clearInterval(timer);
      draw();
      return;
    }
    snake.unshift(head);
    if (head.x === food.x && head.y === food.y) {
      score += 1;
      scoreEl.textContent = String(score);
      spawn();
    } else {
      snake.pop();
    }
    draw();
  }

  function reset() {
    snake = [{ x: 8, y: 10 }, { x: 7, y: 10 }, { x: 6, y: 10 }];
    dir = { x: 1, y: 0 };
    queued = { x: 1, y: 0 };
    score = 0;
    over = false;
    scoreEl.textContent = "0";
    spawn();
    clearInterval(timer);
    timer = setInterval(tick, 130);
    draw();
  }

  document.addEventListener("keydown", function (e) {
    var map = { ArrowUp: [0, -1], ArrowDown: [0, 1], ArrowLeft: [-1, 0], ArrowRight: [1, 0] };
    if (!map[e.key]) return;
    e.preventDefault();
    setDir(map[e.key][0], map[e.key][1]);
  });
  document.getElementById("pad").addEventListener("click", function (e) {
    var b = e.target.closest && e.target.closest("button");
    if (!b) return;
    var d = b.getAttribute("data-dir");
    if (d === "up") setDir(0, -1);
    if (d === "down") setDir(0, 1);
    if (d === "left") setDir(-1, 0);
    if (d === "right") setDir(1, 0);
  });
  document.getElementById("restart").addEventListener("click", reset);
  reset();
})();
`,
    },
    {
      path: "README.md",
      content: `Snake. Open index.html in a browser. Arrow keys or the on-screen buttons. Restart puts you back at score 0.\n`,
    },
  ]);
}

export function pongProject(): Project {
  return project("pong", [
    {
      path: "index.html",
      content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Pong</title>
  <link rel="stylesheet" href="css/style.css" />
</head>
<body>
  <main>
    <header>
      <h1>Pong</h1>
      <p><strong id="you">0</strong> – <strong id="ai">0</strong></p>
    </header>
    <canvas id="board" width="360" height="220"></canvas>
    <button type="button" id="restart">Restart</button>
    <p class="hint">Drag on the board to move your paddle. First to 7.</p>
  </main>
  <script src="js/game.js"></script>
</body>
</html>
`,
    },
    {
      path: "css/style.css",
      content: `* { box-sizing: border-box; }
html, body { margin: 0; min-height: 100%; background: #0c0d10; color: #ececee; font-family: system-ui, sans-serif; }
main { min-height: 100vh; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 12px; padding: 16px; }
h1 { margin: 0; font-size: 22px; }
header { display: flex; gap: 16px; align-items: baseline; }
p { margin: 0; color: #9b9ba4; }
canvas { width: min(96vw, 560px); height: auto; background: #111318; border: 1px solid #2c3038; border-radius: 12px; touch-action: none; }
button { min-height: 44px; padding: 0 18px; border: 0; border-radius: 10px; background: #3d7ec4; color: #f5f8fc; font: inherit; }
.hint { font-size: 13px; text-align: center; }
`,
    },
    {
      path: "js/game.js",
      content: `(function () {
  var canvas = document.getElementById("board");
  var ctx = canvas.getContext("2d");
  var W = canvas.width, H = canvas.height, PH = 48;
  var playerY = 86, aiY = 86, bx, by, vx, vy, you, ai, running, raf;

  function resetBall(dir) {
    bx = W / 2;
    by = H / 2;
    vx = dir * 3.1;
    vy = (Math.random() * 2 - 1) * 2.2;
  }

  function reset() {
    you = 0; ai = 0;
    playerY = 86; aiY = 86;
    running = true;
    document.getElementById("you").textContent = "0";
    document.getElementById("ai").textContent = "0";
    resetBall(Math.random() < 0.5 ? -1 : 1);
    cancelAnimationFrame(raf);
    raf = requestAnimationFrame(frame);
  }

  function draw() {
    ctx.fillStyle = "#111318";
    ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = "#2c3038";
    ctx.fillRect(W / 2 - 1, 0, 2, H);
    ctx.fillStyle = "#7eb0e8";
    ctx.fillRect(8, playerY, 8, PH);
    ctx.fillStyle = "#ececee";
    ctx.fillRect(W - 16, aiY, 8, PH);
    ctx.beginPath();
    ctx.arc(bx, by, 5, 0, Math.PI * 2);
    ctx.fill();
    if (!running) {
      ctx.fillStyle = "rgba(12,13,16,0.72)";
      ctx.fillRect(0, 0, W, H);
      ctx.fillStyle = "#ececee";
      ctx.font = "600 22px system-ui, sans-serif";
      ctx.textAlign = "center";
      ctx.fillText(you > ai ? "You win" : "AI wins", W / 2, H / 2);
    }
  }

  function frame() {
    if (!running) { draw(); return; }
    bx += vx; by += vy;
    if (by < 6 || by > H - 6) vy *= -1;
    if (bx < 20 && by > playerY && by < playerY + PH && vx < 0) {
      vx = Math.abs(vx) + 0.15;
      vy += (by - (playerY + PH / 2)) * 0.06;
    }
    if (bx > W - 20 && by > aiY && by < aiY + PH && vx > 0) {
      vx = -(Math.abs(vx) + 0.12);
    }
    if (bx < 0) { ai += 1; document.getElementById("ai").textContent = String(ai); resetBall(1); }
    if (bx > W) { you += 1; document.getElementById("you").textContent = String(you); resetBall(-1); }
    var aim = by - PH / 2;
    aiY += Math.max(-3.2, Math.min(3.2, aim - aiY));
    aiY = Math.max(0, Math.min(H - PH, aiY));
    if (you >= 7 || ai >= 7) running = false;
    draw();
    raf = requestAnimationFrame(frame);
  }

  function place(clientY) {
    var r = canvas.getBoundingClientRect();
    var y = ((clientY - r.top) * H) / r.height - PH / 2;
    playerY = Math.max(0, Math.min(H - PH, y));
  }
  canvas.addEventListener("pointerdown", function (e) { canvas.setPointerCapture(e.pointerId); place(e.clientY); });
  canvas.addEventListener("pointermove", function (e) { if (e.buttons || e.pressure) place(e.clientY); });
  document.getElementById("restart").addEventListener("click", reset);
  reset();
})();
`,
    },
    {
      path: "README.md",
      content: `One-player pong. Drag on the board to move the left paddle. First to 7 wins.\n`,
    },
  ]);
}

export function clickerProject(): Project {
  return project("clicker", [
    {
      path: "index.html",
      content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Clicker</title>
  <link rel="stylesheet" href="css/style.css" />
</head>
<body>
  <main>
    <h1>Clicker</h1>
    <p class="score" id="score">0</p>
    <p id="rate">1 per click · 0 per second</p>
    <button type="button" id="tap">Click</button>
    <div class="shop">
      <button type="button" data-buy="click">Sharper click · 25</button>
      <button type="button" data-buy="auto">Helper · 40</button>
    </div>
  </main>
  <script src="js/game.js"></script>
</body>
</html>
`,
    },
    {
      path: "css/style.css",
      content: `* { box-sizing: border-box; }
html, body { margin: 0; min-height: 100%; background: #0c0d10; color: #ececee; font-family: system-ui, sans-serif; }
main { min-height: 100vh; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 12px; padding: 24px; text-align: center; }
h1 { margin: 0; }
.score { font-size: 56px; margin: 0; letter-spacing: -0.04em; }
p { margin: 0; color: #9b9ba4; }
button { min-height: 48px; border: 0; border-radius: 12px; font: inherit; }
#tap { background: #3d7ec4; color: #f5f8fc; padding: 0 36px; font-size: 18px; }
.shop { display: flex; flex-direction: column; gap: 8px; width: min(100%, 280px); }
.shop button { background: #1e2128; color: #ececee; }
`,
    },
    {
      path: "js/game.js",
      content: `(function () {
  var score = 0, per = 1, auto = 0;
  var scoreEl = document.getElementById("score");
  var rateEl = document.getElementById("rate");
  function paint() {
    scoreEl.textContent = String(score);
    rateEl.textContent = per + " per click · " + auto + " per second";
  }
  document.getElementById("tap").addEventListener("click", function () {
    score += per;
    paint();
  });
  document.querySelector(".shop").addEventListener("click", function (e) {
    var b = e.target.closest && e.target.closest("button");
    if (!b) return;
    var kind = b.getAttribute("data-buy");
    if (kind === "click" && score >= 25) { score -= 25; per += 1; }
    if (kind === "auto" && score >= 40) { score -= 40; auto += 1; }
    paint();
  });
  setInterval(function () {
    if (!auto) return;
    score += auto;
    paint();
  }, 1000);
  paint();
})();
`,
    },
    {
      path: "README.md",
      content: `A small clicker. Click, then buy a sharper click or a helper.\n`,
    },
  ]);
}

export function twoSumProject(): Project {
  return project("two-sum", [
    {
      path: "index.html",
      content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Two sum</title>
  <link rel="stylesheet" href="css/style.css" />
</head>
<body>
  <main>
    <h1>Two sum</h1>
    <p id="sum">Running tests…</p>
    <ul id="out"></ul>
  </main>
  <script src="js/two-sum.js"></script>
  <script src="js/tests.js"></script>
</body>
</html>
`,
    },
    {
      path: "css/style.css",
      content: `* { box-sizing: border-box; }
body { margin: 0; min-height: 100vh; background: #0c0d10; color: #ececee; font-family: ui-monospace, monospace; }
main { max-width: 640px; margin: 0 auto; padding: 32px 20px; }
h1 { font-family: system-ui, sans-serif; letter-spacing: -0.03em; }
li { margin: 8px 0; }
.ok { color: #8fca9b; }
.bad { color: #e08588; }
`,
    },
    {
      path: "js/two-sum.js",
      content: `function twoSum(nums, target) {
  var map = new Map();
  for (var i = 0; i < nums.length; i++) {
    var need = target - nums[i];
    if (map.has(need)) return [map.get(need), i];
    map.set(nums[i], i);
  }
  return [];
}
`,
    },
    {
      path: "js/tests.js",
      content: `var cases = [
  { nums: [2, 7, 11, 15], target: 9, want: [0, 1] },
  { nums: [3, 2, 4], target: 6, want: [1, 2] },
  { nums: [3, 3], target: 6, want: [0, 1] }
];
var list = document.getElementById("out");
var pass = 0;
cases.forEach(function (c, i) {
  var got = twoSum(c.nums, c.target);
  var ok = JSON.stringify(got) === JSON.stringify(c.want);
  if (ok) pass += 1;
  var li = document.createElement("li");
  li.className = ok ? "ok" : "bad";
  li.textContent = (ok ? "Pass" : "Fail") + " case " + (i + 1) + " got " + JSON.stringify(got);
  list.appendChild(li);
});
document.getElementById("sum").textContent = pass + " / " + cases.length + " passed";
console.log(pass + " passed");
`,
    },
    {
      path: "README.md",
      content: `Two-sum with three checks. Open index.html. Green lines passed.\n`,
    },
  ]);
}

export function labProject(): Project {
  return project("3d-lab", [
    {
      path: "index.html",
      content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>3D lab</title>
  <link rel="stylesheet" href="css/style.css" />
</head>
<body>
  <canvas id="view"></canvas>
  <div class="hud">
    <strong>3D lab</strong>
    <span id="state">Spinning</span>
    <button type="button" id="pause">Pause</button>
  </div>
  <script src="js/lab.js"></script>
</body>
</html>
`,
    },
    {
      path: "css/style.css",
      content: `html, body { margin: 0; height: 100%; background: #0c0d10; color: #ececee; font-family: system-ui, sans-serif; overflow: hidden; }
canvas { display: block; width: 100%; height: 100%; touch-action: none; }
.hud { position: fixed; left: 16px; top: 16px; display: flex; gap: 12px; align-items: center; background: rgba(21,23,28,0.9); border: 1px solid #2c3038; border-radius: 12px; padding: 8px 12px; }
button { min-height: 36px; border: 0; border-radius: 8px; background: #3d7ec4; color: #f5f8fc; font: inherit; padding: 0 12px; }
span { color: #9b9ba4; }
`,
    },
    {
      path: "js/lab.js",
      content: `(function () {
  var canvas = document.getElementById("view");
  var ctx = canvas.getContext("2d");
  var yaw = 0.6, pitch = 0.45, spin = true, drag = false, lx = 0, ly = 0;
  var cube = [[-1,-1,-1],[1,-1,-1],[1,1,-1],[-1,1,-1],[-1,-1,1],[1,-1,1],[1,1,1],[-1,1,1]];
  var edges = [[0,1],[1,2],[2,3],[3,0],[4,5],[5,6],[6,7],[7,4],[0,4],[1,5],[2,6],[3,7]];

  function resize() {
    canvas.width = window.innerWidth * devicePixelRatio;
    canvas.height = window.innerHeight * devicePixelRatio;
  }
  window.addEventListener("resize", resize);
  resize();

  function rotate(v) {
    var x = v[0], y = v[1], z = v[2];
    var cy = Math.cos(yaw), sy = Math.sin(yaw);
    var x1 = x * cy - z * sy, z1 = x * sy + z * cy;
    var cx = Math.cos(pitch), sx = Math.sin(pitch);
    return [x1, y * cx - z1 * sx, y * sx + z1 * cx];
  }
  function project(v, scale) {
    var p = rotate([v[0] * scale, v[1] * scale, v[2] * scale]);
    var f = 420 / (4.2 - p[2]);
    return [canvas.width / 2 + p[0] * f, canvas.height / 2 + p[1] * f];
  }
  function stroke(verts, scale, color, width) {
    ctx.strokeStyle = color;
    ctx.lineWidth = width;
    edges.forEach(function (e) {
      var a = project(verts[e[0]], scale);
      var b = project(verts[e[1]], scale);
      ctx.beginPath();
      ctx.moveTo(a[0], a[1]);
      ctx.lineTo(b[0], b[1]);
      ctx.stroke();
    });
  }
  function frame() {
    if (spin && !drag) yaw += 0.012;
    ctx.fillStyle = "#0c0d10";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    stroke(cube, 1, "#7eb0e8", 2 * devicePixelRatio);
    stroke(cube, 0.45, "#3d7ec4", 1.5 * devicePixelRatio);
    requestAnimationFrame(frame);
  }
  canvas.addEventListener("pointerdown", function (e) {
    drag = true; lx = e.clientX; ly = e.clientY;
    canvas.setPointerCapture(e.pointerId);
  });
  canvas.addEventListener("pointerup", function () { drag = false; });
  canvas.addEventListener("pointermove", function (e) {
    if (!drag) return;
    yaw += (e.clientX - lx) * 0.01;
    pitch += (e.clientY - ly) * 0.01;
    lx = e.clientX; ly = e.clientY;
  });
  document.getElementById("pause").addEventListener("click", function () {
    spin = !spin;
    document.getElementById("state").textContent = spin ? "Spinning" : "Paused";
    this.textContent = spin ? "Pause" : "Spin";
  });
  requestAnimationFrame(frame);
  console.log("3d lab ready");
})();
`,
    },
    {
      path: "README.md",
      content: `A small 3D lab. Drag to orbit two cubes. Pause stops the spin.\n`,
    },
  ]);
}

export function sketchProject(caption: string): Project {
  const safe = caption.replace(/[<>&]/g, "").slice(0, 80) || "Sketch";
  return project("sketch", [
    {
      path: "index.html",
      content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Sketch</title>
  <link rel="stylesheet" href="css/style.css" />
</head>
<body>
  <main>
    <canvas id="c" width="640" height="400"></canvas>
    <p>${safe}</p>
  </main>
  <script src="js/sketch.js"></script>
</body>
</html>
`,
    },
    {
      path: "css/style.css",
      content: `body { margin: 0; min-height: 100vh; display: grid; place-items: center; background: #0c0d10; color: #9b9ba4; font-family: system-ui, sans-serif; }
canvas { width: min(96vw, 640px); height: auto; background: #15171c; border-radius: 16px; }
p { text-align: center; padding: 0 16px; }
`,
    },
    {
      path: "js/sketch.js",
      content: `var c = document.getElementById("c");
var x = c.getContext("2d");
x.fillStyle = "#15171c";
x.fillRect(0, 0, c.width, c.height);
x.strokeStyle = "#7eb0e8";
x.lineWidth = 3;
x.beginPath();
x.ellipse(250, 210, 120, 70, 0, 0, Math.PI * 2);
x.stroke();
x.beginPath();
x.moveTo(130, 200);
x.lineTo(70, 160);
x.lineTo(70, 250);
x.closePath();
x.stroke();
x.fillStyle = "#ececee";
x.beginPath();
x.arc(320, 190, 6, 0, Math.PI * 2);
x.fill();
x.fillStyle = "#3d7ec4";
x.font = "20px system-ui, sans-serif";
x.fillText("On-device sketch", 40, 48);
`,
    },
    {
      path: "README.md",
      content: `A canvas sketch used when the cloud image brain is unreachable.\n`,
    },
  ]);
}
