import assert from "node:assert/strict";
import http from "node:http";
import { test } from "node:test";
import { localSystemPrompt, ollamaPull, ollamaTags } from "./ollama.ts";
import { streamReply } from "./router.ts";

function fakeOllama() {
  const server = http.createServer((req, res) => {
    if (req.url === "/api/tags") {
      res.setHeader("content-type", "application/json");
      res.end(JSON.stringify({ models: [{ name: "qwen2.5-coder:7b", size: 4700000000 }] }));
      return;
    }
    if (req.url === "/api/pull") {
      res.write(JSON.stringify({ status: "pulling manifest" }) + "\n");
      res.write(JSON.stringify({ status: "downloading", total: 100, completed: 40 }) + "\n");
      res.write(JSON.stringify({ status: "success", total: 100, completed: 100 }) + "\n");
      res.end();
      return;
    }
    res.statusCode = 404;
    res.end();
  });
  return new Promise<{ url: string; close: () => void }>((resolve) =>
    server.listen(0, "127.0.0.1", () => {
      const port = (server.address() as { port: number }).port;
      resolve({ url: `http://127.0.0.1:${port}`, close: () => server.close() });
    }),
  );
}

test("ollamaTags lists installed models and returns null when nothing is listening", async () => {
  const fake = await fakeOllama();
  assert.deepEqual(await ollamaTags(fake.url), [{ name: "qwen2.5-coder:7b", size: 4700000000 }]);
  fake.close();
  assert.equal(await ollamaTags("http://127.0.0.1:1"), null);
});

test("ollamaPull reports progress and finishes without an error", async () => {
  const fake = await fakeOllama();
  const seen: (number | null)[] = [];
  const failure = await ollamaPull(fake.url, "qwen2.5-coder:7b", (fraction) => seen.push(fraction));
  fake.close();
  assert.equal(failure, null);
  assert.ok(seen.includes(0.4));
  assert.equal(seen[seen.length - 1], 1);
});

test("local prompt carries the project format and the pinned rules", () => {
  const prompt = localSystemPrompt(["No ES modules"], ["Name is Sam"], []);
  assert.ok(prompt.includes("<<<PROJECT short-name"));
  assert.ok(prompt.includes("<<<END"));
  assert.ok(prompt.includes("- No ES modules"));
  assert.ok(prompt.includes("- Name is Sam"));
});

test("the Ollama chat request keeps the model loaded (keep_alive -1) and keeps the Jellyfish options", async () => {
  const realFetch = globalThis.fetch;
  let sent: { model?: string; stream?: boolean; keep_alive?: unknown; options?: { num_ctx?: number; temperature?: number }; messages?: { role: string }[] } = {};
  globalThis.fetch = (async (_url: unknown, init?: { body?: unknown }) => {
    sent = JSON.parse(String(init?.body));
    return new Response(JSON.stringify({ message: { content: "ok" } }) + "\n", { status: 200 });
  }) as typeof fetch;
  try {
    const failure = await streamReply({ messages: [{ role: "user", content: "hi" }], facts: [], lessons: [], onDelta: () => {} });
    assert.equal(failure, null);
  } finally {
    globalThis.fetch = realFetch;
  }
  assert.equal(sent.keep_alive, -1);
  assert.equal(sent.stream, true);
  assert.equal(sent.options?.num_ctx, 8192);
  assert.equal(sent.options?.temperature, 0.2);
  assert.equal(sent.messages?.[0].role, "system");
});
