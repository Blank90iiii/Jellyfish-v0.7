import type { ProjectFile } from "./parse";

export type Patch = {
  path: string;
  summary: string;
  before: string;
  after: string;
};

export type DiffLine = { kind: "same" | "add" | "del"; text: string };

function braces(content: string): { open: number; close: number } {
  return {
    open: (content.match(/\{/g) || []).length,
    close: (content.match(/\}/g) || []).length,
  };
}

/** First concrete fix for the open project, or null when it already looks sound. */
export function findPatch(files: ProjectFile[]): Patch | null {
  for (const file of files) {
    if (/\/\/\s*\.\.\.|rest of (the )?code|existing code/i.test(file.content)) {
      return {
        path: file.path,
        summary: `${file.path} still has a placeholder skip. A file you can run needs every line.`,
        before: file.content,
        after: file.content.replace(/\/\/\s*\.\.\.[^\n]*/g, "// completed section"),
      };
    }
  }
  for (const file of files) {
    if (!/\.(js|mjs|cjs|ts|tsx|jsx|css)$/.test(file.path)) continue;
    const count = braces(file.content);
    if (count.open > count.close) {
      const missing = count.open - count.close;
      return {
        path: file.path,
        summary: `${file.path} has ${count.open} opening braces and ${count.close} closing braces.`,
        before: file.content,
        after: `${file.content.replace(/\s*$/, "")}\n${"}".repeat(missing)}\n`,
      };
    }
  }
  for (const file of files) {
    if (!file.path.endsWith(".css")) continue;
    if (/#3d7ec4/i.test(file.content)) {
      return {
        path: file.path,
        summary: "That stylesheet still uses a generic blue. Neon orange is the pinned favorite.",
        before: file.content,
        after: file.content.replace(/#3d7ec4/gi, "#FF6B00"),
      };
    }
  }
  return null;
}

export function lineDiff(before: string, after: string): DiffLine[] {
  const a = before.split("\n");
  const b = after.split("\n");
  const changed = new Set<number>();
  const n = Math.max(a.length, b.length);
  for (let i = 0; i < n; i++) {
    if (a[i] !== b[i]) changed.add(i);
  }
  const keep = new Set<number>();
  for (const index of changed) {
    for (let i = index - 1; i <= index + 1; i++) if (i >= 0 && i < n) keep.add(i);
  }
  const out: DiffLine[] = [];
  const sorted = [...keep].sort((x, y) => x - y);
  let prev = -2;
  for (const index of sorted) {
    if (index > prev + 1) out.push({ kind: "same", text: "…" });
    if (a[index] === b[index]) out.push({ kind: "same", text: a[index] ?? "" });
    else {
      if (a[index] !== undefined) out.push({ kind: "del", text: a[index] });
      if (b[index] !== undefined) out.push({ kind: "add", text: b[index] });
    }
    prev = index;
    if (out.length > 80) break;
  }
  return out;
}
