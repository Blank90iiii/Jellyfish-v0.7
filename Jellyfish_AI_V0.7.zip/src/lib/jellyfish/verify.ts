/** Turns "run it and look at it" into facts, then into a check the model can answer. Pure text, no browser needed. */

export type Inspection = {
  errors: string[];
  title: string;
  text: string;
  canvases: { w: number; h: number; filled: number; colors: number }[];
  buttons: string[];
  inputs: number;
  images: number;
  animates: boolean | null;
  reactsToInput: boolean | null;
  overflowX: boolean;
  shot: string | null;
  failed?: string;
};

export type CheckStatus = "pass" | "fail" | "unsure";
export type CheckItem = { text: string; status: CheckStatus; note: string; auto?: boolean };
export type CheckRound = { label: string; shot?: string; items: CheckItem[]; errors: string[] };

export type Scope = "core" | "full";

export function formatInspection(i: Inspection): string {
  const lines: string[] = [];
  if (i.failed) lines.push(`The inspector itself failed: ${i.failed}`);
  lines.push(i.errors.length ? `Console errors: ${i.errors.slice(0, 4).join(" | ")}` : "Console errors: none");
  lines.push(i.text ? `Visible text: "${i.text.slice(0, 240)}"` : "Visible text: none");
  if (i.canvases.length) {
    lines.push(
      ...i.canvases.map(
        (c, n) => `Canvas ${n + 1}: ${c.w}x${c.h}, ${c.filled < 0.005 ? "looks EMPTY (nothing drawn)" : `${Math.round(c.filled * 100)}% of it differs from the background`}, ${c.colors} colors`,
      ),
    );
  } else lines.push("Canvas: none");
  lines.push(i.buttons.length ? `Buttons: ${i.buttons.join(", ")}` : "Buttons: none");
  if (i.inputs) lines.push(`Inputs: ${i.inputs}`);
  lines.push(`Moves or changes by itself: ${i.animates === null ? "unknown" : i.animates ? "yes" : "no"}`);
  lines.push(`Reacted to random keys and clicks: ${i.reactsToInput === null ? "could not tell" : i.reactsToInput ? "yes" : "no"}`);
  lines.push(`Sticks out sideways past the screen: ${i.overflowX ? "yes" : "no"}`);
  return lines.join("\n");
}

/** Facts that need no opinion: they come straight from the measurements. */
export function autoChecks(i: Inspection): CheckItem[] {
  const items: CheckItem[] = [];
  items.push({
    text: "Runs without console errors",
    status: i.errors.length ? "fail" : "pass",
    note: i.errors.length ? i.errors[0].slice(0, 120) : "",
    auto: true,
  });
  if (i.canvases.length) {
    const empty = i.canvases.every((c) => c.filled < 0.005);
    items.push({ text: "The canvas shows something", status: empty ? "fail" : "pass", note: empty ? "everything on it is one color" : "", auto: true });
  }
  if (i.overflowX) items.push({ text: "Fits the screen width", status: "fail", note: "content sticks out sideways", auto: true });
  return items;
}

export function checkPrompt(request: string, requirements: string[] | null, report: string, canSee: boolean, scope: Scope): string {
  const reqBlock = requirements?.length
    ? `REQUIREMENTS (already decided, judge each one):\n${requirements.map((r) => `- ${r}`).join("\n")}`
    : `First write 4 to 8 short, testable requirements from the request. ${
        scope === "core" ? "Only the core: the main mechanic, what is drawn, and the controls. Ignore extras that are not built yet." : "Everything the person asked for."
      }`;
  return `You are the tester. You just built a project. Check it against what the person asked.

THE REQUEST:
${request.slice(0, 1500)}

${reqBlock}

WHAT THE TESTER MEASURED ON THE RUNNING PROJECT:
${report}
${canSee ? "A screenshot of the running project is attached. Look at it." : "No screenshot is available to you. Judge from the measurements. Say UNSURE when they do not prove it."}

Reply in exactly this format and nothing else:
REQ: <requirement> | PASS or FAIL or UNSURE | <reason, at most 12 words>
(one REQ line per requirement)
VERDICT: PASS or FAIL`;
}

export function parseChecks(reply: string): { items: CheckItem[]; verdict: "pass" | "fail" | null } {
  const items: CheckItem[] = [];
  for (const line of reply.replace(/<thought>[\s\S]*?<\/thought>/gi, "").split("\n")) {
    const match = line.match(/^\s*[-*]?\s*REQ:\s*(.+?)\s*\|\s*(PASS|FAIL|UNSURE)\s*(?:\|\s*(.*))?$/i);
    if (!match) continue;
    items.push({ text: match[1].trim().slice(0, 140), status: match[2].toLowerCase() as CheckStatus, note: (match[3] ?? "").trim().slice(0, 140) });
  }
  const v = reply.match(/VERDICT:\s*(PASS|FAIL)/i);
  return { items: items.slice(0, 10), verdict: v ? (v[1].toLowerCase() as "pass" | "fail") : null };
}

export function fixPrompt(failed: CheckItem[], report: string): string {
  return `The tester ran your project. These checks FAILED:
${failed.map((f) => `- ${f.text}${f.note ? ` (${f.note})` : ""}`).join("\n")}

Measurements:
${report}

Rewrite the whole project so every failed check passes. Keep everything that already works. Full files only.`;
}

export const REST_PROMPT =
  "Checkpoint 1 passed. Now add everything else the original request asked for. Keep everything that already works. Return the complete project, full files only.";

export const CORE_NOTE =
  "\n\n[Checkpoint 1 of 2] Build only the core first: the main mechanic, what is drawn, and the controls, working end to end. Leave out extras and polish. Jellyfish will test it, then ask you for the rest.";

export function looksLikeBuild(text: string): boolean {
  return /\b(make|build|create|code|write|develop|generate|design)\b[\s\S]{0,60}\b(game|app|page|site|website|tool|calculator|tracker|dashboard|animation|clock|timer|quiz|simulator|visuali[sz]er|editor|form|landing|clone|scene)\b/i.test(text);
}

/** Models that can look at a picture. Text-only coders like Qwen2.5-Coder cannot. */
export function canSeeImages(provider: string, model: string): boolean {
  if (provider === "ollama") return /vl|llava|vision|minicpm|gemma3|llama3\.2-vision/i.test(model);
  return provider === "xai" || provider === "openai" || provider === "anthropic" || provider === "openrouter";
}
