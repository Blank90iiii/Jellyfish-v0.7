import assert from "node:assert/strict";
import { test } from "node:test";
import { buildPreview } from "./preview.ts";

const files = [
  { path: "index.html", content: '<html><head><link rel=stylesheet href=css/style.css></head><body><script src=js/main.js></script><script src="js/two.js"></script></body></html>' },
  { path: "css/style.css", content: "body{color:red}" },
  { path: "js/main.js", content: "var one=1;" },
  { path: "js/two.js", content: "var two=2;" },
];

test("css and scripts are inlined whether or not the attributes have quotes", () => {
  const html = buildPreview(files);
  assert.ok(html.includes("<style>body{color:red}</style>"));
  assert.ok(html.includes("<script>var one=1;</script>"));
  assert.ok(html.includes("<script>var two=2;</script>"));
  assert.ok(!html.includes("src=js/main.js"));
});
