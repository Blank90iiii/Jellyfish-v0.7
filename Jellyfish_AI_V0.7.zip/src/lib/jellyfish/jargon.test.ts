import assert from "node:assert/strict";
import { test } from "node:test";
import { getJargon, JARGON, jargonTerms } from "./jargon.ts";

test("the dictionary has 20 terms, each with a real definition", () => {
  assert.equal(Object.keys(JARGON).length, 20);
  for (const [term, meaning] of Object.entries(JARGON)) assert.ok(meaning.length > 20, `${term} needs a longer meaning`);
});

test("getJargon ignores capitals, spaces and punctuation, and returns null for unknown words", () => {
  assert.equal(getJargon("api"), JARGON.API);
  assert.equal(getJargon("  JSON?  "), JARGON.JSON);
  assert.equal(getJargon("dom"), JARGON.DOM);
  assert.equal(getJargon("array"), JARGON.Array);
  assert.equal(getJargon("flux capacitor"), null);
  assert.equal(getJargon(""), null);
  assert.equal(jargonTerms().length, 20);
});
