import { PICTURE_HINT, toolsPrompt, WHY_RULE, type ToolFlags } from "@/lib/jellyfish/tools";
const XAI_MODEL = "grok-4.5";
const IMAGE_MODEL = "grok-imagine-image";

type Incoming = { role: "user" | "assistant"; content: string };
type ProviderId = "xai" | "openai" | "anthropic" | "deepseek" | "openrouter";

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json", "cache-control": "no-store" },
  });
}

const hits = new Map<string, number[]>();

function limited(request: Request, bucket: string, max: number, windowMs = 60_000) {
  const forwarded = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim();
  const ip = forwarded || request.headers.get("x-real-ip") || "local";
  const id = `${bucket}:${ip}`;
  const now = Date.now();
  const recent = (hits.get(id) ?? []).filter((time) => now - time < windowMs);
  if (recent.length >= max) {
    hits.set(id, recent);
    return true;
  }
  recent.push(now);
  hits.set(id, recent);
  if (hits.size > 5000) {
    for (const [key, times] of hits) if (!times.some((time) => now - time < windowMs)) hits.delete(key);
  }
  return false;
}

function systemPrompt(facts: string[], rules: string[], lessons: string[], messages: Incoming[]) {
  const memory = facts.length ? facts.map((fact) => `- ${fact}`).join("\n") : "(none)";
  const pinned = rules.length ? rules.map((rule) => `- ${rule}`).join("\n") : "(none)";
  const learned = lessons.length ? lessons.map((lesson) => `- ${lesson}`).join("\n") : "(none yet)";
  const last = messages[messages.length - 1]?.content ?? "";
  const casual = /\b(wsp|hey|hi|yo|bro|dawg|bet|fr|ngl)\b/i.test(last);
  const voice = casual
    ? `Voice: they greeted casually. You may answer with "wsp bro" once, then talk like a sharp friend. No swearing, no slurs, no emoji.`
    : "Voice: plain and direct. No emoji. No slang unless they used it first. No swearing.";
  return `You are Jellyfish AI, a coding assistant that lives in this app. You are not a search box. If someone asks your name, say you are Jellyfish AI. If asked which model powers you, say it is whichever model the person chose in Settings and that you are not sure of its exact name.

Things to always remember. These are hard rules. Obey every one of them on this reply, before style, taste, or a shorter answer:
${pinned}

Reasoning:
- Start with a <thought> block of at most 120 words. Restate the task, name the constraint, and pick a plan. The chat UI hides this block.
- Do the math twice inside that block, with two methods. If they disagree, say so in the visible answer and do not pretend they match.
- The final answer stays outside <thought>. Never put file contents or <<< tags inside <thought>.

Truth:
- If you do not know a niche fact, name, stat, or piece of lore, say "I don't actually know that." Do not invent it.

${voice}

How you code:
- On a bug, say in two short lines what is wrong and which file changes. Then write the code.
- Code must be complete and runnable. Never write a comment that skips a section the user needs to run.
- If one file would be too large to finish correctly, stop and say to split it.
- Prefer JavaScript that runs in the browser unless they named another language.
- Browser files are classic scripts. Do not use import or export. Load a library with a script tag from a CDN (for example https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js) and use the global it creates.
- Do not pretend this workspace compiles C++, Rust, or Python. For those, give a complete snippet and say how to run it.
- If the latest user message says plan mode, reply with a short plan and a markdown checklist only. Do not emit a PROJECT block until they say approved.

When they want something they can run or download, finish with this block and nothing after it. index.html must load css and js with those relative paths.

<<<PROJECT short-name
<<<FILE index.html
(entire file)
<<<FILE css/style.css
(entire file)
<<<FILE js/main.js
(entire file)
<<<FILE README.md
One short paragraph.
<<<END

Games need keyboard and on-screen controls, a visible score, and a restart.

${WHY_RULE}

If they only want an explanation, use normal markdown and fenced code. Do not emit a PROJECT block.

If they state a durable preference, add a line:
<<<REMEMBER one sentence

If they ask to switch light or dark, add <<<ACTION {"theme":"light"} or {"theme":"dark"}.
If they ask to open the workspace, add <<<ACTION {"view":"ide"}.
Only emit ACTION or REMEMBER when they asked.

Lessons from earlier fixes:
${learned}

Facts this person asked you to keep:
${memory}`;
}

function safeModel(input: unknown, fallback: string) {
  if (typeof input !== "string") return fallback;
  const model = input.trim();
  if (!/^[A-Za-z0-9._:/-]{1,80}$/.test(model)) return fallback;
  return model;
}

function parseChat(body: unknown): {
  messages: Incoming[];
  facts: string[];
  rules: string[];
  lessons: string[];
  search: boolean;
  provider: ProviderId;
  model: string;
  apiKey: string;
  baseUrl: string;
  images: string[];
  tools?: ToolFlags;
} | null {
  if (!body || typeof body !== "object") return null;
  const data = body as {
    messages?: unknown;
    facts?: unknown;
    lessons?: unknown;
    search?: unknown;
    images?: unknown;
    provider?: { id?: unknown; model?: unknown; apiKey?: unknown; baseUrl?: unknown };
  };
  if (!Array.isArray(data.messages) || data.messages.length === 0 || data.messages.length > 14) return null;
  const messages: Incoming[] = [];
  for (const item of data.messages) {
    if (!item || typeof item !== "object") return null;
    const row = item as { role?: unknown; content?: unknown };
    if (row.role !== "user" && row.role !== "assistant") return null;
    if (typeof row.content !== "string") return null;
    const content = row.content.trim().slice(0, 12_000);
    if (!content) return null;
    messages.push({ role: row.role, content });
  }
  if (messages[messages.length - 1]?.role !== "user") return null;
  const facts = Array.isArray(data.facts)
    ? data.facts.filter((fact) => typeof fact === "string").map((fact) => fact.slice(0, 200)).slice(-40)
    : [];
  const rules = Array.isArray((data as { rules?: unknown }).rules)
    ? (data as { rules: unknown[] }).rules.filter((rule) => typeof rule === "string").map((rule) => rule.slice(0, 240)).slice(-40)
    : [];
  const lessons = Array.isArray(data.lessons)
    ? data.lessons.filter((lesson) => typeof lesson === "string").map((lesson) => lesson.slice(0, 240)).slice(-12)
    : [];
  const id = data.provider?.id;
  const provider: ProviderId =
    id === "openai" || id === "anthropic" || id === "deepseek" || id === "openrouter" || id === "xai" ? id : "xai";
  const images = Array.isArray(data.images)
    ? data.images.filter((item) => typeof item === "string" && item.startsWith("data:image/") && item.length < 1_200_000).slice(0, 1)
    : [];
  return {
    messages,
    facts,
    rules,
    lessons,
    search: data.search === true && provider === "xai",
    provider,
    model: safeModel(data.provider?.model, defaultModel(provider)),
    apiKey: typeof data.provider?.apiKey === "string" ? data.provider.apiKey.trim().slice(0, 300) : "",
    baseUrl: safeBase(provider, data.provider?.baseUrl, defaultBase(provider)),
    images,
    tools: toolFlags((data as { tools?: unknown }).tools),
  };
}

function toolFlags(input: unknown): ToolFlags | undefined {
  if (!input || typeof input !== "object") return undefined;
  const row = input as { web?: unknown; terminal?: unknown };
  return { web: row.web === true, terminal: row.terminal === true };
}

function defaultModel(id: ProviderId) {
  if (id === "openai") return "gpt-4o-mini";
  if (id === "anthropic") return "claude-sonnet-4-5";
  if (id === "deepseek") return "deepseek-chat";
  if (id === "openrouter") return "openai/gpt-4o-mini";
  return XAI_MODEL;
}

function keyFor(id: ProviderId, clientKey: string) {
  if (id === "xai") return process.env.XAI_API_KEY || "";
  return clientKey;
}

function defaultBase(id: ProviderId) {
  if (id === "openai") return "https://api.openai.com/v1";
  if (id === "deepseek") return "https://api.deepseek.com";
  if (id === "openrouter") return "https://openrouter.ai/api/v1";
  if (id === "anthropic") return "https://api.anthropic.com";
  return "https://api.x.ai/v1";
}

function isPrivateHost(host: string) {
  const h = host.toLowerCase().replace(/^\[|\]$/g, "");
  if (h === "localhost" || h.endsWith(".localhost") || h.endsWith(".local") || h.endsWith(".internal")) return true;
  if (h === "::1" || h === "::" || /^f[cd][0-9a-f]{2}:/.test(h) || /^fe80:/.test(h)) return true;
  const m = h.match(/^(\d+)\.(\d+)\.(\d+)\.(\d+)$/);
  if (m) {
    const a = Number(m[1]);
    const b = Number(m[2]);
    return a === 0 || a === 10 || a === 127 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168);
  }
  return false;
}

/**
 * The server holds the xAI key, so the xAI provider can never be redirected.
 * Other providers use the key the person typed, so a custom base URL only ever
 * receives their own key. Private and local addresses are refused on a deployed server.
 */
function safeBase(id: ProviderId, input: unknown, fallback: string) {
  if (id === "xai") return fallback;
  if (typeof input !== "string" || !input.trim()) return fallback;
  try {
    const url = new URL(input.trim().slice(0, 200));
    const clean = `${url.origin}${url.pathname}`.replace(/\/$/, "");
    if (url.protocol === "https:") return isPrivateHost(url.hostname) ? fallback : clean;
    const dev = process.env.NODE_ENV !== "production";
    const local = url.hostname === "localhost" || url.hostname === "127.0.0.1";
    if (url.protocol === "http:" && local && dev) return clean;
  } catch {
    /* use fallback */
  }
  return fallback;
}

function chatUrl(id: ProviderId, base: string) {
  if (id === "anthropic") {
    if (/\/v1\/messages$/i.test(base)) return base;
    return `${base.replace(/\/$/, "")}/v1/messages`.replace("https://api.anthropic.com/v1/v1/messages", "https://api.anthropic.com/v1/messages");
  }
  if (/\/chat\/completions$/i.test(base)) return base;
  return `${base.replace(/\/$/, "")}/chat/completions`;
}

function media(dataUrl: string): { mime: string; data: string } | null {
  const match = dataUrl.match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,([A-Za-z0-9+/=]+)$/);
  if (!match) return null;
  return { mime: match[1], data: match[2] };
}

function openAiMessages(messages: Incoming[], system: string, image: string | undefined, allowImage: boolean) {
  const rows: { role: string; content: unknown }[] = [{ role: "system", content: system }];
  messages.forEach((message, index) => {
    const last = index === messages.length - 1 && message.role === "user";
    if (last && image && allowImage) {
      rows.push({
        role: "user",
        content: [
          { type: "text", text: message.content },
          { type: "image_url", image_url: { url: image } },
        ],
      });
      return;
    }
    const note = last && image && !allowImage ? `${message.content}\n(An image was attached.)` : message.content;
    rows.push({ role: message.role, content: note });
  });
  return rows;
}

function anthropicMessages(messages: Incoming[], image: string | undefined) {
  const rows: { role: "user" | "assistant"; content: unknown }[] = [];
  for (const message of messages) {
    if (!rows.length && message.role === "assistant") continue;
    rows.push({ role: message.role, content: message.content });
  }
  const last = rows[rows.length - 1];
  const parsed = image ? media(image) : null;
  if (last && last.role === "user" && parsed) {
    last.content = [
      { type: "image", source: { type: "base64", media_type: parsed.mime, data: parsed.data } },
      { type: "text", text: String(last.content) },
    ];
  }
  return rows;
}

type ChatRequest = {
  messages: Incoming[];
  facts: string[];
  rules: string[];
  lessons: string[];
  search: boolean;
  provider: ProviderId;
  model: string;
  apiKey: string;
  baseUrl: string;
  images: string[];
  tools?: ToolFlags;
};

async function callModel(parsed: ChatRequest, signal: AbortSignal) {
  const key = keyFor(parsed.provider, parsed.apiKey);
  const system = systemPrompt(parsed.facts, parsed.rules, parsed.lessons, parsed.messages) + PICTURE_HINT + toolsPrompt(parsed.tools);
  const image = parsed.images[0];
  if (parsed.provider === "anthropic") {
    return fetch(chatUrl(parsed.provider, parsed.baseUrl), {
      method: "POST",
      signal,
      headers: {
        "content-type": "application/json",
        "x-api-key": key,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: parsed.model,
        max_tokens: 8192,
        temperature: 0.3,
        stream: true,
        system,
        messages: anthropicMessages(parsed.messages, image),
      }),
    });
  }
  const allowImage = parsed.provider !== "deepseek";
  return fetch(chatUrl(parsed.provider, parsed.baseUrl), {
    method: "POST",
    signal,
    headers: {
      Authorization: `Bearer ${key}`,
      "content-type": "application/json",
    },
    body: JSON.stringify({
      model: parsed.model,
      stream: true,
      max_tokens: 8192,
      temperature: 0.3,
      messages: openAiMessages(parsed.messages, system, image, allowImage),
      ...(parsed.search ? { search_parameters: { mode: "on", return_citations: true, max_search_results: 5 } } : {}),
    }),
  });
}

function textOf(event: { choices?: { delta?: { content?: string } }[]; delta?: { text?: string }; type?: string }) {
  const openai = event.choices?.[0]?.delta?.content;
  if (typeof openai === "string" && openai) return openai;
  if (event.type === "content_block_delta" && typeof event.delta?.text === "string") return event.delta.text;
  return "";
}

export async function handleChat(request: Request): Promise<Response> {
  if (limited(request, "chat", 30)) return json({ error: "slow down" }, 429);
  let payload: unknown;
  try {
    payload = await request.json();
  } catch {
    return json({ error: "bad json" }, 400);
  }
  const parsed = parseChat(payload);
  if (!parsed) return json({ error: "bad request" }, 400);
  const key = keyFor(parsed.provider, parsed.apiKey);
  if (!key) return json({ error: parsed.provider === "xai" ? "unavailable" : "missing key" }, parsed.provider === "xai" ? 503 : 400);

  let upstream: Response;
  try {
    upstream = await callModel(parsed, request.signal);
    if (!upstream.ok && parsed.search && upstream.status !== 401 && upstream.status !== 429) {
      parsed.search = false;
      upstream = await callModel(parsed, request.signal);
    }
  } catch {
    if (request.signal.aborted) return new Response(null, { status: 499 });
    return json({ error: "unreachable" }, 502);
  }
  if (!upstream.ok || !upstream.body) return json({ error: "upstream", status: upstream.status }, 502);

  const encoder = new TextEncoder();
  const decoder = new TextDecoder();
  const reader = upstream.body.getReader();
  let buffer = "";
  let cited = false;

  const send = (controller: ReadableStreamDefaultController<Uint8Array>, value: unknown) => {
    controller.enqueue(encoder.encode(`data: ${JSON.stringify(value)}\n\n`));
  };

  const consume = (controller: ReadableStreamDefaultController<Uint8Array>, chunk: string) => {
    buffer += chunk;
    const lines = buffer.split("\n");
    buffer = lines.pop() ?? "";
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed.startsWith("data:")) continue;
      const data = trimmed.slice(5).trim();
      if (!data || data === "[DONE]") continue;
      let event: {
        choices?: { delta?: { content?: string }; finish_reason?: string | null }[];
        citations?: unknown;
        delta?: { text?: string; stop_reason?: string | null };
        type?: string;
      };
      try {
        event = JSON.parse(data) as typeof event;
      } catch {
        continue;
      }
      const delta = textOf(event);
      if (delta) send(controller, { t: "d", c: delta });
      if (event.choices?.[0]?.finish_reason === "length" || event.delta?.stop_reason === "max_tokens") {
        send(controller, { t: "d", c: "\n\n[This reply hit the length limit and was cut off. Ask me to continue, or split the request into smaller pieces.]" });
      }
      if (!cited && Array.isArray(event.citations)) {
        const urls = event.citations.filter((url) => typeof url === "string").slice(0, 5);
        if (urls.length) {
          cited = true;
          send(controller, { t: "cite", urls });
        }
      }
    }
  };

  const stream = new ReadableStream({
    async start(controller) {
      try {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          consume(controller, decoder.decode(value, { stream: true }));
        }
        consume(controller, decoder.decode());
        send(controller, { t: "done" });
        controller.close();
      } catch {
        if (!request.signal.aborted) send(controller, { t: "err", m: "stream failed" });
        try {
          controller.close();
        } catch {
          /* already closed */
        }
      }
    },
    cancel() {
      reader.cancel().catch(() => {});
    },
  });

  return new Response(stream, {
    headers: {
      "content-type": "text/event-stream; charset=utf-8",
      "cache-control": "no-cache, no-transform",
      "x-accel-buffering": "no",
    },
  });
}

export async function handleImage(request: Request): Promise<Response> {
  const apiKey = process.env.XAI_API_KEY || "";
  if (!apiKey) return json({ error: "unavailable" }, 503);
  if (limited(request, "image", 6)) return json({ error: "slow down" }, 429);
  let payload: unknown;
  try {
    payload = await request.json();
  } catch {
    return json({ error: "bad json" }, 400);
  }
  if (!payload || typeof payload !== "object" || (payload as { cloud?: unknown }).cloud !== true) {
    return json({ error: "cloud pictures are off" }, 403);
  }
  const prompt =
    payload && typeof payload === "object" && typeof (payload as { prompt?: unknown }).prompt === "string"
      ? (payload as { prompt: string }).prompt.trim().slice(0, 500)
      : "";
  if (prompt.length < 2) return json({ error: "prompt" }, 400);
  try {
    const res = await fetch("https://api.x.ai/v1/images/generations", {
      method: "POST",
      signal: request.signal,
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: IMAGE_MODEL,
        prompt,
        n: 1,
        response_format: "url",
      }),
    });
    if (!res.ok) return json({ error: "upstream" }, 502);
    const data = (await res.json()) as { data?: { url?: string; b64_json?: string }[] };
    const first = data.data?.[0];
    if (first?.url) return json({ url: first.url });
    if (first?.b64_json && first.b64_json.length < 1_500_000) {
      return json({ url: `data:image/png;base64,${first.b64_json}` });
    }
    return json({ error: "empty" }, 502);
  } catch {
    if (request.signal.aborted) return new Response(null, { status: 499 });
    return json({ error: "unreachable" }, 502);
  }
}
