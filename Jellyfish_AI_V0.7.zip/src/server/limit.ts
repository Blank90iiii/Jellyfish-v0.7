const hits = new Map<string, number[]>();

export function clientIp(request: Request) {
  return request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || request.headers.get("x-real-ip") || "local";
}

/** True when more than `max` requests came from one address in the window. */
export function tooMany(request: Request, bucket: string, max: number, windowMs = 60_000) {
  const id = `${bucket}:${clientIp(request)}`;
  const now = Date.now();
  const recent = (hits.get(id) ?? []).filter((time) => now - time < windowMs);
  if (recent.length >= max) {
    hits.set(id, recent);
    return true;
  }
  recent.push(now);
  hits.set(id, recent);
  if (hits.size > 5000) {
    for (const [key, times] of hits) if (!times.some((time) => now - time < windowMs)) hits.delete(key);
  }
  return false;
}

/** True only for a request made from this same computer: loopback host and no proxy in front. */
export function isLocalRequest(request: Request) {
  try {
    const host = new URL(request.url).hostname;
    const loopback = host === "localhost" || host === "127.0.0.1" || host === "[::1]" || host === "::1";
    return loopback && !request.headers.get("x-forwarded-for") && !request.headers.get("x-real-ip");
  } catch {
    return false;
  }
}

export function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json", "cache-control": "no-store" } });
}
