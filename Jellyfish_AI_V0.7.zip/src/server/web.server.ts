import { lookup } from "node:dns/promises";
import { formatHits, htmlToText, pageTitle, parseBrave, parseDuckDuckGo, parseRss, parseSearx, publicUrl, isPrivateHost, type SearchHit } from "@/lib/jellyfish/web";
import { isLocalRequest, json, tooMany } from "./limit";

const MAX_BYTES = 1_000_000;
const UA = "Mozilla/5.0 (compatible; JellyfishAI/1.0)";

/** Fetches a public page. Every redirect is re-checked, and the hostname's real addresses must be public too. */
async function safeFetch(start: URL, init: RequestInit, allowPrivate: boolean): Promise<{ status: number; type: string; body: string }> {
  let url = start;
  for (let hop = 0; hop < 4; hop += 1) {
    if (!allowPrivate) {
      const addresses = await lookup(url.hostname, { all: true }).catch(() => []);
      if (!addresses.length) throw new Error("Couldn't look that address up. Is the computer online?");
      if (addresses.some((item) => isPrivateHost(item.address))) throw new Error("blocked address");
    }
    const response = await fetch(url, { ...init, redirect: "manual", signal: AbortSignal.timeout(10_000), headers: { "user-agent": UA, ...(init.headers ?? {}) } });
    if (response.status >= 300 && response.status < 400 && response.headers.get("location")) {
      const next = publicUrl(new URL(response.headers.get("location") as string, url).toString(), allowPrivate);
      if (!next) throw new Error("blocked redirect");
      url = next;
      continue;
    }
    const reader = response.body?.getReader();
    let size = 0;
    const parts: Uint8Array[] = [];
    while (reader) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.length;
      parts.push(value);
      if (size > MAX_BYTES) {
        await reader.cancel();
        break;
      }
    }
    return { status: response.status, type: response.headers.get("content-type") ?? "", body: new TextDecoder().decode(Buffer.concat(parts)) };
  }
  throw new Error("too many redirects");
}

type SearchCfg = { id?: unknown; key?: unknown; url?: unknown };

async function search(op: "search" | "news", query: string, cfg: SearchCfg, local: boolean): Promise<SearchHit[]> {
  const q = encodeURIComponent(query);
  const id = cfg.id === "brave" || cfg.id === "searx" ? cfg.id : "ddg";
  if (id === "brave" && typeof cfg.key === "string" && cfg.key) {
    const path = op === "news" ? "news/search" : "web/search";
    const url = publicUrl(`https://api.search.brave.com/res/v1/${path}?q=${q}&count=8`);
    if (!url) return [];
    const res = await safeFetch(url, { headers: { accept: "application/json", "x-subscription-token": cfg.key.slice(0, 300) } }, false);
    return parseBrave(JSON.parse(res.body));
  }
  if (id === "searx" && typeof cfg.url === "string" && cfg.url) {
    const base = cfg.url.replace(/\/$/, "");
    const url = publicUrl(`${base}/search?q=${q}&format=json${op === "news" ? "&categories=news" : ""}`, local);
    if (!url) throw new Error("That SearXNG address isn't allowed here.");
    const res = await safeFetch(url, { headers: { accept: "application/json" } }, local);
    return parseSearx(JSON.parse(res.body));
  }
  if (op === "news") {
    const url = publicUrl(query ? `https://news.google.com/rss/search?q=${q}&hl=en-US&gl=US&ceid=US:en` : "https://news.google.com/rss?hl=en-US&gl=US&ceid=US:en");
    if (!url) return [];
    return parseRss((await safeFetch(url, {}, false)).body);
  }
  const url = publicUrl(`https://html.duckduckgo.com/html/?q=${q}`);
  if (!url) return [];
  return parseDuckDuckGo((await safeFetch(url, {}, false)).body);
}

export async function handleWeb(request: Request): Promise<Response> {
  if (tooMany(request, "web", 20)) return json({ ok: false, error: "slow down" }, 429);
  let data: { op?: unknown; q?: unknown; url?: unknown; provider?: SearchCfg };
  try {
    data = await request.json();
  } catch {
    return json({ ok: false, error: "bad json" }, 400);
  }
  const op = data.op;
  try {
    if (op === "search" || op === "news") {
      const q = typeof data.q === "string" ? data.q.trim().slice(0, 200) : "";
      if (op === "search" && !q) return json({ ok: false, error: "empty query" }, 400);
      const hits = await search(op, q, data.provider ?? {}, isLocalRequest(request));
      return json({ ok: true, text: formatHits(hits), count: hits.length });
    }
    if (op === "read") {
      const url = typeof data.url === "string" ? publicUrl(data.url) : null;
      if (!url) return json({ ok: false, error: "That address isn't allowed (public http/https only)." }, 400);
      const res = await safeFetch(url, {}, false);
      if (res.status >= 400) return json({ ok: false, error: `The page answered ${res.status}.` });
      if (!/text\/|json|xml/i.test(res.type)) return json({ ok: false, error: `Not a text page (${res.type || "unknown type"}).` });
      const text = /html/i.test(res.type) ? htmlToText(res.body) : res.body.slice(0, 8000);
      return json({ ok: true, text: `${pageTitle(res.body) ? `Title: ${pageTitle(res.body)}\n` : ""}${text}` });
    }
    return json({ ok: false, error: "unknown op" }, 400);
  } catch (error) {
    return json({ ok: false, error: error instanceof Error ? error.message.slice(0, 160) : "failed" });
  }
}
