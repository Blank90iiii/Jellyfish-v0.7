import { spawn } from "node:child_process";
import { mkdir, readdir, readFile, stat, writeFile } from "node:fs/promises";
import { homedir } from "node:os";
import { dirname, join, normalize, sep } from "node:path";
import { isLocalRequest, json, tooMany } from "./limit";

const DENY = [
  /\brm\s+-[a-z]*r[a-z]*f?\s+(\/|~|\$HOME|\*)(\s|$)/i,
  /\bmkfs\b/i,
  /\bdd\s+if=/i,
  /\bformat\s+[a-z]:/i,
  /\bdel\s+\/[sq]/i,
  /\brd\s+\/s/i,
  /:\(\)\s*\{/,
  /\b(shutdown|reboot|halt|poweroff)\b/i,
  />\s*\/dev\/sd/i,
  /\breg\s+(delete|add)\b/i,
];

const SKIP = new Set(["node_modules", ".git", ".next", "dist", ".output", ".vercel"]);

function safeRel(path: string) {
  const clean = normalize(path.replace(/\\/g, "/")).replace(/^(\.\.[/\\])+/, "");
  if (!clean || clean.startsWith("..") || clean.startsWith("/") || /^[a-z]:/i.test(clean)) return null;
  return clean;
}

function cleanEnv() {
  const env: Record<string, string> = {};
  for (const [key, value] of Object.entries(process.env)) {
    if (value === undefined) continue;
    if (/key|token|secret|password|database_url|auth/i.test(key)) continue;
    env[key] = value;
  }
  return env;
}

async function walk(root: string, rel = "", out: string[] = []): Promise<string[]> {
  for (const entry of await readdir(join(root, rel), { withFileTypes: true })) {
    if (SKIP.has(entry.name)) continue;
    const next = rel ? `${rel}/${entry.name}` : entry.name;
    if (entry.isDirectory()) await walk(root, next, out);
    else out.push(next);
    if (out.length > 400) break;
  }
  return out;
}

export function terminalEnabled() {
  return process.env.JELLYFISH_TERMINAL === "1";
}

export async function handleRun(request: Request): Promise<Response> {
  if (!terminalEnabled() || !isLocalRequest(request)) {
    return json({ ok: false, error: "The terminal is off. It only works on your own computer, started with JELLYFISH_TERMINAL=1." }, 403);
  }
  if (tooMany(request, "run", 20)) return json({ ok: false, error: "slow down" }, 429);
  let data: { projectId?: unknown; command?: unknown; files?: unknown };
  try {
    data = await request.json();
  } catch {
    return json({ ok: false, error: "bad json" }, 400);
  }
  const command = typeof data.command === "string" ? data.command.trim() : "";
  if (!command || command.length > 500 || /[\r\n]/.test(command)) return json({ ok: false, error: "One command, up to 500 characters." }, 400);
  if (DENY.some((pattern) => pattern.test(command))) return json({ ok: false, error: "That command is blocked for safety." }, 400);
  const id = typeof data.projectId === "string" ? data.projectId.replace(/[^a-z0-9-]/gi, "").slice(0, 60) : "";
  if (!id) return json({ ok: false, error: "missing project" }, 400);

  const base = process.env.JELLYFISH_DATA || join(homedir(), ".jellyfish");
  const dir = join(base, "workspaces", id);
  await mkdir(dir, { recursive: true });

  const sent = new Map<string, string>();
  if (Array.isArray(data.files)) {
    for (const item of data.files.slice(0, 200)) {
      const row = item as { path?: unknown; content?: unknown };
      if (typeof row.path !== "string" || typeof row.content !== "string" || row.content.length > 300_000) continue;
      const rel = safeRel(row.path);
      if (!rel) continue;
      const target = join(dir, rel);
      if (!target.startsWith(dir + sep)) continue;
      await mkdir(dirname(target), { recursive: true });
      await writeFile(target, row.content);
      sent.set(rel.replace(/\\/g, "/"), row.content);
    }
  }

  const result = await new Promise<{ code: number | null; out: string; err: string; timedOut: boolean }>((resolve) => {
    const child = spawn(command, { shell: true, cwd: dir, env: cleanEnv() });
    let out = "";
    let err = "";
    let timedOut = false;
    const timer = setTimeout(() => {
      timedOut = true;
      child.kill("SIGKILL");
    }, 60_000);
    child.stdout.on("data", (chunk: Buffer) => {
      if (out.length < 20_000) out += chunk.toString();
    });
    child.stderr.on("data", (chunk: Buffer) => {
      if (err.length < 20_000) err += chunk.toString();
    });
    child.on("error", (e) => {
      err += String(e.message);
    });
    child.on("close", (code) => {
      clearTimeout(timer);
      resolve({ code, out: out.slice(0, 6000), err: err.slice(0, 4000), timedOut });
    });
  });

  const changed: { path: string; content: string }[] = [];
  try {
    for (const rel of await walk(dir)) {
      const full = join(dir, rel);
      const info = await stat(full);
      if (info.size > 100_000 || changed.length >= 30) continue;
      const text = await readFile(full, "utf8");
      if (text.includes("\u0000")) continue;
      if (sent.get(rel) !== text) changed.push({ path: rel, content: text });
    }
  } catch {
    /* listing is best effort */
  }
  return json({ ok: true, code: result.code, stdout: result.out, stderr: result.err, timedOut: result.timedOut, changed });
}
