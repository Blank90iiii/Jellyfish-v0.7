import { createFileRoute } from "@tanstack/react-router";
import { JellyfishApp } from "@/components/jellyfish/app";

export const Route = createFileRoute("/")({ component: JellyfishApp });
