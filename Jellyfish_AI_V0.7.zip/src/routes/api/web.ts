import { createFileRoute } from "@tanstack/react-router";
import { handleWeb } from "@/server/web.server";

export const Route = createFileRoute("/api/web")({
  server: {
    handlers: {
      POST: ({ request }) => handleWeb(request),
    },
  },
});
