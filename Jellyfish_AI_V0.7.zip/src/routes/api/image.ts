import { createFileRoute } from "@tanstack/react-router";
import { handleImage } from "@/server/ai.server";

export const Route = createFileRoute("/api/image")({
  server: {
    handlers: {
      POST: ({ request }) => handleImage(request),
    },
  },
});
