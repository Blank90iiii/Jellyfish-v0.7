import { createFileRoute } from "@tanstack/react-router";
import { handleRun } from "@/server/run.server";

export const Route = createFileRoute("/api/run")({
  server: {
    handlers: {
      POST: ({ request }) => handleRun(request),
    },
  },
});
