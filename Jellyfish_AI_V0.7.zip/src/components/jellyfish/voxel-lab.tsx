import { useEffect, useRef, useState } from "react";
import { breakSound, placeSound } from "@/lib/jellyfish/audio";
import { pushLog } from "@/lib/jellyfish/console-bus";
import { ConsoleDock } from "./console-dock";

const X = 12;
const Y = 8;
const Z = 12;
const ORANGE = 0xff6b00;

type Kind = 0 | 1 | 2 | 3 | 4;

const COLORS: Record<Exclude<Kind, 0>, number> = {
  1: 0x6f8f4e,
  2: 0x8a5a3a,
  3: 0x8d8d8d,
  4: ORANGE,
};

function index(x: number, y: number, z: number) {
  return x + X * (y + Y * z);
}

function inside(x: number, y: number, z: number) {
  return x >= 0 && y >= 0 && z >= 0 && x < X && y < Y && z < Z;
}

function freshGrid(): Uint8Array {
  const grid = new Uint8Array(X * Y * Z);
  for (let z = 0; z < Z; z++) {
    for (let x = 0; x < X; x++) {
      grid[index(x, 0, z)] = 3;
      grid[index(x, 1, z)] = 2;
      grid[index(x, 2, z)] = 1;
    }
  }
  grid[index(6, 3, 6)] = 4;
  return grid;
}

export function VoxelLab() {
  const host = useRef<HTMLDivElement>(null);
  const gridRef = useRef<Uint8Array>(freshGrid());
  const modeRef = useRef<"break" | "place">("break");
  const paintRef = useRef<Exclude<Kind, 0>>(4);
  const soundRef = useRef(true);
  const [mode, setMode] = useState<"break" | "place">("break");
  const [paint, setPaint] = useState<Exclude<Kind, 0>>(4);
  const [sound, setSound] = useState(true);
  const [count, setCount] = useState(() => gridRef.current.reduce((sum, cell) => sum + (cell ? 1 : 0), 0));

  useEffect(() => {
    modeRef.current = mode;
  }, [mode]);
  useEffect(() => {
    paintRef.current = paint;
  }, [paint]);
  useEffect(() => {
    soundRef.current = sound;
  }, [sound]);

  useEffect(() => {
    const el = host.current;
    if (!el) return;
    let dead = false;
    let cleanup = () => {};
    void import("three").then((THREE) => {
      if (dead || !host.current) return;
      const canvas = document.createElement("canvas");
      canvas.className = "h-full w-full touch-none";
      host.current.appendChild(canvas);
      const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
      renderer.setClearColor(0x0a0a0a, 1);
      const scene = new THREE.Scene();
      const camera = new THREE.PerspectiveCamera(50, 1, 0.1, 80);
      const ambient = new THREE.AmbientLight(0xffffff, 0.55);
      const sunLight = new THREE.DirectionalLight(0xfff1e0, 0.9);
      sunLight.position.set(12, 18, 8);
      scene.add(ambient, sunLight);

      const kinds = [1, 2, 3, 4] as const;
      const meshes = new Map<Exclude<Kind, 0>, import("three").InstancedMesh>();
      const geo = new THREE.BoxGeometry(0.96, 0.96, 0.96);
      for (const kind of kinds) {
        const material = new THREE.MeshStandardMaterial({ color: COLORS[kind], roughness: 0.72 });
        const mesh = new THREE.InstancedMesh(geo, material, X * Y * Z);
        mesh.count = 0;
        mesh.userData.kind = kind;
        scene.add(mesh);
        meshes.set(kind, mesh);
      }

      const system = new THREE.Group();
      const sun = new THREE.Mesh(
        new THREE.SphereGeometry(0.38, 20, 16),
        new THREE.MeshStandardMaterial({ color: ORANGE, emissive: ORANGE, emissiveIntensity: 0.8 }),
      );
      const planetPivot = new THREE.Group();
      const planet = new THREE.Mesh(
        new THREE.SphereGeometry(0.18, 16, 12),
        new THREE.MeshStandardMaterial({ color: 0xe0e0e0 }),
      );
      planet.position.set(1.5, 0, 0);
      const moon = new THREE.Mesh(
        new THREE.SphereGeometry(0.08, 12, 10),
        new THREE.MeshStandardMaterial({ color: ORANGE }),
      );
      moon.position.set(0.42, 0, 0);
      planet.add(moon);
      planetPivot.add(planet);
      system.add(sun, planetPivot);
      system.position.set(6, 6.2, 6);
      scene.add(system);

      const dummy = new THREE.Object3D();
      const lists = new Map<Exclude<Kind, 0>, { x: number; y: number; z: number }[]>();

      function rebuild() {
        lists.clear();
        for (const kind of meshes.keys()) lists.set(kind, []);
        const grid = gridRef.current;
        for (let z = 0; z < Z; z++) {
          for (let y = 0; y < Y; y++) {
            for (let x = 0; x < X; x++) {
              const kind = grid[index(x, y, z)] as Kind;
              if (!kind) continue;
              lists.get(kind)?.push({ x, y, z });
            }
          }
        }
        let total = 0;
        for (const [kind, mesh] of meshes) {
          const cells = lists.get(kind) ?? [];
          cells.forEach((cell, i) => {
            dummy.position.set(cell.x, cell.y, cell.z);
            dummy.updateMatrix();
            mesh.setMatrixAt(i, dummy.matrix);
          });
          mesh.count = cells.length;
          mesh.instanceMatrix.needsUpdate = true;
          total += cells.length;
        }
        setCount(total);
      }
      rebuild();

      let yaw = 0.7;
      let pitch = 0.55;
      let dist = 18;
      function frameCamera() {
        camera.position.set(
          6 + Math.sin(yaw) * Math.cos(pitch) * dist,
          2 + Math.sin(pitch) * dist,
          6 + Math.cos(yaw) * Math.cos(pitch) * dist,
        );
        camera.lookAt(6, 1.5, 6);
      }
      frameCamera();

      const raycaster = new THREE.Raycaster();
      const pointer = new THREE.Vector2();
      let dragging = false;
      let moved = false;
      let lastX = 0;
      let lastY = 0;

      function resize() {
        const rect = canvas.getBoundingClientRect();
        renderer.setSize(rect.width, rect.height, false);
        camera.aspect = Math.max(rect.width, 1) / Math.max(rect.height, 1);
        camera.updateProjectionMatrix();
      }
      resize();
      const observer = new ResizeObserver(resize);
      observer.observe(canvas);

      function pick(clientX: number, clientY: number) {
        const rect = canvas.getBoundingClientRect();
        pointer.x = ((clientX - rect.left) / rect.width) * 2 - 1;
        pointer.y = -((clientY - rect.top) / rect.height) * 2 + 1;
        raycaster.setFromCamera(pointer, camera);
        const hits = raycaster.intersectObjects([...meshes.values()], false);
        return hits.find((hit) => hit.instanceId != null) ?? null;
      }

      function edit(clientX: number, clientY: number) {
        const hit = pick(clientX, clientY);
        if (!hit || hit.instanceId == null) return;
        const kind = hit.object.userData.kind as Exclude<Kind, 0>;
        const cell = lists.get(kind)?.[hit.instanceId];
        if (!cell) return;
        const grid = gridRef.current;
        if (modeRef.current === "break") {
          grid[index(cell.x, cell.y, cell.z)] = 0;
          if (soundRef.current) breakSound();
          pushLog("log", `Broke ${cell.x},${cell.y},${cell.z}`, "lab");
        } else if (hit.face) {
          const nx = cell.x + Math.round(hit.face.normal.x);
          const ny = cell.y + Math.round(hit.face.normal.y);
          const nz = cell.z + Math.round(hit.face.normal.z);
          if (inside(nx, ny, nz) && grid[index(nx, ny, nz)] === 0) {
            grid[index(nx, ny, nz)] = paintRef.current;
            if (soundRef.current) placeSound();
            pushLog("log", `Placed ${nx},${ny},${nz}`, "lab");
          }
        }
        rebuild();
      }

      function onPointerDown(event: PointerEvent) {
        dragging = true;
        moved = false;
        lastX = event.clientX;
        lastY = event.clientY;
        canvas.setPointerCapture(event.pointerId);
      }
      function onPointerMove(event: PointerEvent) {
        if (!dragging) return;
        const dx = event.clientX - lastX;
        const dy = event.clientY - lastY;
        if (Math.abs(dx) + Math.abs(dy) > 3) moved = true;
        lastX = event.clientX;
        lastY = event.clientY;
        if (!moved) return;
        yaw -= dx * 0.008;
        pitch = Math.max(0.15, Math.min(1.2, pitch + dy * 0.006));
        frameCamera();
      }
      function onPointerUp(event: PointerEvent) {
        if (!dragging) return;
        dragging = false;
        if (!moved) {
          const previous = modeRef.current;
          if (event.button === 2) modeRef.current = "place";
          edit(event.clientX, event.clientY);
          modeRef.current = previous;
        }
      }
      canvas.addEventListener("pointerdown", onPointerDown);
      canvas.addEventListener("pointermove", onPointerMove);
      canvas.addEventListener("pointerup", onPointerUp);
      canvas.addEventListener("contextmenu", (event) => event.preventDefault());
      canvas.addEventListener(
        "wheel",
        (event) => {
          dist = Math.max(8, Math.min(32, dist + Math.sign(event.deltaY) * 0.8));
          frameCamera();
        },
        { passive: true },
      );

      const clock = new THREE.Clock();
      let frame = 0;
      function tick() {
        const t = clock.getElapsedTime();
        // Nested orbit: planet angle w*t around the sun, moon angle k*t around the planet.
        planetPivot.rotation.y = t * 0.55;
        planet.rotation.y = t * 1.7;
        frame = requestAnimationFrame(tick);
        renderer.render(scene, camera);
      }
      tick();
      pushLog("info", "3D lab ready. Drag to orbit. Tap to break or place.", "lab");

      cleanup = () => {
        cancelAnimationFrame(frame);
        observer.disconnect();
        canvas.remove();
        geo.dispose();
        for (const mesh of meshes.values()) {
          const material = mesh.material;
          if (Array.isArray(material)) material.forEach((item) => item.dispose());
          else material.dispose();
        }
        renderer.dispose();
      };
    });
    return () => {
      dead = true;
      cleanup();
    };
  }, []);

  return (
    <section className="flex min-h-0 flex-1 flex-col">
      <div className="flex flex-wrap items-center gap-2 border-b border-line px-3 py-2">
        <button
          type="button"
          className={"min-h-11 px-3 text-sm " + (mode === "break" ? "bg-accent text-accent-fg" : "text-muted")}
          onClick={() => setMode("break")}
        >
          Break
        </button>
        <button
          type="button"
          className={"min-h-11 px-3 text-sm " + (mode === "place" ? "bg-accent text-accent-fg" : "text-muted")}
          onClick={() => setMode("place")}
        >
          Place
        </button>
        {([1, 2, 3, 4] as const).map((kind) => (
          <button
            key={kind}
            type="button"
            aria-label={kind === 4 ? "Orange block" : `Block ${kind}`}
            className={"size-11 border " + (paint === kind ? "border-accent" : "border-line")}
            style={{ background: `#${COLORS[kind].toString(16).padStart(6, "0")}` }}
            onClick={() => setPaint(kind)}
          />
        ))}
        <button type="button" className="min-h-11 px-3 text-sm text-fg" onClick={() => setSound((value) => !value)}>
          {sound ? "Sound on" : "Sound off"}
        </button>
        <p className="ml-auto text-sm text-muted">{count} blocks</p>
      </div>
      <div ref={host} className="min-h-0 flex-1" />
      <ConsoleDock />
    </section>
  );
}
