import { Moon, Sun } from "lucide-react";

/** Quick Day/Night switch. The editor reads the same theme, so they stay in sync. */
export function ThemeToggle({ theme, onTheme }: { theme: "dark" | "light"; onTheme: (theme: "dark" | "light") => void }) {
  const night = theme === "dark";
  return (
    <button
      type="button"
      onClick={() => onTheme(night ? "light" : "dark")}
      aria-label={night ? "Switch to day" : "Switch to night"}
      aria-pressed={night}
      className="inline-flex min-h-11 items-center gap-2 text-sm text-fg"
    >
      {night ? <Moon className="size-4" /> : <Sun className="size-4" />}
      {night ? "Night" : "Day"}
    </button>
  );
}
