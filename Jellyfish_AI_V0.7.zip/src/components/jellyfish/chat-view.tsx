import { TelemetryPanel } from "./telemetry-panel";
import { useRef, useState } from "react";
import { Camera, ClipboardList, FileText, ImagePlus, Plus, Send, Square, X } from "lucide-react";
import type { Attachment, Chat } from "@/lib/jellyfish/store";
import type { Project } from "@/lib/jellyfish/parse";
import type { SidecarItem } from "@/lib/jellyfish/model";
import { MessageBody } from "./message-body";

const SUGGESTIONS = ["What is your name?", "Make me a simple snake game", "Write a JS two-sum"];

export function ChatView({
  chat,
  projectName,
  draft,
  streaming,
  activity,
  attachments,
  notice,
  proposal,
  planFirst,
  planHold,
  sidecar,
  onSidecar,
  onDraft,
  onSend,
  onStop,
  onAttach,
  onRemove,
  onApplyProposal,
  onDismissProposal,
  onPlanFirst,
  onApprovePlan,
  onOpen,
  onPreview,
  onZip,
}: {
  chat: Chat;
  projectName: string;
  draft: string;
  streaming: boolean;
  activity: string;
  attachments: Attachment[];
  notice: string;
  proposal: string;
  planFirst: boolean;
  planHold: boolean;
  sidecar: SidecarItem[];
  onSidecar: (text: string) => { ok: boolean; note: string };
  onDraft: (value: string) => void;
  onSend: (value: string) => void;
  onStop: () => void;
  onAttach: (files: FileList | null) => void;
  onRemove: (id: string) => void;
  onApplyProposal: () => void;
  onDismissProposal: () => void;
  onPlanFirst: (on: boolean) => void;
  onApprovePlan: () => void;
  onOpen: (project: Project) => void;
  onPreview: (project: Project) => void;
  onZip: (project: Project) => void;
}) {
  const empty = chat.messages.length === 0;
  const [menu, setMenu] = useState(false);
  const cameraRef = useRef<HTMLInputElement>(null);
  const photoRef = useRef<HTMLInputElement>(null);
  const docRef = useRef<HTMLInputElement>(null);

  function take(files: FileList | null) {
    setMenu(false);
    onAttach(files);
  }

  return (
    <section className="flex min-h-0 min-w-0 flex-1 flex-col">
      <div className="min-h-0 flex-1 overflow-y-auto px-4" data-chat-scroll>
        {empty ? (
          <div className="mx-auto flex min-h-full max-w-lg flex-col justify-center gap-6 py-10">
            <div>
              <p className="text-xs tracking-widest text-muted uppercase">{projectName}</p>
              <h1 className="mt-2 text-4xl font-semibold tracking-tight text-fg">Ask me straight.</h1>
              <p className="mt-3 max-w-md text-base leading-relaxed text-muted">
                Chats, files, and lessons stay on this device. Your pinned rules apply to every reply. A game shows up beside the chat.
              </p>
            </div>
            <div className="flex flex-col">
              {SUGGESTIONS.map((prompt) => (
                <button key={prompt} type="button" onClick={() => onSend(prompt)} className="min-h-12 border-t border-line py-3 text-left text-fg">
                  {prompt}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="mx-auto flex max-w-3xl flex-col gap-6 py-6">
            {chat.messages.map((message) =>
              message.role === "user" ? (
                <div key={message.id} className="flex flex-col items-end gap-2">
                  <span className="text-xs tracking-widest text-muted">YOU</span>
                  {message.attachments?.map((item) =>
                    item.dataUrl ? (
                      <img key={item.id} src={item.dataUrl} alt={item.name} className="max-h-40 max-w-xs border border-line object-contain" />
                    ) : (
                      <p key={item.id} className="font-mono text-xs text-muted">
                        {item.name}
                      </p>
                    ),
                  )}
                  {message.text ? <p className="max-w-lg text-right text-fg">{message.text}</p> : null}
                </div>
              ) : (
                <div key={message.id} className="flex flex-col items-start gap-1">
                  <span className="text-xs tracking-widest text-muted">JELLYFISH</span>
                  <div className="w-full text-fg">
                    <MessageBody
                      raw={message.text}
                      pending={message.pending}
                      imageUrl={message.imageUrl}
                      checks={message.checks}
                      activity={activity}
                      onOpen={onOpen}
                      onPreview={onPreview}
                      onZip={onZip}
                    />
                  </div>
                </div>
              ),
            )}
          </div>
        )}
      </div>

      {planHold ? (
        <div className="border-t border-line px-4 py-3">
          <p className="text-sm text-fg">Plan is ready. Nothing is written until you approve it.</p>
          <button type="button" className="mt-2 min-h-11 bg-accent px-4 text-sm text-accent-fg" onClick={onApprovePlan}>
            Approve and write the code
          </button>
        </div>
      ) : null}
      {proposal ? (
        <div className="border-t border-line px-4 py-3">
          <p className="text-sm text-fg">{proposal}</p>
          <div className="mt-2 flex gap-2">
            <button type="button" className="min-h-11 bg-accent px-4 text-sm text-accent-fg" onClick={onApplyProposal}>
              Apply
            </button>
            <button type="button" className="min-h-11 px-3 text-sm text-muted" onClick={onDismissProposal}>
              Not now
            </button>
          </div>
        </div>
      ) : null}

      <TelemetryPanel />
      {streaming ? <SidecarBox queue={sidecar} onAsk={onSidecar} /> : null}
      <form
        className="safe-bottom relative border-t border-line px-3 pt-3"
        onSubmit={(event) => {
          event.preventDefault();
          if (streaming) onStop();
          else onSend(draft);
        }}
      >
        <div className="mx-auto flex max-w-3xl flex-col gap-2">
          {notice ? <p className="text-sm text-danger">{notice}</p> : null}
          {attachments.length ? (
            <div className="flex flex-wrap gap-2">
              {attachments.map((item) => (
                <span key={item.id} className="inline-flex items-center gap-2 border border-line px-2 py-1 text-xs text-fg">
                  {item.name}
                  <button type="button" aria-label={`Remove ${item.name}`} onClick={() => onRemove(item.id)}>
                    <X className="size-3.5" />
                  </button>
                </span>
              ))}
            </div>
          ) : null}
          <div className="flex items-end gap-2">
            <div className="relative">
              <button
                type="button"
                aria-label="Attach a file"
                className="inline-flex size-11 items-center justify-center text-muted"
                onClick={() => setMenu((open) => !open)}
              >
                <Plus className="size-5" />
              </button>
              {menu ? (
                <div className="absolute bottom-12 left-0 z-20 w-44 border border-line bg-surface">
                  <button type="button" className="flex min-h-11 w-full items-center gap-2 px-3 text-left text-sm text-fg" onClick={() => cameraRef.current?.click()}>
                    <Camera className="size-4" /> Camera
                  </button>
                  <button type="button" className="flex min-h-11 w-full items-center gap-2 px-3 text-left text-sm text-fg" onClick={() => photoRef.current?.click()}>
                    <ImagePlus className="size-4" /> Photo
                  </button>
                  <button type="button" className="flex min-h-11 w-full items-center gap-2 px-3 text-left text-sm text-fg" onClick={() => docRef.current?.click()}>
                    <FileText className="size-4" /> Document
                  </button>
                </div>
              ) : null}
              <input ref={cameraRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={(event) => take(event.target.files)} />
              <input ref={photoRef} type="file" accept="image/*" className="hidden" onChange={(event) => take(event.target.files)} />
              <input ref={docRef} type="file" accept="*/*" className="hidden" onChange={(event) => take(event.target.files)} />
            </div>
            <textarea
              value={draft}
              rows={1}
              placeholder="Message Jellyfish AI..."
              className="max-h-32 min-h-11 flex-1 resize-none border border-line bg-transparent px-3 py-3 text-fg outline-none placeholder:text-muted"
              onChange={(event) => {
                onDraft(event.target.value);
                event.target.style.height = "auto";
                event.target.style.height = `${Math.min(event.target.scrollHeight, 128)}px`;
              }}
              onKeyDown={(event) => {
                if (event.key === "Enter" && !event.shiftKey) {
                  event.preventDefault();
                  if (!streaming) onSend(draft);
                }
              }}
            />
            {streaming ? (
              <button
                type="button"
                onClick={onStop}
                aria-label="Force stop"
                className="min-h-11 shrink-0 border-2 border-[#ff2d2d] bg-transparent px-3 text-xs font-black tracking-widest text-[#ff2d2d] uppercase"
              >
                FORCE STOP
              </button>
            ) : null}
            <button
              type="button"
              aria-pressed={planFirst}
              aria-label={planFirst ? "Plan first is on" : "Plan first is off"}
              title="Plan first: checklist before any code"
              className={"inline-flex size-11 items-center justify-center " + (planFirst ? "text-accent" : "text-muted")}
              onClick={() => onPlanFirst(!planFirst)}
            >
              <ClipboardList className="size-5" />
            </button>
            <button
              type="submit"
              className="inline-flex min-h-11 items-center gap-2 bg-accent px-4 text-sm font-medium text-accent-fg disabled:opacity-40"
              disabled={!streaming && !draft.trim() && attachments.length === 0}
            >
              {streaming ? <Square className="size-4" /> : <Send className="size-4" />}
              {streaming ? "Stop" : "Send"}
            </button>
          </div>
          <p className="pb-1 text-xs text-muted">Max size 10MB</p>
        </div>
      </form>
    </section>
  );
}

/*
  The sidecar: a second, small input that only shows while a build is running.
  A question typed here waits in a queue and is answered between build steps.
*/
function SidecarBox({ queue, onAsk }: { queue: SidecarItem[]; onAsk: (text: string) => { ok: boolean; note: string } }) {
  const [text, setText] = useState("");
  const [note, setNote] = useState("");

  return (
    <form
      className="border-t border-line px-3 py-2"
      onSubmit={(event) => {
        event.preventDefault();
        if (!text.trim()) return;
        const result = onAsk(text);
        setNote(result.note);
        if (result.ok) setText("");
      }}
    >
      <div className="mx-auto flex max-w-3xl flex-col gap-1">
        <label htmlFor="sidecar-input" className="text-xs tracking-widest text-muted uppercase">
          Side question
        </label>
        <div className="flex items-center gap-2">
          <input
            id="sidecar-input"
            value={text}
            placeholder="Ask something while it builds..."
            className="min-h-11 min-w-0 flex-1 border border-line bg-transparent px-3 text-sm text-fg outline-none placeholder:text-muted"
            onChange={(event) => setText(event.target.value)}
          />
          <button type="submit" className="min-h-11 shrink-0 border border-line px-3 text-sm text-fg disabled:opacity-40" disabled={!text.trim()}>
            Ask
          </button>
        </div>
        {queue.length ? (
          <ul className="flex flex-col text-xs text-muted">
            {queue.map((item, index) => (
              <li key={item.id} className="truncate">
                Waiting {index + 1}: {item.text}
              </li>
            ))}
          </ul>
        ) : null}
        {note ? <p className="text-xs text-muted">{note}</p> : null}
      </div>
    </form>
  );
}
