import { useEffect, useRef } from "react";
import { Braces, X } from "lucide-react";
import type { ProjectFile } from "@/lib/jellyfish/parse";
import { buildPreview } from "@/lib/jellyfish/preview";

export function ArtifactPane({
  name,
  files,
  onClose,
  onOpenCode,
}: {
  name: string;
  files: ProjectFile[];
  onClose: () => void;
  onOpenCode: () => void;
}) {
  const frame = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    if (frame.current) frame.current.srcdoc = buildPreview(files);
  }, [files]);

  return (
    <section className="flex min-h-0 min-w-0 flex-1 flex-col border-t border-line md:w-1/2 md:flex-none md:border-t-0 md:border-l">
      <div className="flex items-center gap-2 border-b border-line px-4">
        <p className="min-w-0 flex-1 truncate py-3 text-sm text-fg">{name}</p>
        <button type="button" onClick={onOpenCode} className="inline-flex min-h-11 items-center gap-2 text-sm text-accent">
          <Braces className="size-4" />
          Code
        </button>
        <button type="button" onClick={onClose} aria-label="Close preview" className="inline-flex size-11 items-center justify-center text-muted">
          <X className="size-4" />
        </button>
      </div>
      <iframe ref={frame} title={`${name} preview`} sandbox="allow-scripts allow-modals" className="min-h-0 w-full flex-1 border-0 bg-bg" />
    </section>
  );
}
