import { useEffect, useRef, useState } from "react";
import { LOCAL_PRESETS, ollamaPull, ollamaTags, type LocalModel } from "@/lib/jellyfish/ollama";

export function LocalBrain({
  baseUrl,
  model,
  onUseModel,
}: {
  baseUrl: string;
  model: string;
  onUseModel: (model: string) => void;
}) {
  const [installed, setInstalled] = useState<LocalModel[] | null | undefined>(undefined);
  const [busy, setBusy] = useState("");
  const [fraction, setFraction] = useState<number | null>(null);
  const [status, setStatus] = useState("");
  const [note, setNote] = useState("");
  const abortRef = useRef<AbortController | null>(null);

  async function refresh() {
    setInstalled(undefined);
    setInstalled(await ollamaTags(baseUrl));
  }

  useEffect(() => {
    void refresh();
    return () => abortRef.current?.abort();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [baseUrl]);

  const has = (name: string) => !!installed?.some((item) => item.name === name || item.name === `${name}:latest`);

  async function download(name: string) {
    const controller = new AbortController();
    abortRef.current = controller;
    setBusy(name);
    setNote("");
    setFraction(null);
    const failure = await ollamaPull(
      baseUrl,
      name,
      (next, line) => {
        setFraction(next);
        setStatus(line);
      },
      controller.signal,
    ).catch(() => "Download stopped.");
    setBusy("");
    setStatus("");
    setNote(failure ?? "Downloaded.");
    if (!failure) onUseModel(name);
    void refresh();
  }

  return (
    <div className="mt-4 border border-line p-4">
      <p className="text-xs tracking-widest text-muted uppercase">Local brain</p>
      <p className="mt-2 text-sm text-fg">
        {installed === undefined
          ? "Checking…"
          : installed === null
            ? "Ollama isn't running at this address. Install it from ollama.com and start it."
            : `Ollama is running. ${installed.length} model${installed.length === 1 ? "" : "s"} installed.`}
      </p>
      {installed ? (
        <ul className="mt-3">
          {LOCAL_PRESETS.map((preset) => {
            const ready = has(preset.model);
            const active = model === preset.model;
            return (
              <li key={preset.model} className="border-t border-line py-3">
                <p className="text-sm text-fg">{preset.label}</p>
                <p className="text-xs text-muted">{preset.note}</p>
                {ready ? (
                  <button type="button" className={"mt-2 min-h-11 text-sm " + (active ? "text-muted" : "text-accent")} disabled={active} onClick={() => onUseModel(preset.model)}>
                    {active ? "In use" : "Use this brain"}
                  </button>
                ) : (
                  <button type="button" className="mt-2 min-h-11 text-sm text-accent" disabled={!!busy} onClick={() => void download(preset.model)}>
                    {busy === preset.model ? "Downloading…" : "Download"}
                  </button>
                )}
              </li>
            );
          })}
        </ul>
      ) : null}
      {busy ? (
        <div className="mt-2">
          <div className="h-1 w-full bg-line">
            <div className="h-1 bg-accent" style={{ width: `${Math.round((fraction ?? 0) * 100)}%` }} />
          </div>
          <p className="mt-1 text-xs text-muted">
            {status} {fraction !== null ? `${Math.round(fraction * 100)}%` : ""}
          </p>
          <button type="button" className="mt-1 min-h-11 text-sm text-muted" onClick={() => abortRef.current?.abort()}>
            Cancel
          </button>
        </div>
      ) : null}
      {note ? <p className="mt-2 text-sm text-fg">{note}</p> : null}
      <button type="button" className="mt-1 min-h-11 text-sm text-muted" onClick={() => void refresh()}>
        Check again
      </button>
    </div>
  );
}
