import { useState } from "react";
import { X } from "lucide-react";
import type { ProjectFile } from "@/lib/jellyfish/parse";
import { downloadZip } from "@/lib/jellyfish/zip";
import { findPatch, lineDiff, type Patch } from "@/lib/jellyfish/self";
import { addLesson } from "@/lib/jellyfish/knowledge";
import { baseFor, loadProviders, modelFor, PROVIDERS, saveProviders, type ProviderConfig } from "@/lib/jellyfish/providers";
import { DEFAULT_PRIMARY, DEFAULT_SECONDARY } from "@/lib/jellyfish/model";
import { streamReply } from "@/lib/jellyfish/router";
import { LocalBrain } from "./local-brain";
import { HelpTip } from "./help-tip";
import { EvalPanel } from "./eval-panel";
import { APP_VERSION } from "@/lib/jellyfish/version";
import { addSnippet, loadSnippets, removeSnippet, type Snippet } from "@/lib/jellyfish/snippets";
import { sysLog } from "@/lib/jellyfish/syslog";
import { loadBuild, saveBuild, type BuildConfig } from "@/lib/jellyfish/buildconfig";
import { loadApproval, saveApproval, type ApprovalMode } from "@/lib/jellyfish/approval";
import { loadTools, saveTools, type SearchProviderId, type ToolsConfig } from "@/lib/jellyfish/toolsconfig";

function readSafe() {
  try {
    return localStorage.getItem("jellyfish.safeMode") !== "0";
  } catch {
    return true;
  }
}

export function SettingsView({
  theme,
  facts,
  files,
  autonomous,
  onTheme,
  primary,
  secondary,
  rules,
  onPalette,
  onAddRule,
  onRemoveRule,
  onRemoveFact,
  onClearFacts,
  onClearChats,
  onAutonomous,
  onRewrite,
  onClose,
}: {
  theme: "dark" | "light";
  facts: string[];
  files: ProjectFile[];
  autonomous: boolean;
  onTheme: (theme: "dark" | "light") => void;
  primary: string;
  secondary: string;
  rules: string[];
  onPalette: (primary: string, secondary: string) => void;
  onAddRule: (rule: string) => void;
  onRemoveRule: (rule: string) => void;
  onRemoveFact: (fact: string) => void;
  onClearFacts: () => void;
  onClearChats: () => void;
  onAutonomous: (on: boolean) => void;
  onRewrite: (path: string, content: string) => void;
  onClose: () => void;
}) {
  const [armFacts, setArmFacts] = useState(false);
  const [ruleDraft, setRuleDraft] = useState("");
  const [safe, setSafe] = useState(readSafe);
  const [build, setBuild] = useState<BuildConfig>(() => loadBuild());
  const [approval, setApprovalMode] = useState<ApprovalMode>(() => loadApproval());
  const changeApproval = (mode: ApprovalMode) => {
    setApprovalMode(mode);
    saveApproval(mode);
  };
  const changeBuild = (next: BuildConfig) => {
    setBuild(next);
    saveBuild(next);
  };
  const [tools, setTools] = useState<ToolsConfig>(() => loadTools());
  const changeTools = (next: ToolsConfig) => {
    setTools(next);
    saveTools(next);
  };
  const [snippets, setSnippets] = useState<Snippet[]>(() => loadSnippets());
  const [snippetName, setSnippetName] = useState("");
  const [snippetCode, setSnippetCode] = useState("");
  const [copied, setCopied] = useState("");

  function changeSafe(on: boolean) {
    setSafe(on);
    try {
      localStorage.setItem("jellyfish.safeMode", on ? "1" : "0");
    } catch {
      /* ignore */
    }
    if (on) onAutonomous(false);
    sysLog("info", "safe mode", on ? "Safe mode on: self-edits are preview only." : "Safe mode off: Apply rewrite is allowed (a backup zip is still made).");
  }
  const [armChats, setArmChats] = useState(false);
  const [providers, setProviders] = useState<ProviderConfig>(() => loadProviders());
  const [testNote, setTestNote] = useState("");
  const [testing, setTesting] = useState(false);
  const [patch, setPatch] = useState<Patch | null>(null);
  const [scanNote, setScanNote] = useState("");

  function commit(next: ProviderConfig) {
    setProviders(next);
    saveProviders(next);
  }

  async function testProvider() {
    setTesting(true);
    setTestNote("");
    let text = "";
    const error = await streamReply({
      messages: [{ role: "user", content: "Reply with the single word ready." }],
      facts: [],
      rules: [],
      lessons: [],
      onDelta: (chunk) => {
        text += chunk;
      },
    });
    setTesting(false);
    setTestNote(error && error !== "offline" ? error : text.trim().slice(0, 80) || "No reply.");
  }

  return (
    <section className="absolute inset-0 z-20 flex flex-col bg-bg">
      <div className="flex items-center justify-between border-b border-line px-4">
        <h2 className="text-sm font-medium text-fg">Settings</h2>
        <button type="button" onClick={onClose} aria-label="Close settings" className="inline-flex size-11 items-center justify-center text-muted">
          <X className="size-4" />
        </button>
      </div>
      <div className="mx-auto flex w-full max-w-lg flex-1 flex-col overflow-y-auto px-6">
        <div className="border-b border-line py-8">
          <h3 className="flex items-center gap-2 text-xs tracking-widest text-muted uppercase">
            Cloud Pictures
            <HelpTip text="Off by default. When off, pictures are drawn on this device as SVG by Qwen and nothing is sent out. When on, picture requests go to the cloud image service; if that fails, Qwen draws it instead." />
          </h3>
          <button
            type="button"
            role="switch"
            aria-checked={providers.cloudPictures}
            onClick={() => commit({ ...providers, cloudPictures: !providers.cloudPictures })}
            className={"mt-4 min-h-11 px-5 text-sm " + (providers.cloudPictures ? "bg-accent text-accent-fg" : "border border-line text-muted")}
          >
            {providers.cloudPictures ? "On" : "Off"}
          </button>
        </div>

        <div className="border-b border-line py-8">
          <h3 className="flex items-center gap-2 text-xs tracking-widest text-muted uppercase">
            Connect
            <HelpTip text="Qwen runs on this device through Ollama and is the default. Other brains are optional and need their own key." />
          </h3>
          <p className="mt-3 text-sm leading-relaxed text-muted">Keys stay in this browser. They are sent only with a chat you start.</p>
          <div className="mt-4 flex flex-col">
            {PROVIDERS.map((item) => {
              const on = providers.active === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => commit({ ...providers, active: item.id })}
                  className={"min-h-11 border-t border-line text-left text-sm " + (on ? "text-accent" : "text-fg")}
                >
                  {item.label}
                  <span className="ml-2 text-muted">{item.hint}</span>
                </button>
              );
            })}
          </div>
          <label className="mt-4 block text-xs tracking-widest text-muted uppercase">
            Model
            <input
              value={providers.models[providers.active] ?? ""}
              placeholder={modelFor(providers, providers.active)}
              onChange={(event) => commit({ ...providers, models: { ...providers.models, [providers.active]: event.target.value } })}
              className="mt-2 min-h-11 w-full border-b border-line bg-transparent text-sm text-fg outline-none placeholder:text-muted"
            />
          </label>
          {providers.active !== "ollama" && providers.active !== "xai" ? (
            <label className="mt-4 block text-xs tracking-widest text-muted uppercase">
              Base URL
              <input
                value={providers.baseUrls[providers.active] ?? ""}
                placeholder={baseFor({ ...providers, baseUrls: {} }, providers.active)}
                autoComplete="off"
                autoCapitalize="off"
                spellCheck={false}
                onChange={(event) => commit({ ...providers, baseUrls: { ...providers.baseUrls, [providers.active]: event.target.value } })}
                className="mt-2 min-h-11 w-full border-b border-line bg-transparent font-mono text-sm text-fg outline-none placeholder:text-muted"
              />
              <span className="mt-1 block text-xs normal-case tracking-normal text-muted">Any OpenAI-compatible endpoint. Leave empty for the default. Your key is sent only to this address.</span>
            </label>
          ) : null}
          {providers.active === "ollama" ? (
            <label className="mt-4 block text-xs tracking-widest text-muted uppercase">
              Address
              <input
                value={providers.ollamaUrl}
                onChange={(event) => commit({ ...providers, ollamaUrl: event.target.value })}
                className="mt-2 min-h-11 w-full border-b border-line bg-transparent font-mono text-sm text-fg outline-none"
              />
            </label>
          ) : null}
          {providers.active === "ollama" ? (
            <LocalBrain
              baseUrl={providers.ollamaUrl}
              model={modelFor(providers, "ollama")}
              onUseModel={(name) => commit({ ...providers, models: { ...providers.models, ollama: name } })}
            />
          ) : null}
          {PROVIDERS.find((item) => item.id === providers.active)?.needsKey ? (
            <label className="mt-4 block text-xs tracking-widest text-muted uppercase">
              API key
              <input
                type="password"
                autoComplete="off"
                value={providers.keys[providers.active] ?? ""}
                onChange={(event) => commit({ ...providers, keys: { ...providers.keys, [providers.active]: event.target.value } })}
                className="mt-2 min-h-11 w-full border-b border-line bg-transparent text-sm text-fg outline-none"
              />
            </label>
          ) : null}
          <button type="button" className="mt-4 min-h-11 text-sm text-accent" onClick={() => void testProvider()} disabled={testing}>
            {testing ? "Testing…" : "Test connection"}
          </button>
          {testNote ? <p className="mt-2 text-sm text-fg">{testNote}</p> : null}
        </div>

        <div className="border-b border-line py-8">
          <h3 className="text-xs tracking-widest text-muted uppercase">Look</h3>
          <div className="mt-4 grid grid-cols-2 gap-4">
            <label className="block text-xs tracking-widest text-muted uppercase">
              Primary
              <input
                type="color"
                value={primary}
                onChange={(event) => onPalette(event.target.value, secondary)}
                className="mt-2 block h-11 w-full cursor-pointer border border-line bg-transparent"
              />
            </label>
            <label className="block text-xs tracking-widest text-muted uppercase">
              Secondary
              <input
                type="color"
                value={secondary}
                onChange={(event) => onPalette(primary, event.target.value)}
                className="mt-2 block h-11 w-full cursor-pointer border border-line bg-transparent"
              />
            </label>
          </div>
          <button type="button" className="mt-3 min-h-11 text-sm text-muted" onClick={() => onPalette(DEFAULT_PRIMARY, DEFAULT_SECONDARY)}>
            Reset to soft peach
          </button>
          <div className="mt-4 flex gap-3">
            {(["dark", "light"] as const).map((option) => (
              <button
                key={option}
                type="button"
                onClick={() => onTheme(option)}
                className={"min-h-11 px-5 text-sm capitalize " + (theme === option ? "bg-accent text-accent-fg" : "text-muted")}
              >
                {option}
              </button>
            ))}
          </div>
        </div>

        <div className="border-b border-line py-8">
          <h3 className="text-xs tracking-widest text-muted uppercase">When Jellyfish asks you first</h3>
          <p className="mt-3 text-sm leading-relaxed text-muted">
            Running a terminal command always asks, in every mode. This setting adds more questions.
          </p>
          <div className="mt-3 flex flex-wrap gap-2">
            <button
              type="button"
              title="Asks before terminal commands and before reading the internet."
              className={"min-h-11 border px-3 text-sm " + (approval === "important" ? "border-accent text-accent" : "border-line text-muted")}
              onClick={() => changeApproval("important")}
            >
              Important things only
            </button>
            <button
              type="button"
              title="Also asks before every fix attempt, every test, and before adding the rest of the features."
              className={"min-h-11 border px-3 text-sm " + (approval === "every" ? "border-accent text-accent" : "border-line text-muted")}
              onClick={() => changeApproval("every")}
            >
              Every step
            </button>
          </div>
        </div>

        <div className="border-b border-line py-8">
          <h3 className="text-xs tracking-widest text-muted uppercase">Testing while it builds</h3>
          <p className="mt-3 text-sm leading-relaxed text-muted">
            After building, Jellyfish runs the project, pokes it with keys and clicks, measures what is on screen, takes a screenshot, and checks it against your request. If something fails it fixes it and tests again. Slower, but it catches the lazy "looks done" answers.
          </p>
          <button
            type="button"
            className={"mt-3 min-h-11 px-4 text-sm " + (build.verify ? "bg-accent text-accent-fg" : "text-muted")}
            onClick={() => changeBuild({ ...build, verify: !build.verify })}
          >
            {build.verify ? "Check against my request: on" : "Check against my request: off"}
          </button>
          <button
            type="button"
            className={"mt-3 ml-3 min-h-11 px-4 text-sm " + (build.checkpoints ? "bg-accent text-accent-fg" : "text-muted")}
            onClick={() => changeBuild({ ...build, checkpoints: !build.checkpoints })}
          >
            {build.checkpoints ? "Stop midway to test: on" : "Stop midway to test: off"}
          </button>
          <p className="mt-2 text-xs leading-relaxed text-muted">
            Midway means: build the core first, test it, then add the rest and test again. Screenshots go to the AI only if its model can see images (Qwen2.5-Coder cannot; it uses the measurements instead). You always see the screenshots in the chat.
          </p>
        </div>

        <div className="border-b border-line py-8">
          <h3 className="text-xs tracking-widest text-muted uppercase">Tools the AI can use</h3>
          <p className="mt-3 text-sm leading-relaxed text-muted">
            The AI is told which tools exist and asks for them itself. Testing and stress testing are always available. Everything it reads from the internet is treated as outside data, never as orders.
          </p>
          <button
            type="button"
            className={"mt-3 min-h-11 px-4 text-sm " + (tools.web ? "bg-accent text-accent-fg" : "text-muted")}
            onClick={() => changeTools({ ...tools, web: !tools.web })}
          >
            {tools.web ? "Internet: on (search, news, read pages)" : "Internet: off"}
          </button>
          {tools.web ? (
            <div className="mt-3">
              <p className="text-xs tracking-widest text-muted uppercase">Search source</p>
              <div className="mt-2 flex flex-wrap gap-2">
                {([
                  ["ddg", "DuckDuckGo (no key)"],
                  ["brave", "Brave Search (key)"],
                  ["searx", "SearXNG (your own)"],
                ] as [SearchProviderId, string][]).map(([id, label]) => (
                  <button
                    key={id}
                    type="button"
                    className={"min-h-11 border px-3 text-xs " + (tools.search.id === id ? "border-accent text-accent" : "border-line text-muted")}
                    onClick={() => changeTools({ ...tools, search: { ...tools.search, id } })}
                  >
                    {label}
                  </button>
                ))}
              </div>
              {tools.search.id === "brave" ? (
                <input
                  value={tools.search.key}
                  type="password"
                  autoComplete="off"
                  placeholder="Brave Search API key"
                  onChange={(event) => changeTools({ ...tools, search: { ...tools.search, key: event.target.value } })}
                  className="mt-2 min-h-11 w-full border-b border-line bg-transparent font-mono text-sm text-fg outline-none placeholder:text-muted"
                />
              ) : null}
              {tools.search.id === "searx" ? (
                <input
                  value={tools.search.url}
                  autoComplete="off"
                  placeholder="http://localhost:8888"
                  onChange={(event) => changeTools({ ...tools, search: { ...tools.search, url: event.target.value } })}
                  className="mt-2 min-h-11 w-full border-b border-line bg-transparent font-mono text-sm text-fg outline-none placeholder:text-muted"
                />
              ) : null}
              <p className="mt-2 text-xs leading-relaxed text-muted">
                DuckDuckGo works without a key but is scraped and can break. Brave is steadier. News uses Google News headlines unless Brave or SearXNG is chosen. Pages are read as text; this is not a full browser.
              </p>
            </div>
          ) : null}
          <button
            type="button"
            className={"mt-4 min-h-11 px-4 text-sm " + (tools.terminal ? "bg-accent text-accent-fg" : "text-muted")}
            onClick={() => changeTools({ ...tools, terminal: !tools.terminal })}
          >
            {tools.terminal ? "Terminal: on (you approve every command)" : "Terminal: off"}
          </button>
          <p className="mt-2 text-xs leading-relaxed text-muted">
            Needs Jellyfish started on your own computer with JELLYFISH_TERMINAL=1. Every command asks you first and runs only in the project folder. It does not work on a hosted website.
          </p>
        </div>

        <div className="border-b border-line py-8">
          <h3 className="text-xs tracking-widest text-muted uppercase">Safe mode</h3>
          <p className="mt-3 text-sm leading-relaxed text-muted">
            On: Jellyfish can only show you a self-edit as a diff. Nothing is written and autonomous mode stays off. Off: you can apply a rewrite, and a backup zip is always saved first.
          </p>
          <button
            type="button"
            className={"mt-3 min-h-11 px-4 text-sm " + (safe ? "bg-accent text-accent-fg" : "text-danger")}
            onClick={() => changeSafe(!safe)}
          >
            {safe ? "Safe mode is on" : "Safe mode is off"}
          </button>
        </div>

        <div className="border-b border-line py-8">
          <h3 className="text-xs tracking-widest text-muted uppercase">Autonomous mode</h3>
          <p className="mt-3 text-sm leading-relaxed text-muted">
            If this is on and you are idle for 2 minutes, or a console error is waiting, Jellyfish proposes one fix. Typing stops it.
          </p>
          <button
            type="button"
            className={"mt-3 min-h-11 px-4 text-sm " + (autonomous ? "bg-accent text-accent-fg" : "text-muted")}
            disabled={safe}
            onClick={() => onAutonomous(!autonomous)}
          >
            {safe ? "Off (safe mode is on)" : autonomous ? "On" : "Off"}
          </button>
        </div>

        <div className="border-b border-line py-8">
          <h3 className="text-xs tracking-widest text-muted uppercase">Analyze self</h3>
          <p className="mt-3 text-sm leading-relaxed text-muted">
            Reads this project for a real defect, shows the diff, and writes the file only after a backup zip.
          </p>
          <button
            type="button"
            className="mt-3 min-h-11 text-sm text-accent"
            onClick={() => {
              const found = findPatch(files);
              setPatch(found);
              setScanNote(
                found
                  ? found.summary
                  : "Scanned the open project. No skipped code, no broken braces, and the accent colors are intact.",
              );
            }}
          >
            Analyze self
          </button>
          {scanNote ? <p className="mt-3 text-sm text-fg">{scanNote}</p> : null}
          {patch ? (
            <>
              <pre className="mt-3 max-h-64 overflow-auto border border-line p-3 font-mono text-xs">
                {lineDiff(patch.before, patch.after).map((line, index) => (
                  <div key={index} className={line.kind === "add" ? "text-ok" : line.kind === "del" ? "text-danger" : "text-muted"}>
                    {line.kind === "add" ? "+ " : line.kind === "del" ? "- " : "  "}
                    {line.text}
                  </div>
                ))}
              </pre>
              <button
                type="button"
                className="mt-3 min-h-11 bg-accent px-4 text-sm text-accent-fg disabled:opacity-40"
                disabled={safe}
                onClick={() => {
                  void downloadZip("pre_self_edit_backup", files);
                  onRewrite(patch.path, patch.after);
                  void addLesson(patch.summary, "self.edit");
                  setScanNote(`Rewrote ${patch.path}. Backup downloaded as pre_self_edit_backup.zip.`);
                  setPatch(null);
                }}
              >
                {safe ? "Apply rewrite (turn safe mode off first)" : "Apply rewrite"}
              </button>
            </>
          ) : null}
        </div>

        <div className="border-b border-line py-8">
          <h3 className="text-xs tracking-widest text-muted uppercase">Things to always remember</h3>
          <p className="mt-3 text-sm leading-relaxed text-muted">Hard rules, like “No ES modules”. Every one is added to the instructions before every reply.</p>
          <form
            className="mt-4 flex gap-2"
            onSubmit={(event) => {
              event.preventDefault();
              onAddRule(ruleDraft);
              setRuleDraft("");
            }}
          >
            <input
              value={ruleDraft}
              maxLength={240}
              placeholder="Add a rule"
              onChange={(event) => setRuleDraft(event.target.value)}
              className="min-h-11 flex-1 border-b border-line bg-transparent text-sm text-fg outline-none placeholder:text-muted"
            />
            <button type="submit" className="min-h-11 px-3 text-sm text-accent">
              Add
            </button>
          </form>
          {rules.length ? (
            <ul className="mt-2">
              {rules.map((rule) => (
                <li key={rule} className="flex items-start justify-between gap-4 border-b border-line py-3 text-sm">
                  <span>{rule}</span>
                  <button type="button" className="min-h-11 shrink-0 text-muted" onClick={() => onRemoveRule(rule)}>
                    Remove
                  </button>
                </li>
              ))}
            </ul>
          ) : (
            <p className="mt-3 text-sm text-muted">No rules yet.</p>
          )}
        </div>

        <div className="border-b border-line py-8">
          <h3 className="text-xs tracking-widest text-muted uppercase">Memory</h3>
          <p className="mt-4 text-sm leading-relaxed text-fg">
            Facts stay pinned on every reply. Say “remember that …” to add one.
          </p>
          {facts.length ? (
            <ul className="mt-4">
              {facts.map((fact) => (
                <li key={fact} className="flex items-start justify-between gap-4 border-b border-line py-3 text-sm">
                  <span>{fact}</span>
                  <button type="button" className="min-h-11 shrink-0 text-muted" onClick={() => onRemoveFact(fact)}>
                    Remove
                  </button>
                </li>
              ))}
            </ul>
          ) : (
            <p className="mt-4 text-sm text-muted">No facts yet.</p>
          )}
          <button
            type="button"
            className="mt-3 min-h-11 text-sm text-fg"
            onClick={() => {
              if (!armFacts) {
                setArmFacts(true);
                return;
              }
              onClearFacts();
              setArmFacts(false);
            }}
          >
            {armFacts ? "Clear facts now" : "Clear facts"}
          </button>
          <button
            type="button"
            className="block min-h-11 text-sm text-danger"
            onClick={() => {
              if (!armChats) {
                setArmChats(true);
                return;
              }
              onClearChats();
              setArmChats(false);
            }}
          >
            {armChats ? "Clear this project's chats now" : "Clear this project's chats"}
          </button>
        </div>

        <EvalPanel rules={rules} />

        <div className="border-b border-line py-8">
          <h3 className="text-xs tracking-widest text-muted uppercase">Snippet library</h3>
          <p className="mt-3 text-sm leading-relaxed text-muted">Saved on this device. Save a file from the open project, or paste your own.</p>
          {files.length ? (
            <div className="mt-3 flex flex-wrap gap-2">
              {files.slice(0, 12).map((file) => (
                <button
                  key={file.path}
                  type="button"
                  className="min-h-11 border border-line px-3 text-xs text-fg"
                  onClick={() => setSnippets((list) => addSnippet(list, file.path, file.content))}
                >
                  Save {file.path}
                </button>
              ))}
            </div>
          ) : null}
          <input
            value={snippetName}
            maxLength={60}
            placeholder="Snippet name"
            onChange={(event) => setSnippetName(event.target.value)}
            className="mt-4 min-h-11 w-full border-b border-line bg-transparent text-sm text-fg outline-none placeholder:text-muted"
          />
          <textarea
            value={snippetCode}
            rows={4}
            placeholder="Paste code"
            onChange={(event) => setSnippetCode(event.target.value)}
            className="mt-2 w-full border border-line bg-transparent p-2 font-mono text-xs text-fg outline-none placeholder:text-muted"
          />
          <button
            type="button"
            className="mt-2 min-h-11 text-sm text-accent"
            onClick={() => {
              setSnippets((list) => addSnippet(list, snippetName, snippetCode));
              setSnippetName("");
              setSnippetCode("");
            }}
          >
            Save snippet
          </button>
          {snippets.length ? (
            <ul className="mt-2">
              {snippets.map((item) => (
                <li key={item.id} className="border-t border-line py-3">
                  <p className="text-sm text-fg">{item.name}</p>
                  <pre className="mt-1 max-h-24 overflow-auto font-mono text-xs text-muted">{item.code.slice(0, 400)}</pre>
                  <button
                    type="button"
                    className="min-h-11 pr-4 text-sm text-accent"
                    onClick={() => {
                      void navigator.clipboard?.writeText(item.code).then(() => setCopied(item.id));
                    }}
                  >
                    {copied === item.id ? "Copied" : "Copy"}
                  </button>
                  <button type="button" className="min-h-11 text-sm text-muted" onClick={() => setSnippets((list) => removeSnippet(list, item.id))}>
                    Delete
                  </button>
                </li>
              ))}
            </ul>
          ) : (
            <p className="mt-3 text-sm text-muted">No snippets yet.</p>
          )}
        </div>

        <div className="py-8">
          <h3 className="text-xs tracking-widest text-muted uppercase">How replies work</h3>
          <p className="mt-2 text-xs text-muted">Jellyfish AI v{APP_VERSION}</p>
          <p className="mt-4 text-sm leading-relaxed text-muted">
            Hard questions go to the connected brain. Reasoning sits behind “View Jellyfish's Thought Process”. A built project is run once and repaired if the console complains.
          </p>
        </div>
      </div>
    </section>
  );
}
