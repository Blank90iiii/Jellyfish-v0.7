import { useState } from "react";
import type { ProjectFile } from "@/lib/jellyfish/parse";

export type DiffRow = { path: string; before: string; after: string };

export type DiffProposal = {
  name: string;
  files: ProjectFile[];
  rows: DiffRow[];
  reason: string;
};

function linesOf(before: string, after: string) {
  const left = before.split("\n");
  const right = after.split("\n");
  const total = Math.max(left.length, right.length);
  const cap = 240;
  const start = total > cap ? total - cap : 0;
  const rows: { n: number; left?: string; right?: string; changed: boolean }[] = [];
  for (let i = start; i < total; i++) {
    rows.push({ n: i + 1, left: left[i], right: right[i], changed: left[i] !== right[i] });
  }
  return { rows, trimmed: start };
}

export function DiffViewer({
  proposal,
  onApprove,
  onReject,
}: {
  proposal: DiffProposal;
  onApprove: () => void;
  onReject: () => void;
}) {
  const [path, setPath] = useState(proposal.rows[0]?.path ?? "");
  const row = proposal.rows.find((item) => item.path === path) ?? proposal.rows[0];
  const view = row ? linesOf(row.before, row.after) : { rows: [], trimmed: 0 };

  return (
    <div className="fixed inset-0 z-40 flex items-stretch justify-center bg-black/70 p-3 sm:p-6">
      <section className="flex max-h-full w-full max-w-5xl flex-col border border-line bg-bg">
        <header className="flex flex-wrap items-center gap-2 border-b border-line px-4 py-3">
          <div className="min-w-0 flex-1">
            <p className="text-sm font-semibold text-fg">Review before overwrite</p>
            <p className="truncate text-xs text-muted">{proposal.reason}</p>
          </div>
          <button type="button" className="min-h-11 bg-accent px-4 text-sm font-medium text-accent-fg" onClick={onApprove}>
            Approve
          </button>
          <button type="button" className="min-h-11 px-3 text-sm text-muted" onClick={onReject}>
            Reject
          </button>
        </header>
        {proposal.rows.length > 1 ? (
          <div className="flex gap-3 overflow-x-auto border-b border-line px-4">
            {proposal.rows.map((item) => (
              <button
                key={item.path}
                type="button"
                className={"min-h-11 shrink-0 border-b-2 font-mono text-xs " + (item.path === row?.path ? "border-accent text-fg" : "border-transparent text-muted")}
                onClick={() => setPath(item.path)}
              >
                {item.path}
              </button>
            ))}
          </div>
        ) : (
          <p className="border-b border-line px-4 py-2 font-mono text-xs text-muted">{row?.path}</p>
        )}
        <div className="grid min-h-0 flex-1 grid-cols-1 md:grid-cols-2">
          <div className="min-h-0 overflow-auto border-b border-line md:border-r md:border-b-0">
            <p className="sticky top-0 bg-bg px-3 py-2 text-xs tracking-widest text-danger uppercase">Current</p>
            {view.trimmed > 0 ? <p className="px-3 text-xs text-muted">Showing the last {view.rows.length} lines.</p> : null}
            <pre className="px-3 pb-4 font-mono text-xs leading-relaxed">
              {view.rows.map((line) => (
                <div key={`l-${line.n}`} className={line.changed ? "bg-danger/15 text-danger" : "text-muted"}>
                  <span className="mr-2 inline-block w-8 text-right text-muted">{line.n}</span>
                  {line.left ?? ""}
                </div>
              ))}
            </pre>
          </div>
          <div className="min-h-0 overflow-auto">
            <p className="sticky top-0 bg-bg px-3 py-2 text-xs tracking-widest text-ok uppercase">Proposed</p>
            {view.trimmed > 0 ? <p className="px-3 text-xs text-muted">Showing the last {view.rows.length} lines.</p> : null}
            <pre className="px-3 pb-4 font-mono text-xs leading-relaxed">
              {view.rows.map((line) => (
                <div key={`r-${line.n}`} className={line.changed ? "bg-ok/15 text-ok" : "text-muted"}>
                  <span className="mr-2 inline-block w-8 text-right text-muted">{line.n}</span>
                  {line.right ?? ""}
                </div>
              ))}
            </pre>
          </div>
        </div>
      </section>
    </div>
  );
}
