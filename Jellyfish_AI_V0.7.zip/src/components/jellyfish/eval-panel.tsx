import { useRef, useState } from "react";
import evalDefs from "@/lib/jellyfish/evals.json";
import { QUICK_IDS, runEvals, type EvalDef, type EvalReport, type EvalResult } from "@/lib/jellyfish/evals";
import { loadProviders, modelFor } from "@/lib/jellyfish/providers";
import { inspectProject, probeProject } from "@/lib/jellyfish/sandbox";
import { streamReply } from "@/lib/jellyfish/router";
import { sysLog } from "@/lib/jellyfish/syslog";

const KEY = "jellyfish.evalReports";

function loadReports(): EvalReport[] {
  try {
    const data = JSON.parse(localStorage.getItem(KEY) ?? "[]") as EvalReport[];
    return Array.isArray(data) ? data.filter((item) => item && Array.isArray(item.results)).slice(0, 5) : [];
  } catch {
    return [];
  }
}

function saveReport(report: EvalReport): EvalReport[] {
  const next = [report, ...loadReports()].slice(0, 5);
  try {
    localStorage.setItem(KEY, JSON.stringify(next));
  } catch {
    /* storage full */
  }
  return next;
}

function line(report: EvalReport) {
  return `${report.model} · ${new Date(report.at).toLocaleString()} · passed ${report.passed}/${report.total} · first try ${report.firstTry}/${report.total} · ${report.avgSeconds}s and ${report.avgCalls} calls each`;
}

/** Measures the brain: runs fixed coding requests and scores them first try and after Jellyfish's testing. */
export function EvalPanel({ rules }: { rules: string[] }) {
  const [running, setRunning] = useState(false);
  const [progress, setProgress] = useState("");
  const [live, setLive] = useState<EvalResult[]>([]);
  const [reports, setReports] = useState<EvalReport[]>(() => loadReports());
  const abortRef = useRef<AbortController | null>(null);

  async function start(quick: boolean) {
    const defs = (evalDefs as EvalDef[]).filter((def) => !quick || QUICK_IDS.includes(def.id));
    const controller = new AbortController();
    abortRef.current = controller;
    setRunning(true);
    setLive([]);
    const providers = loadProviders();
    const meta = { provider: providers.active, model: modelFor(providers, providers.active) };
    sysLog("info", "evals", `Started ${defs.length} prompts on ${meta.model}`);
    const results: EvalResult[] = [];
    try {
      const report = await runEvals(defs, {
        generate: (turns, onDelta, opts) =>
          streamReply({ messages: turns, facts: [], rules, lessons: [], images: opts?.images, signal: controller.signal, onDelta }),
        probe: (files) => probeProject(files),
        inspect: (files) => inspectProject(files),
        aborted: () => controller.signal.aborted,
        onProgress: (done, total, current, result) => {
          setProgress(`${done}${result ? "" : "+"} of ${total}: ${current.slice(0, 48)}`);
          if (result) {
            results.push(result);
            setLive([...results]);
          }
        },
        meta,
      });
      if (report.total > 0) setReports(saveReport(report));
      sysLog("info", "evals", `Finished: passed ${report.passed}/${report.total}`);
    } finally {
      abortRef.current = null;
      setRunning(false);
      setProgress("");
    }
  }

  function download(report: EvalReport) {
    const blob = new Blob([JSON.stringify(report, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `jellyfish-eval-${report.model.replace(/[^a-z0-9.-]/gi, "_")}-${new Date(report.at).toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  const latest = reports[0];
  const previous = reports[1];

  return (
    <div className="border-b border-line py-8">
      <h3 className="text-xs tracking-widest text-muted uppercase">Evals: measure the brain</h3>
      <p className="mt-3 text-sm leading-relaxed text-muted">
        Gives the current model fixed coding requests and scores them twice: first try (the model alone) and final (after Jellyfish tested and fixed it). The gap is what Jellyfish adds. Prompts that load libraries from the internet fail without a connection.
      </p>
      <div className="mt-3 flex flex-wrap gap-2">
        <button type="button" disabled={running} title="5 mixed prompts. Takes a few minutes." className="min-h-11 border border-line px-3 text-sm text-fg disabled:opacity-40" onClick={() => void start(true)}>
          Quick run (5)
        </button>
        <button type="button" disabled={running} title="All 30 prompts. On a slow laptop this can take an hour or more." className="min-h-11 border border-line px-3 text-sm text-fg disabled:opacity-40" onClick={() => void start(false)}>
          Full run (30)
        </button>
        {running ? (
          <button type="button" className="min-h-11 border border-[#ff2d2d] px-3 text-sm font-bold text-[#ff2d2d]" onClick={() => abortRef.current?.abort()}>
            Stop
          </button>
        ) : null}
      </div>
      {running ? <p className="mt-3 text-xs text-muted">{progress || "Starting…"}</p> : null}
      {live.length ? (
        <ul className="mt-3 text-xs">
          {live.map((result) => (
            <li key={result.id} className={result.passed ? "text-fg" : "text-danger"}>
              {result.passed ? "✓" : "✗"} {result.prompt.slice(0, 44)} <span className="text-muted">· {result.firstTry ? "first try" : result.formatOk ? `${result.fixes} fixes` : "no project"} · {Math.round(result.seconds)}s{result.note ? ` · ${result.note}` : ""}</span>
            </li>
          ))}
        </ul>
      ) : null}
      {latest ? (
        <div className="mt-4 border-t border-line pt-3 text-xs">
          <p className="text-fg">Latest: {line(latest)}</p>
          {previous ? <p className="mt-1 text-muted">Before: {line(previous)}</p> : null}
          <button type="button" className="mt-2 min-h-11 text-sm text-accent" onClick={() => download(latest)}>
            Download report (.json)
          </button>
        </div>
      ) : (
        <p className="mt-3 text-xs text-muted">No runs yet.</p>
      )}
    </div>
  );
}
