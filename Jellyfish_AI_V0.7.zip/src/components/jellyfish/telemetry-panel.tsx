import { useEffect, useState } from "react";
import { getRun, secondsOf, subscribeRun, type Run, type Step } from "@/lib/jellyfish/telemetry";

const MARK: Record<Step["status"], string> = { active: "●", done: "✓", failed: "✗" };

/** Live view of what Jellyfish is doing: reading memory, writing, testing, fixing. Read-only. */
export function TelemetryPanel() {
  const [run, setRun] = useState<Run | null>(() => getRun());
  const [open, setOpen] = useState(false);
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => subscribeRun(() => setRun(getRun())), []);
  const live = !!run && !run.outcome;
  useEffect(() => {
    if (!live) return;
    const timer = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(timer);
  }, [live]);

  if (!run || run.steps.length === 0) return null;
  const current = run.steps[run.steps.length - 1];
  const total = secondsOf({ startedAt: run.startedAt, endedAt: run.endedAt }, now);
  const headline = live ? current.label : run.outcome === "failed" ? "Last run failed" : run.outcome === "stopped" ? "Last run was stopped" : "Last run finished";

  return (
    <div className="border-t border-line px-3 text-xs" aria-live="polite">
      <button
        type="button"
        title="Shows what Jellyfish is doing right now. Tap to see every step."
        className="flex min-h-11 w-full items-center gap-2 text-left"
        onClick={() => setOpen((value) => !value)}
      >
        <span className={live ? "text-accent" : run.outcome === "failed" ? "text-danger" : "text-muted"}>{live ? "●" : run.outcome === "failed" ? "✗" : "✓"}</span>
        <span className="min-w-0 flex-1 truncate text-fg">{headline}</span>
        <span className="shrink-0 text-muted">
          {total}s · {run.calls} model {run.calls === 1 ? "call" : "calls"} {open ? "▴" : "▾"}
        </span>
      </button>
      {open ? (
        <ol className="max-h-48 overflow-y-auto pb-2">
          {run.steps.map((step) => (
            <li key={step.id} className={"flex gap-2 py-0.5 " + (step.status === "failed" ? "text-danger" : step.status === "active" ? "text-fg" : "text-muted")}>
              <span className="w-3 shrink-0">{MARK[step.status]}</span>
              <span className="min-w-0 flex-1">
                {step.label}
                {step.detail ? <span className="text-muted"> — {step.detail}</span> : null}
              </span>
              <span className="shrink-0">{secondsOf(step, now)}s</span>
            </li>
          ))}
        </ol>
      ) : null}
    </div>
  );
}
