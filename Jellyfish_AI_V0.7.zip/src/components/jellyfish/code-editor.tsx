import { useEffect, useRef, useState } from "react";
import { languageFor, monacoThemeFor } from "@/lib/jellyfish/editor-lang";

type Monaco = typeof import("monaco-editor/esm/vs/editor/editor.api");
type Editor = import("monaco-editor/esm/vs/editor/editor.api").editor.IStandaloneCodeEditor;

let monacoPromise: Promise<Monaco> | null = null;

/*
  Loads Monaco from this app's own files (works offline). Browser only.
  Follows the Vite worker recipe for Monaco: import the editor worker with the
  "?worker" suffix and hand it to MonacoEnvironment.getWorker. Only the core
  editor worker is needed: HTML, CSS and JS use Monaco's built-in highlighters,
  which run on the main thread. Nothing here is loaded until an editor opens.
*/
function loadMonaco(): Promise<Monaco> {
  if (!monacoPromise) {
    monacoPromise = (async () => {
      const [{ default: EditorWorker }, monaco] = await Promise.all([
        import("monaco-editor/esm/vs/editor/editor.worker?worker"),
        import("monaco-editor/esm/vs/editor/editor.api"),
        import("monaco-editor/esm/vs/editor/editor.all.js"),
        import("monaco-editor/esm/vs/basic-languages/html/html.contribution.js"),
        import("monaco-editor/esm/vs/basic-languages/css/css.contribution.js"),
        import("monaco-editor/esm/vs/basic-languages/javascript/javascript.contribution.js"),
      ]).then((parts) => [parts[0], parts[1]] as const);
      (self as unknown as { MonacoEnvironment: unknown }).MonacoEnvironment = {
        getWorker: () => new EditorWorker(),
      };
      return monaco;
    })();
    // a failed load may be retried the next time an editor opens
    monacoPromise.catch(() => {
      monacoPromise = null;
    });
  }
  return monacoPromise;
}

/*
  Monaco editor, one model per file so undo history and scroll survive tab switches.
  If Monaco cannot load, a plain textarea takes over so editing never breaks.
*/
export function CodeEditor({
  path,
  value,
  theme,
  onChange,
  className,
}: {
  path: string;
  value: string;
  theme: "dark" | "light";
  onChange: (path: string, content: string) => void;
  className?: string;
}) {
  const host = useRef<HTMLDivElement>(null);
  const editor = useRef<Editor | null>(null);
  const monacoRef = useRef<Monaco | null>(null);
  const latest = useRef({ path, onChange });
  latest.current = { path, onChange };
  const [failed, setFailed] = useState(false);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let cancelled = false;
    let disposeChange: { dispose: () => void } | null = null;
    loadMonaco()
      .then((monaco) => {
        if (cancelled || !host.current) return;
        monacoRef.current = monaco;
        const instance = monaco.editor.create(host.current, {
          model: null,
          theme: monacoThemeFor(theme),
          automaticLayout: true,
          minimap: { enabled: false },
          fontSize: 14,
          tabSize: 2,
          wordWrap: "on",
          scrollBeyondLastLine: false,
          fixedOverflowWidgets: true,
          ariaLabel: "Editor",
        });
        editor.current = instance;
        disposeChange = instance.onDidChangeModelContent(() => {
          const model = instance.getModel();
          if (!model) return;
          const text = model.getValue();
          const current = latest.current;
          if (model.uri.path === `/${current.path}`) current.onChange(current.path, text);
        });
        setReady(true);
      })
      .catch(() => {
        if (!cancelled) setFailed(true);
      });
    return () => {
      cancelled = true;
      disposeChange?.dispose();
      editor.current?.dispose();
      editor.current = null;
      setReady(false);
    };
    // created once; theme and file are synced by the effects below
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const monaco = monacoRef.current;
    const instance = editor.current;
    if (!ready || !monaco || !instance) return;
    const uri = monaco.Uri.parse(`file:///${path}`);
    let model = monaco.editor.getModel(uri);
    if (!model) model = monaco.editor.createModel(value, languageFor(path), uri);
    else if (model.getValue() !== value) model.setValue(value);
    if (instance.getModel() !== model) instance.setModel(model);
    // value is read on purpose: outside edits (fixes, rewrites) must reach the editor
  }, [ready, path, value]);

  useEffect(() => {
    if (ready && monacoRef.current) monacoRef.current.editor.setTheme(monacoThemeFor(theme));
  }, [ready, theme]);

  if (failed) {
    return (
      <textarea
        value={value}
        spellCheck={false}
        onChange={(event) => onChange(path, event.target.value)}
        className={"resize-none bg-bg p-5 font-mono text-sm leading-relaxed text-fg outline-none " + (className ?? "")}
        aria-label="Editor"
      />
    );
  }
  return <div ref={host} className={className} role="group" aria-label="Code editor" />;
}
