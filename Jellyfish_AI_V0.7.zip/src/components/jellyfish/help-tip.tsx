import { useEffect, useRef, useState, type ReactNode } from "react";
import { nextHelpOpen } from "@/lib/jellyfish/helptip";

/**
  Tap-for-help "?" for touchscreens (also works with mouse and keyboard).
  The outside-click closer ignores anything inside this wrapper, and the
  Help button stops its own click from bubbling, so tapping "?" again
  closes the bubble instead of being swallowed.
*/
export function HelpTip({ text, children }: { text: string; children?: ReactNode }) {
  const [open, setOpen] = useState(false);
  const root = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    if (!open) return;
    function onDown(event: PointerEvent) {
      const target = event.target as Node | null;
      if (target && root.current?.contains(target)) return;
      setOpen((value) => nextHelpOpen(value, "outside"));
    }
    function onKey(event: KeyboardEvent) {
      if (event.key === "Escape") setOpen((value) => nextHelpOpen(value, "escape"));
    }
    document.addEventListener("pointerdown", onDown, true);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("pointerdown", onDown, true);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  return (
    <span ref={root} className="relative inline-flex items-center gap-1">
      {children}
      <button
        type="button"
        aria-label="Help"
        aria-expanded={open}
        title={text}
        onClick={(event) => {
          event.stopPropagation();
          setOpen((value) => nextHelpOpen(value, "help"));
        }}
        className="inline-flex size-6 shrink-0 items-center justify-center rounded-full border border-line text-xs text-muted"
      >
        ?
      </button>
      {open ? (
        <span
          role="tooltip"
          className="absolute top-full left-0 z-40 mt-2 w-56 max-w-[70vw] border border-line bg-surface p-3 text-xs leading-relaxed whitespace-normal text-fg shadow-lg"
        >
          {text}
        </span>
      ) : null}
    </span>
  );
}
