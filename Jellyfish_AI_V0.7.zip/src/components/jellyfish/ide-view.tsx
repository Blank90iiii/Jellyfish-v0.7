import { useEffect, useRef, useState } from "react";
import { Download, Play, Trash2 } from "lucide-react";
import type { ProjectFile } from "@/lib/jellyfish/parse";
import { buildPreview } from "@/lib/jellyfish/preview";
import { labProject, blankProject } from "@/lib/jellyfish/projects";
import { pushLog } from "@/lib/jellyfish/console-bus";
import { pushSnapshot } from "@/lib/jellyfish/history";
import { ConsoleDock } from "./console-dock";
import { CodeEditor } from "./code-editor";
import { FileTree } from "./file-tree";
import { HelpTip } from "./help-tip";
import { ThemeToggle } from "./theme-toggle";

/*
  IDE chrome is a stack of hairline rows. No pill borders.
  Editor and preview share a two-column grid from md up;
  phones toggle between them so nothing scrolls sideways.
*/
export function IdeView({
  projectId,
  files,
  activeFile,
  runToken,
  theme,
  onTheme,
  onChange,
  onSelect,
  onAdd,
  onDelete,
  onLoad,
  onZip,
  onExplain,
}: {
  projectId: string;
  files: ProjectFile[];
  activeFile: string;
  runToken: number;
  theme: "dark" | "light";
  onTheme: (theme: "dark" | "light") => void;
  onChange: (path: string, content: string) => void;
  onSelect: (path: string) => void;
  onAdd: (path: string) => boolean;
  onDelete: (path: string) => void;
  onLoad: (files: ProjectFile[], run: boolean) => void;
  onZip: () => void;
  onExplain: (text: string) => void;
}) {
  const current = files.find((file) => file.path === activeFile) ?? files[0];
  const frame = useRef<HTMLIFrameElement>(null);
  const snapRef = useRef<{ path: string; at: number } | null>(null);
  const [showPreview, setShowPreview] = useState(false);
  const [draftPath, setDraftPath] = useState("");

  function changeFile(path: string, content: string) {
    const previous = files.find((file) => file.path === path)?.content ?? "";
    const now = Date.now();
    const mark = snapRef.current;
    if (previous !== content && (!mark || mark.path !== path || now - mark.at > 8000)) {
      pushSnapshot({ projectId, path, content: previous, label: path });
      snapRef.current = { path, at: now };
    }
    onChange(path, content);
  }

  function run() {
    const html = buildPreview(files);
    setShowPreview(true);
    pushLog("info", "Run", "code");
    if (frame.current) frame.current.srcdoc = html;
  }

  useEffect(() => {
    function onMessage(event: MessageEvent) {
      if (event.source !== frame.current?.contentWindow) return;
      const data = event.data as { type?: string; msg?: string; level?: string; err?: boolean };
      if (!data || data.type !== "cf-log" || typeof data.msg !== "string") return;
      const level = data.level === "warn" || data.level === "error" || data.level === "log" ? data.level : data.err ? "error" : "log";
      pushLog(level, data.msg, "code");
    }
    window.addEventListener("message", onMessage);
    return () => window.removeEventListener("message", onMessage);
  }, []);

  useEffect(() => {
    if (runToken > 0) run();
    // run reads latest files when a project is opened
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [runToken]);

  return (
    <section className="flex min-h-0 flex-1 flex-col overflow-x-hidden">
      <div className="flex flex-wrap items-center gap-x-6 gap-y-2 border-b border-line px-5 py-3">
        <button
          type="button"
          onClick={run}
          className="inline-flex min-h-11 items-center gap-2 text-sm font-medium text-accent"
        >
          <Play className="size-4" />
          Run
        </button>
        <button
          type="button"
          onClick={onZip}
          className="inline-flex min-h-11 items-center gap-2 text-sm text-fg"
        >
          <Download className="size-4" />
          Zip
        </button>
        <button
          type="button"
          onClick={() => onLoad(labProject().files, true)}
          className="inline-flex min-h-11 items-center text-sm text-fg"
        >
          Sample lab
        </button>
        <button
          type="button"
          onClick={() => onLoad(blankProject().files, false)}
          className="inline-flex min-h-11 items-center text-sm text-muted"
        >
          Blank page
        </button>
        <ThemeToggle theme={theme} onTheme={onTheme} />
        <HelpTip text="Run shows your page in the preview. Zip downloads the files. Sample lab and Blank page replace the files in this workspace. Day/Night also changes the editor colors." />
      </div>

      <FileTree paths={files.map((file) => file.path)} activeFile={current?.path ?? ""} onSelect={onSelect} />

      <div className="flex items-center gap-3 border-b border-line px-5 py-4">
        <input
          value={draftPath}
          onChange={(event) => setDraftPath(event.target.value)}
          placeholder="css/extra.css"
          className="min-h-11 min-w-0 flex-1 border-0 border-b border-line bg-transparent px-0 font-mono text-sm text-fg outline-none placeholder:text-muted"
        />
        <button
          type="button"
          className="min-h-11 shrink-0 text-sm text-fg"
          onClick={() => {
            if (onAdd(draftPath)) setDraftPath("");
          }}
        >
          Add file
        </button>
        <HelpTip text="Type a path like css/extra.css and tap Add file. The trash icon deletes the open file." />
        {current && files.length > 1 ? (
          <button
            type="button"
            aria-label="Delete file"
            className="inline-flex size-11 shrink-0 items-center justify-center text-muted"
            onClick={() => onDelete(current.path)}
          >
            <Trash2 className="size-4" />
          </button>
        ) : null}
      </div>

      <div className="grid min-h-0 flex-1 md:grid-cols-2">
        <CodeEditor
          path={current?.path ?? "index.html"}
          value={current?.content ?? ""}
          theme={theme}
          onChange={changeFile}
          className={"min-h-48 w-full bg-bg " + (showPreview ? "hidden md:block" : "")}
        />
        <iframe
          ref={frame}
          title="Preview"
          sandbox="allow-scripts allow-modals"
          className={
            "h-full min-h-64 w-full border-0 bg-bg md:border-l md:border-line " +
            (showPreview ? "" : "hidden md:block")
          }
        />
      </div>

      <div className="flex items-center border-t border-line px-5 md:hidden">
        <button
          type="button"
          className="min-h-11 text-sm text-accent"
          onClick={() => setShowPreview((value) => !value)}
        >
          {showPreview ? "Show editor" : "Show preview"}
        </button>
      </div>

      <ConsoleDock onExplain={onExplain} />
    </section>
  );
}
