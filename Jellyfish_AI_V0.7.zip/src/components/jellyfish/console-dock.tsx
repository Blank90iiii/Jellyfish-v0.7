import { useEffect, useState } from "react";
import { Bug } from "lucide-react";
import { clearConsole, getLogs, getNets, subscribe, type ConsoleEntry, type NetEntry } from "@/lib/jellyfish/console-bus";
import { clearSys, getSys, subscribeSys, type SysEntry } from "@/lib/jellyfish/syslog";

const LEVEL: Record<ConsoleEntry["level"], string> = {
  log: "text-ok",
  info: "text-muted",
  warn: "text-accent",
  error: "text-danger",
};

export function ConsoleDock({ onExplain, onStress }: { onExplain?: (text: string) => void; onStress?: () => Promise<void> }) {
  const [tab, setTab] = useState<"logs" | "network" | "system">("logs");
  const [sys, setSys] = useState<SysEntry[]>(() => getSys().slice());
  const [stressing, setStressing] = useState(false);
  const [logs, setLogs] = useState<ConsoleEntry[]>(() => getLogs());
  const [nets, setNets] = useState<NetEntry[]>(() => getNets());

  useEffect(() => subscribeSys(() => setSys(getSys().slice())), []);

  useEffect(() => {
    return subscribe(() => {
      setLogs(getLogs().slice());
      setNets(getNets().slice());
    });
  }, []);

  return (
    <div className="flex h-36 shrink-0 flex-col border-t border-line bg-surface">
      <div className="flex items-center gap-4 border-b border-line px-4">
        <button type="button" className={"min-h-11 text-sm " + (tab === "logs" ? "text-accent" : "text-muted")} onClick={() => setTab("logs")}>
          Console
        </button>
        <button
          type="button"
          className={"min-h-11 text-sm " + (tab === "network" ? "text-accent" : "text-muted")}
          onClick={() => setTab("network")}
        >
          Network
        </button>
        <button type="button" className={"min-h-11 text-sm " + (tab === "system" ? "text-accent" : "text-muted")} onClick={() => setTab("system")}>
          System{sys.some((entry) => entry.level === "error") ? " !" : ""}
        </button>
        {onStress ? (
          <button
            type="button"
            className="ml-auto min-h-11 text-sm text-accent"
            disabled={stressing}
            onClick={() => {
              setStressing(true);
              void onStress().finally(() => setStressing(false));
            }}
          >
            {stressing ? "Stressing…" : "Stress test"}
          </button>
        ) : null}
        <button type="button" className={"min-h-11 text-sm text-muted " + (onStress ? "" : "ml-auto")} onClick={() => (tab === "system" ? clearSys() : clearConsole())}>
          Clear
        </button>
      </div>
      <div className="min-h-0 flex-1 overflow-y-auto px-4 py-2 font-mono text-xs">
        {tab === "system" ? (
          sys.length ? (
            sys.map((entry) => (
              <p key={entry.id} className={entry.level === "error" ? "text-danger" : entry.level === "warn" ? "text-accent" : "text-muted"}>
                {entry.level} {entry.source} {entry.text}
              </p>
            ))
          ) : (
            <p className="text-muted">Jellyfish and the model are running clean.</p>
          )
        ) : tab === "logs" ? (
          logs.length ? (
            logs.map((entry) => (
              <div key={entry.id} className="flex items-start gap-2">
                <p className={"min-w-0 flex-1 " + LEVEL[entry.level]}>
                  {entry.level} {entry.source} {entry.text}
                </p>
                {entry.level === "error" && onExplain ? (
                  <button
                    type="button"
                    aria-label="Explain this error and fix it"
                    title="Explain this error and fix it"
                    className="inline-flex size-8 shrink-0 items-center justify-center text-danger"
                    onClick={() => onExplain(`${entry.source}: ${entry.text}`)}
                  >
                    <Bug className="size-3.5" />
                  </button>
                ) : null}
              </div>
            ))
          ) : (
            <p className="text-muted">Console is quiet.</p>
          )
        ) : nets.length ? (
          nets.map((entry) => (
            <p key={entry.id} className={entry.ok ? "text-ok" : "text-danger"}>
              {entry.method} {entry.status || "fail"} {entry.ms}ms {entry.url}
            </p>
          ))
        ) : (
          <p className="text-muted">No requests yet.</p>
        )}
      </div>
    </div>
  );
}
