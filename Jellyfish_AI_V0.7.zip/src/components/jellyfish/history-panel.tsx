import { useEffect, useState } from "react";
import { loadSnapshots, type Snapshot } from "@/lib/jellyfish/history";

function when(at: number): string {
  if (!at) return "";
  const date = new Date(at);
  return date.toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
}

export function HistoryPanel({ projectId, onRevert }: { projectId: string; onRevert: (snap: Snapshot) => void }) {
  const [rows, setRows] = useState<Snapshot[]>(() => loadSnapshots(projectId));

  useEffect(() => {
    const load = () => setRows(loadSnapshots(projectId));
    load();
    window.addEventListener("jellyfish-history", load);
    window.addEventListener("storage", load);
    return () => {
      window.removeEventListener("jellyfish-history", load);
      window.removeEventListener("storage", load);
    };
  }, [projectId]);

  if (!rows.length) {
    return <p className="px-3 text-sm text-muted">No snapshots yet. Edits and approved writes land here.</p>;
  }

  return (
    <ul className="flex flex-col">
      {rows.map((snap) => (
        <li key={snap.id} className="border-b border-line px-3 py-2">
          <p className="truncate font-mono text-xs text-fg">{snap.path}</p>
          <p className="truncate text-xs text-muted">{when(snap.at)}</p>
          <button type="button" className="min-h-11 text-sm text-accent" onClick={() => onRevert(snap)}>
            Revert
          </button>
        </li>
      ))}
    </ul>
  );
}
