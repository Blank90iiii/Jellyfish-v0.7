import { type ReactNode, useState } from "react";
import { Box, Braces, Brain, FolderClosed, History, MessageSquare, PanelLeft, PanelRight, Plus, Settings, Trash2 } from "lucide-react";
import type { JellyfishState, ProjectSpace } from "@/lib/jellyfish/store";
import type { Snapshot } from "@/lib/jellyfish/history";
import { HistoryPanel } from "./history-panel";
import { MemoryPanel } from "./memory-panel";

function Mark({ className = "size-8" }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={`${className} shrink-0 text-accent`} aria-hidden="true">
      <rect x="1.25" y="1.25" width="29.5" height="29.5" rx="8" className="fill-bg" stroke="currentColor" strokeWidth="1.25" />
      <path d="M8 16.4C8 11.2 11.5 7.4 16 7.4s8 3.8 8 9" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
      <path d="M8 16.4c1.5 1.5 3 2.2 4.4 2.2M24 16.4c-1.5 1.5-3 2.2-4.4 2.2" fill="none" stroke="currentColor" strokeWidth="1.45" strokeLinecap="round" />
      <path d="M12.2 18.6c-.7 2.1.9 3 0 5.3M16 18.8c.4 2.2-.9 3.1.5 5.5M19.8 18.6c.7 2.1-.9 3 0 5.3" fill="none" stroke="currentColor" strokeWidth="1.35" strokeLinecap="round" />
    </svg>
  );
}

type Rail = "desk" | "memory" | "history";

export function Sidebar({
  state,
  project,
  collapsed,
  gearTurn,
  memoryNote,
  summarizing,
  onToggleCollapse,
  onNewChat,
  onSelectChat,
  onNewProject,
  onSelectProject,
  onDeleteProject,
  onCode,
  onLab,
  onArtifacts,
  onSettings,
  onAddFact,
  onEditFact,
  onRemoveFact,
  onSummarize,
  onDownloadKnowledge,
  onRevert,
}: {
  state: JellyfishState;
  project: ProjectSpace;
  collapsed: boolean;
  gearTurn: number;
  memoryNote: string;
  summarizing: boolean;
  onToggleCollapse: () => void;
  onNewChat: () => void;
  onSelectChat: (id: string) => void;
  onNewProject: (name: string) => void;
  onSelectProject: (id: string) => void;
  onDeleteProject: (id: string) => void;
  onCode: () => void;
  onLab: () => void;
  onArtifacts: () => void;
  onSettings: () => void;
  onAddFact: (fact: string) => void;
  onEditFact: (before: string, after: string) => void;
  onRemoveFact: (fact: string) => void;
  onSummarize: () => void;
  onDownloadKnowledge: () => void;
  onRevert: (snap: Snapshot) => void;
}) {
  const [draftName, setDraftName] = useState("");
  const [rail, setRail] = useState<Rail>("desk");
  const codeOn = state.panel === "code";
  const labOn = state.panel === "lab";
  const artOn = state.artifactsOpen && state.panel === "chat";

  function pick(next: Rail) {
    setRail(next);
    if (collapsed) onToggleCollapse();
  }

  return (
    <aside className={"jf-rail flex h-full shrink-0 flex-col border-r border-line bg-bg " + (collapsed ? "w-14" : "w-64")}>
      <div className={"flex items-center gap-2 px-2 py-3 " + (collapsed ? "justify-center" : "")}>
        <button type="button" onClick={onToggleCollapse} aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"} className="inline-flex size-11 items-center justify-center">
          {collapsed ? <Mark className="size-7" /> : <PanelLeft className="size-4 text-muted" />}
        </button>
        {collapsed ? null : (
          <p className="min-w-0 truncate text-sm font-semibold tracking-tight">
            <span className="text-accent">Jellyfish</span> AI
          </p>
        )}
      </div>
      {collapsed ? null : <p className="px-4 pb-1 text-xs tracking-widest text-muted uppercase">V7</p>}

      <div className={collapsed ? "flex flex-col items-center px-1" : "grid grid-cols-3 px-1"}>
        <RailButton collapsed={collapsed} compact={!collapsed} label="Chats" icon={MessageSquare} onClick={() => pick("desk")} active={rail === "desk"} />
        <RailButton collapsed={collapsed} compact={!collapsed} label="Memory" icon={Brain} onClick={() => pick("memory")} active={rail === "memory"} />
        <RailButton collapsed={collapsed} compact={!collapsed} label="History" icon={History} onClick={() => pick("history")} active={rail === "history"} />
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto px-1 pb-2">
        {rail === "memory" && !collapsed ? (
          <MemoryPanel
            facts={state.facts}
            note={memoryNote}
            summarizing={summarizing}
            onAdd={onAddFact}
            onEdit={onEditFact}
            onRemove={onRemoveFact}
            onSummarize={onSummarize}
            onDownload={onDownloadKnowledge}
          />
        ) : null}
        {rail === "history" && !collapsed ? <HistoryPanel projectId={project.id} onRevert={onRevert} /> : null}
        {rail === "desk" ? (
          <>
            <Section label="Chats" collapsed={collapsed}>
              <RailButton collapsed={collapsed} label="New chat" icon={Plus} onClick={onNewChat} />
              {collapsed
                ? null
                : project.chats.map((chat) => (
                    <button
                      key={chat.id}
                      type="button"
                      onClick={() => onSelectChat(chat.id)}
                      className={
                        "block min-h-11 w-full truncate border-l-2 px-3 text-left text-sm " +
                        (chat.id === project.activeChatId && state.panel === "chat" ? "border-accent text-fg" : "border-transparent text-muted")
                      }
                    >
                      {chat.title}
                    </button>
                  ))}
            </Section>

            <Section label="Projects" collapsed={collapsed}>
              {collapsed ? (
                <RailButton collapsed label="Projects" icon={FolderClosed} onClick={onToggleCollapse} />
              ) : (
                <>
                  <form
                    className="flex items-center gap-1 px-1"
                    onSubmit={(event) => {
                      event.preventDefault();
                      onNewProject(draftName);
                      setDraftName("");
                    }}
                  >
                    <input
                      value={draftName}
                      onChange={(event) => setDraftName(event.target.value)}
                      placeholder="New project"
                      aria-label="New project name"
                      className="min-h-11 min-w-0 flex-1 border-b border-line bg-transparent px-2 text-sm text-fg outline-none placeholder:text-muted"
                    />
                    <button type="submit" aria-label="Create project" className="inline-flex size-11 items-center justify-center text-accent" disabled={!draftName.trim()}>
                      <Plus className="size-4" />
                    </button>
                  </form>
                  {state.projects.map((item) => {
                    const on = item.id === project.id;
                    return (
                      <div key={item.id} className="flex items-center">
                        <button
                          type="button"
                          onClick={() => onSelectProject(item.id)}
                          className={"min-h-11 min-w-0 flex-1 truncate border-l-2 px-3 text-left text-sm " + (on ? "border-accent text-fg" : "border-transparent text-muted")}
                        >
                          {item.name}
                        </button>
                        {on && state.projects.length > 1 ? (
                          <button type="button" aria-label={`Remove ${item.name}`} className="inline-flex size-11 items-center justify-center text-muted" onClick={() => onDeleteProject(item.id)}>
                            <Trash2 className="size-3.5" />
                          </button>
                        ) : null}
                      </div>
                    );
                  })}
                </>
              )}
            </Section>

            <Section label="Code" collapsed={collapsed}>
              <RailButton collapsed={collapsed} label="Code" icon={Braces} onClick={onCode} active={codeOn} />
              <RailButton collapsed={collapsed} label="3D lab" icon={Box} onClick={onLab} active={labOn} />
            </Section>

            <Section label="Artifacts" collapsed={collapsed}>
              <RailButton collapsed={collapsed} label="Artifacts" icon={PanelRight} onClick={onArtifacts} active={artOn} />
            </Section>
          </>
        ) : null}
      </div>

      <div className="border-t border-line p-2">
        <button type="button" onClick={onSettings} className={"inline-flex min-h-11 items-center gap-2 text-sm text-fg " + (collapsed ? "w-full justify-center" : "px-2")}>
          <Settings key={`gear-${gearTurn}`} className={"size-4" + (gearTurn > 0 ? " gear-spin" : "")} />
          {collapsed ? null : "Settings"}
        </button>
      </div>
    </aside>
  );
}

function Section({ label, collapsed, children }: { label: string; collapsed: boolean; children: ReactNode }) {
  return (
    <div className="mt-3">
      {collapsed ? null : <p className="px-3 pb-1 text-xs tracking-widest text-muted uppercase">{label}</p>}
      {children}
    </div>
  );
}

function RailButton({
  collapsed,
  label,
  icon: Icon,
  onClick,
  active,
  compact,
}: {
  collapsed: boolean;
  label: string;
  icon: typeof Plus;
  onClick: () => void;
  active?: boolean;
  compact?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={label}
      className={
        "inline-flex min-h-11 items-center gap-1 text-sm " +
        (compact ? "w-full justify-center px-1 text-xs " : collapsed ? "w-full justify-center " : "w-full px-3 ") +
        (active ? "text-accent" : "text-fg")
      }
    >
      <Icon className="size-4 shrink-0" />
      {collapsed ? null : label}
    </button>
  );
}
