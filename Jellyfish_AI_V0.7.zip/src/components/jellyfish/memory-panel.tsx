import { useEffect, useState } from "react";
import { Download, Trash2 } from "lucide-react";
import { refreshLessons, type Lesson } from "@/lib/jellyfish/knowledge";

export function MemoryPanel({
  facts,
  note,
  summarizing,
  onAdd,
  onEdit,
  onRemove,
  onSummarize,
  onDownload,
}: {
  facts: string[];
  note: string;
  summarizing: boolean;
  onAdd: (fact: string) => void;
  onEdit: (before: string, after: string) => void;
  onRemove: (fact: string) => void;
  onSummarize: () => void;
  onDownload: () => void;
}) {
  const [draft, setDraft] = useState("");
  const [editing, setEditing] = useState<string | null>(null);
  const [editDraft, setEditDraft] = useState("");
  const [notes, setNotes] = useState<Lesson[]>([]);

  useEffect(() => {
    let cancel = false;
    const load = () => {
      void refreshLessons().then((lessons) => {
        if (!cancel) setNotes(lessons.filter((lesson) => lesson.pattern === "session.summary").slice(-6).reverse());
      });
    };
    load();
    window.addEventListener("jellyfish-knowledge", load);
    return () => {
      cancel = true;
      window.removeEventListener("jellyfish-knowledge", load);
    };
  }, []);

  return (
    <div className="flex flex-col gap-3 px-2 pb-3">
      <form
        className="flex items-center gap-1"
        onSubmit={(event) => {
          event.preventDefault();
          onAdd(draft);
          setDraft("");
        }}
      >
        <input
          value={draft}
          onChange={(event) => setDraft(event.target.value)}
          placeholder="Add a fact"
          aria-label="Add a fact"
          className="min-h-11 min-w-0 flex-1 border-b border-line bg-transparent px-2 text-sm text-fg outline-none placeholder:text-muted"
        />
        <button type="submit" className="min-h-11 px-2 text-sm text-accent" disabled={!draft.trim()}>
          Save
        </button>
      </form>

      {facts.length === 0 ? <p className="px-2 text-sm text-muted">No facts yet. Tell Jellyfish to remember something.</p> : null}
      <ul className="flex flex-col">
        {facts.map((fact) => (
          <li key={fact} className="border-b border-line py-2">
            {editing === fact ? (
              <form
                className="flex flex-col gap-1 px-2"
                onSubmit={(event) => {
                  event.preventDefault();
                  onEdit(fact, editDraft);
                  setEditing(null);
                }}
              >
                <input
                  value={editDraft}
                  onChange={(event) => setEditDraft(event.target.value)}
                  aria-label={`Edit ${fact}`}
                  className="min-h-11 border-b border-line bg-transparent text-sm text-fg outline-none"
                />
                <div className="flex gap-2">
                  <button type="submit" className="min-h-11 text-sm text-accent">
                    Update
                  </button>
                  <button type="button" className="min-h-11 text-sm text-muted" onClick={() => setEditing(null)}>
                    Cancel
                  </button>
                </div>
              </form>
            ) : (
              <div className="flex items-start gap-1">
                <button
                  type="button"
                  className="min-h-11 flex-1 px-2 text-left text-sm text-fg"
                  onClick={() => {
                    setEditing(fact);
                    setEditDraft(fact);
                  }}
                >
                  {fact}
                </button>
                <button type="button" aria-label={`Delete ${fact}`} className="inline-flex size-11 items-center justify-center text-muted" onClick={() => onRemove(fact)}>
                  <Trash2 className="size-3.5" />
                </button>
              </div>
            )}
          </li>
        ))}
      </ul>

      <button type="button" className="min-h-11 px-2 text-left text-sm text-accent" onClick={onSummarize} disabled={summarizing}>
        {summarizing ? "Summarizing…" : "Summarize this chat"}
      </button>
      <button type="button" className="inline-flex min-h-11 items-center gap-2 px-2 text-left text-sm text-fg" onClick={onDownload}>
        <Download className="size-3.5" />
        Download knowledge.json
      </button>
      {note ? <p className="px-2 text-xs text-muted">{note}</p> : null}

      {notes.length ? (
        <div className="px-2">
          <p className="pb-1 text-xs tracking-widest text-muted uppercase">Session notes</p>
          <ul className="flex flex-col gap-2">
            {notes.map((lesson) => (
              <li key={lesson.id} className="text-xs leading-relaxed text-muted">
                {lesson.summary}
              </li>
            ))}
          </ul>
        </div>
      ) : null}
    </div>
  );
}
