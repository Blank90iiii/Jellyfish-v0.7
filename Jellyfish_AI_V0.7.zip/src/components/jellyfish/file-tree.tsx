import { useEffect, useMemo, useState } from "react";
import { ChevronDown, ChevronRight, FileText, Folder } from "lucide-react";
import { buildTree, parentFolders, type TreeNode } from "@/lib/jellyfish/filetree";

/*
  A flat list of file paths shown as a folder tree.
  Folders open and close. Tap a file to select it. Nothing here edits files.
*/
export function FileTree({
  paths,
  activeFile,
  onSelect,
}: {
  paths: string[];
  activeFile: string;
  onSelect: (path: string) => void;
}) {
  const tree = useMemo(() => buildTree(paths), [paths]);
  // Folders the person closed. Everything starts open.
  const [closed, setClosed] = useState<string[]>([]);

  // Selecting a file somewhere else (a tab, the AI, a restore) must never leave it hidden inside a closed folder.
  useEffect(() => {
    const parents = parentFolders(activeFile);
    if (!parents.length) return;
    setClosed((current) => (current.some((folder) => parents.includes(folder)) ? current.filter((folder) => !parents.includes(folder)) : current));
  }, [activeFile]);

  function toggle(folder: string) {
    setClosed((current) => (current.includes(folder) ? current.filter((item) => item !== folder) : [...current, folder]));
  }

  if (!paths.length) return <p className="px-5 py-3 text-xs text-muted">No files yet.</p>;

  return (
    <div role="tree" aria-label="Project files" className="max-h-44 overflow-y-auto border-b border-line px-3 py-2">
      <Branch nodes={tree} depth={0} closed={closed} activeFile={activeFile} onToggle={toggle} onSelect={onSelect} />
    </div>
  );
}

function Branch({
  nodes,
  depth,
  closed,
  activeFile,
  onToggle,
  onSelect,
}: {
  nodes: TreeNode[];
  depth: number;
  closed: string[];
  activeFile: string;
  onToggle: (folder: string) => void;
  onSelect: (path: string) => void;
}) {
  return (
    <ul role="group" className="flex flex-col">
      {nodes.map((node) => {
        const indent = { paddingLeft: `${depth * 14 + 4}px` };
        if (node.kind === "file") {
          const active = node.path === activeFile;
          return (
            <li key={node.path} role="none">
              <button
                type="button"
                role="treeitem"
                aria-selected={active}
                onClick={() => onSelect(node.path)}
                style={indent}
                className={"flex min-h-9 w-full items-center gap-2 pr-2 text-left font-mono text-xs " + (active ? "bg-accent text-accent-fg" : "text-fg")}
              >
                <FileText className="size-3.5 shrink-0" />
                <span className="truncate">{node.name}</span>
              </button>
            </li>
          );
        }
        const open = !closed.includes(node.path);
        return (
          <li key={node.path} role="none">
            <button
              type="button"
              role="treeitem"
              aria-expanded={open}
              onClick={() => onToggle(node.path)}
              style={indent}
              className="flex min-h-9 w-full items-center gap-2 pr-2 text-left font-mono text-xs text-muted"
            >
              {open ? <ChevronDown className="size-3.5 shrink-0" /> : <ChevronRight className="size-3.5 shrink-0" />}
              <Folder className="size-3.5 shrink-0" />
              <span className="truncate">{node.name}</span>
            </button>
            {open ? <Branch nodes={node.children} depth={depth + 1} closed={closed} activeFile={activeFile} onToggle={onToggle} onSelect={onSelect} /> : null}
          </li>
        );
      })}
    </ul>
  );
}
