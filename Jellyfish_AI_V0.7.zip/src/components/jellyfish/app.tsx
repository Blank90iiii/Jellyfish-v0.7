import { useEffect, useRef, useState } from "react";
import { Menu, PanelRight, Settings, Terminal } from "lucide-react";
import { useJellyfish, type Attachment, type ChatMessage } from "@/lib/jellyfish/store";
import { parseMessage, type Project, type ProjectFile } from "@/lib/jellyfish/parse";
import { compactHistory } from "@/lib/jellyfish/context";
import { extractFacts } from "@/lib/jellyfish/memory";
import { isImageAsk, localAnswer, offline, wantsSearch } from "@/lib/jellyfish/local";
import { downloadZip } from "@/lib/jellyfish/zip";
import { addLesson, lessonLines, refreshLessons } from "@/lib/jellyfish/knowledge";
import { pushSnapshot, pushWorkspaceSnapshot, type Snapshot } from "@/lib/jellyfish/history";
import { dequeueSidecar, enqueueSidecar } from "@/lib/jellyfish/sidecar";
import type { SidecarItem } from "@/lib/jellyfish/model";
import { estimateTokens, sessionSummary } from "@/lib/jellyfish/summary";
import { streamReply, type Turn } from "@/lib/jellyfish/router";
import { readUpload } from "@/lib/jellyfish/uploads";
import { inspectProject, probeProject, stressProject } from "@/lib/jellyfish/sandbox";
import { canSeeImages, CORE_NOTE, type CheckRound } from "@/lib/jellyfish/verify";
import { route, runBuild, type Effects } from "@/lib/jellyfish/conductor";
import { beginRun, endRun, noteCall, stepTo, type Outcome, type Phase } from "@/lib/jellyfish/telemetry";
import { loadApproval } from "@/lib/jellyfish/approval";
import { loadBuild } from "@/lib/jellyfish/buildconfig";
import { loadProviders, modelFor } from "@/lib/jellyfish/providers";
import { packAttachments, STUDY_THRESHOLD } from "@/lib/jellyfish/study";
import { hookSystem, sysLog } from "@/lib/jellyfish/syslog";
import { parseTools, stripTools, toolLabel, wrapResult, type ToolCall } from "@/lib/jellyfish/tools";
import { loadTools, type ToolsConfig } from "@/lib/jellyfish/toolsconfig";
import { runTool, webTool } from "@/lib/jellyfish/toolclient";
import { findPatch } from "@/lib/jellyfish/self";
import { installNetHook, peekError, pushLog } from "@/lib/jellyfish/console-bus";
import { ChatView } from "./chat-view";
import { IdeView } from "./ide-view";
import { SettingsView } from "./settings-view";
import { Sidebar } from "./sidebar";
import { ArtifactPane } from "./artifact-pane";
import { VoxelLab } from "./voxel-lab";
import { ConsoleDock } from "./console-dock";
import { DiffViewer, type DiffProposal } from "./diff-viewer";
import { TokenMeter } from "./token-meter";

/** How many tool calls the model may chain in one answer. */
const MAX_TOOL_TURNS = 4;

function packProject(text: string, project?: Project) {
  if (!project) return text;
  const files = project.files.map((file) => `<<<FILE ${file.path}\n${file.content}`).join("\n");
  return `${text}\n\n<<<PROJECT ${project.name}\n${files}\n<<<END`;
}

function withFiles(text: string, files: Attachment[]) {
  const extra = files
    .map((file) => (file.text ? `\n\n[file ${file.name}]\n${file.text}` : `\n[image ${file.name}]`))
    .join("");
  const body = `${text}${extra}`.trim();
  return body || "Look at the attached file.";
}

export function JellyfishApp() {
  const fish = useJellyfish();
  const { state, project, booted } = fish;
  const [draft, setDraft] = useState("");
  const [streaming, setStreaming] = useState(false);
  const [activity, setActivity] = useState("Thinking");
  const [gearTurn, setGearTurn] = useState(0);
  const [drawer, setDrawer] = useState(false);
  const [settings, setSettings] = useState(false);
  const [consoleOpen, setConsoleOpen] = useState(false);
  const [pendingFiles, setPendingFiles] = useState<Attachment[]>([]);
  const [uploadNote, setUploadNote] = useState("");
  const [autonomous, setAutonomous] = useState(false);
  const [proposal, setProposal] = useState("");
  const [planFirst, setPlanFirst] = useState(false);
  const [planHold, setPlanHold] = useState(false);
  const [diff, setDiff] = useState<DiffProposal | null>(null);
  const [approval, setApproval] = useState<{ title: string; detail: string; danger: boolean; why?: string; resolve: (ok: boolean) => void } | null>(null);
  const [memoryNote, setMemoryNote] = useState("");
  const [summarizing, setSummarizing] = useState(false);
  const abortRef = useRef<AbortController | null>(null);
  // Truth for the side-question queue (state.sidecarQueue mirrors it for the screen). A ref, so a running build always reads the latest list.
  const sidecarRef = useRef<SidecarItem[]>([]);
  const busyRef = useRef(false);
  const lastActive = useRef(Date.now());
  const proposalRef = useRef("");
  const chat = project.chats.find((item) => item.id === project.activeChatId) ?? project.chats[0];

  useEffect(() => {
    installNetHook();
    try {
      if (localStorage.getItem("jellyfish.autonomous") === "1") setAutonomous(true);
      if (localStorage.getItem("jellyfish.planFirst") === "1") setPlanFirst(true);
    } catch {
      /* ignore */
    }
    void refreshLessons();
  }, []);

  useEffect(() => {
    const pane = document.querySelector("[data-chat-scroll]");
    if (pane) pane.scrollTop = pane.scrollHeight;
  }, [chat?.messages, streaming, state.panel]);

  useEffect(() => {
    hookSystem();
  }, []);

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      if (event.key !== "Escape") return;
      if (abortRef.current) abortRef.current.abort();
      setDrawer(false);
      setSettings(false);
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    if (!autonomous) return;
    const timer = window.setInterval(() => {
      if (abortRef.current || proposalRef.current) return;
      if (Date.now() - lastActive.current < 120_000) return;
      const patch = findPatch(project.files);
      const error = peekError();
      if (patch) {
        proposalRef.current = patch.summary;
        setProposal(patch.summary);
      } else if (error) {
        proposalRef.current = error;
        setProposal(`Console error: ${error}`);
      } else {
        lastActive.current = Date.now();
      }
    }, 15_000);
    return () => window.clearInterval(timer);
  }, [autonomous, project.files]);

  function haltBackground() {
    lastActive.current = Date.now();
    proposalRef.current = "";
    setProposal("");
  }

  function patchMessage(projectId: string, chatId: string, messageId: string, recipe: (message: ChatMessage) => ChatMessage) {
    fish.update((current) => ({
      ...current,
      projects: current.projects.map((item) =>
        item.id === projectId
          ? {
              ...item,
              chats: item.chats.map((thread) =>
                thread.id === chatId
                  ? { ...thread, messages: thread.messages.map((message) => (message.id === messageId ? recipe(message) : message)) }
                  : thread,
              ),
            }
          : item,
      ),
    }));
  }

  function finishLocal(projectId: string, chatId: string, messageId: string, text: string, planning: boolean) {
    if (planning) {
      patchMessage(projectId, chatId, messageId, (message) => ({
        ...message,
        pending: false,
        text: "Plan:\n- Restate the request\n- List the files\n- Use script tags, never import or export\n- Run it and read the console\n\nApprove the plan and the files get written.",
      }));
      setPlanHold(true);
      return;
    }
    const answer = offline(localAnswer(text));
    patchMessage(projectId, chatId, messageId, (message) => ({
      ...message,
      pending: false,
      text: packProject(answer.text, answer.project),
    }));
    if (answer.project) fish.showArtifact(answer.project);
  }

  function askApproval(title: string, detail: string, danger = false, why?: string): Promise<boolean> {
    return new Promise((resolve) => setApproval({ title, detail, danger, why, resolve }));
  }

  /** Puts a question in the sidecar queue. Returns whether it was accepted, plus a short note for the person. */
  function queueSidecar(raw: string): { ok: boolean; note: string } {
    const result = enqueueSidecar(sidecarRef.current, raw, crypto.randomUUID());
    if (!result.accepted) return { ok: false, note: result.note };
    setSidecar(result.queue);
    return { ok: true, note: result.note };
  }

  function setSidecar(queue: SidecarItem[]) {
    sidecarRef.current = queue;
    fish.update((current) => ({ ...current, sidecarQueue: queue }));
  }

  function appendMessages(projectId: string, chatId: string, added: ChatMessage[]) {
    fish.update((current) => ({
      ...current,
      projects: current.projects.map((item) =>
        item.id === projectId
          ? { ...item, chats: item.chats.map((thread) => (thread.id === chatId ? { ...thread, messages: [...thread.messages, ...added] } : thread)) }
          : item,
      ),
    }));
  }

  async function executeTool(call: ToolCall, cfg: ToolsConfig, files: { path: string; content: string }[], signal: AbortSignal): Promise<string> {
    try {
      if ((call.name === "test" || call.name === "stress") && loadApproval() === "every") {
        if (!(await askApproval(`Run the ${call.name} tool`, "It runs the current project in the hidden sandbox."))) return "The person did not allow this test.";
      }
      if (call.name === "test") {
        if (!files.length) return "There is no project to test yet.";
        const errors = await probeProject(files as Parameters<typeof probeProject>[0]);
        return errors.length ? `Console errors:\n${errors.join("\n")}` : "No console errors.";
      }
      if (call.name === "stress") {
        if (!files.length) return "There is no project to test yet.";
        const report = await stressProject(files as Parameters<typeof stressProject>[0], 8);
        return `${report.fps.toFixed(0)} fps, longest freeze ${Math.round(report.maxGapMs)} ms. ${report.verdict.length ? `Problems: ${report.verdict.join("; ")}.` : "No problems found."}${report.errors.length ? `\nErrors:\n${report.errors.join("\n")}` : ""}`;
      }
      if (call.name === "search" || call.name === "news" || call.name === "read") {
        if (!cfg.web) return "The internet tool is switched off in Settings.";
        if (!(await askApproval(`Use the internet (${call.name})`, call.arg || "top headlines"))) return "The person did not allow this. Do not use the internet tool again unless they ask.";
        return await webTool(call.name, call.arg, cfg, signal);
      }
      if (call.name === "run") {
        if (!cfg.terminal) return "The terminal is switched off in Settings.";
        const ok = await askApproval("Run a command", call.arg, true, call.why ?? "");
        if (!ok) return "The person denied this command. Do not run it. Ask what they want instead.";
        const outcome = await runTool(call.arg, project.id, files, signal);
        sysLog("info", "terminal", `${call.arg.slice(0, 80)} -> ${outcome.text.split("\n")[0]}`);
        return outcome.text;
      }
      return "Unknown tool.";
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError") throw error;
      return `Tool failed: ${error instanceof Error ? error.message : "unknown error"}`;
    }
  }

  async function runStress() {
    if (!project.files.length) return;
    sysLog("info", "stress", "Stress test started (8 seconds of random keys and clicks)");
    const report = await stressProject(project.files, 8);
    const summary = `${report.fps.toFixed(0)} fps, ${report.frames} frames, longest freeze ${Math.round(report.maxGapMs)} ms${report.heapGrowthMb !== null ? `, memory +${report.heapGrowthMb.toFixed(1)} MB` : ""}`;
    if (report.verdict.length) pushLog("warn", `Stress test: ${report.verdict.join("; ")}. (${summary})`, "stress");
    else pushLog("log", `Stress test passed. ${summary}`, "stress");
    sysLog("info", "stress", `Finished: ${summary}`);
  }

  function applyParsed(full: string, userText = "") {
    const parsed = parseMessage(full, false);
    // A fact is saved from a model reply only when the person asked for it. Web pages the model reads cannot write memory.
    if (/\bremember\b/i.test(userText)) for (const fact of parsed.remembers) fish.remember(fact);
    for (const action of parsed.actions) {
      if (action.theme) fish.setTheme(action.theme);
      if (action.view === "ide" || action.view === "code") fish.setPanel("code");
      if (action.view === "chat") fish.setPanel("chat");
      if (action.view === "set") setSettings(true);
    }
    if (parsed.project) fish.showArtifact(parsed.project);
  }

  function stageFiles(name: string, files: ProjectFile[], reason: string) {
    const rows = files
      .map((file) => ({
        path: file.path,
        before: project.files.find((item) => item.path === file.path)?.content ?? "",
        after: file.content,
      }))
      .filter((row) => row.before !== row.after);
    if (!rows.length) {
      fish.loadWorkspace({ name, files }, true);
      return;
    }
    setDiff({ name, files, rows, reason });
  }

  function approveDiff() {
    if (!diff) return;
    for (const row of diff.rows) {
      pushSnapshot({ projectId: project.id, path: row.path, content: row.before, label: `Before ${row.path}` });
    }
    fish.loadWorkspace({ name: diff.name, files: diff.files }, true);
    setDiff(null);
  }

  function revertSnapshot(snap: Snapshot) {
    const current = project.files.find((file) => file.path === snap.path);
    if (current && current.content !== snap.content) {
      pushSnapshot({ projectId: project.id, path: snap.path, content: current.content, label: `Before revert ${snap.path}` });
    }
    if (!current) fish.addFile(snap.path);
    fish.updateFile(snap.path, snap.content);
    fish.setActiveFile(snap.path);
    fish.setPanel("code");
  }

  async function summarizeChat() {
    if (summarizing) return;
    const text = sessionSummary(chat?.messages ?? []);
    if (!text) {
      setMemoryNote("This chat is empty, so there is nothing to save.");
      return;
    }
    setSummarizing(true);
    try {
      await addLesson(text, "session.summary");
      setMemoryNote("Saved to the knowledge bank on this device.");
    } finally {
      setSummarizing(false);
    }
  }

  async function downloadKnowledge() {
    const lessons = await refreshLessons();
    const blob = new Blob([JSON.stringify({ version: 7, facts: state.facts, lessons }, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "knowledge.json";
    link.click();
    URL.revokeObjectURL(url);
  }

  async function send(raw: string, opts?: { plan?: boolean; original?: string }) {
    const typed = raw.trim();
    const files = pendingFiles;
    // A run is going: a typed message becomes a side question instead of a second model call.
    if (busyRef.current || streaming) {
      if (typed) queueSidecar(typed);
      return;
    }
    if (!typed && files.length === 0) return;
    haltBackground();
    setDraft("");
    setPendingFiles([]);
    setUploadNote("");
    const text = typed;
    const packed = withFiles(text, files);
    const build = loadBuild();
    const request = opts?.original ?? text;
    const rt = route(request, { hasProject: project.files.length > 0, planFirst, imageAsk: isImageAsk(text), checkpoints: build.checkpoints, verify: build.verify });
    const planning = opts?.plan ?? rt.plan;
    if (!planning) setPlanHold(false);
    const projectId = project.id;
    const chatId = project.activeChatId;
    const userId = crypto.randomUUID();
    const botId = crypto.randomUUID();
    const learned = extractFacts(text);
    for (const fact of learned) fish.remember(fact);
    const facts = [...state.facts];
    for (const fact of learned) {
      if (!facts.some((item) => item.toLowerCase() === fact.toLowerCase())) facts.push(fact);
    }
    fish.update((current) => ({
      ...current,
      panel: current.panel === "lab" ? "lab" : "chat",
      projects: current.projects.map((item) => {
        if (item.id !== projectId) return item;
        return {
          ...item,
          chats: item.chats.map((thread) => {
            if (thread.id !== chatId) return thread;
            const title = thread.messages.length === 0 ? (text || files[0]?.name || "New chat").slice(0, 42) : thread.title;
            return {
              ...thread,
              title,
              messages: [
                ...thread.messages,
                { id: userId, role: "user" as const, text, attachments: files.map((file) => ({ ...file, full: undefined })) },
                { id: botId, role: "assistant" as const, text: "", pending: true },
              ],
            };
          }),
        };
      }),
    }));

    const history = compactHistory([
      ...(chat?.messages ?? []).map((message) => ({
        role: message.role,
        content: message.imageUrl ? `${message.text}\n(an image was generated)` : message.text,
      })),
      { role: "user" as const, content: planning ? `${packed}\n\n[Plan mode] Reply with a short plan and a markdown checklist of files. Do not emit a PROJECT block yet.` : packed },
    ]);
    const images = files.map((file) => file.dataUrl).filter((url): url is string => !!url).slice(0, 1);

    const controller = new AbortController();
    abortRef.current = controller;
    busyRef.current = true;
    setStreaming(true);
    // Save the whole workspace before the AI can change anything. Unchanged files are skipped.
    try {
      const saved = pushWorkspaceSnapshot(project.id, project.files);
      if (saved) sysLog("info", "snapshot", `Saved ${saved} file${saved === 1 ? "" : "s"} before the AI request`);
    } catch {
      /* a full disk must never block a chat */
    }
    setActivity(isImageAsk(text) && images.length === 0 ? "Drawing" : "Thinking");

    const lessons = lessonLines();
    const toolsCfg = loadTools();
    const checkpointed = build.checkpoints && !planning && rt.intent === "build";
    beginRun(text || files[0]?.name || "Request");
    const mark = (phase: Phase, label: string, detail = "") => {
      stepTo(phase, label, detail);
      setActivity(label);
    };
    mark("memory", "Reading memory", `${facts.length} facts · ${state.rules.length} rules · ${lessons.length} lessons`);
    let outcome: Outcome = "done";

    async function runModel(turns: Turn[], onDelta: (chunk: string) => void, imagesOverride?: string[], plain = false) {
      noteCall();
      const result = await streamReply({
        messages: turns,
        facts,
        rules: state.rules,
        lessons,
        tools: plain ? undefined : { web: toolsCfg.web, terminal: toolsCfg.terminal },
        search: plain ? false : wantsSearch(text),
        images: imagesOverride ?? images,
        signal: controller.signal,
        onDelta,
        onCite: (urls) => {
          onDelta(`\n\nSources:\n${urls.map((url) => `- ${url}`).join("\n")}`);
        },
      });
      if (result && result !== "offline") sysLog("error", "model", result);
      return result;
    }

    /** Answers the first waiting side question as its own standalone prompt, in the chat, then returns so the build can go on. */
    async function answerSidecar(): Promise<void> {
      if (controller.signal.aborted) return;
      const { item, rest } = dequeueSidecar(sidecarRef.current);
      if (!item) return;
      setSidecar(rest);
      const answerId = crypto.randomUUID();
      appendMessages(projectId, chatId, [
        { id: crypto.randomUUID(), role: "user", text: item.text },
        { id: answerId, role: "assistant", text: "", pending: true },
      ]);
      mark("generating", "Answering a side question", item.text.slice(0, 80));
      sysLog("info", "sidecar", `Answering: ${item.text.slice(0, 80)}`);
      let answer = "";
      let failure: string | null | undefined;
      try {
        failure = await runModel(
          [{ role: "user", content: item.text }],
          (chunk) => {
            answer += chunk;
            patchMessage(projectId, chatId, answerId, (message) => ({ ...message, text: answer }));
          },
          [],
          true,
        );
      } finally {
        const text = answer.trim()
          ? answer
          : controller.signal.aborted
            ? "(stopped)"
            : failure && failure !== "offline"
              ? failure
              : "I could not answer that one. Ask it again when the build is done.";
        patchMessage(projectId, chatId, answerId, (message) => ({ ...message, pending: false, text }));
      }
    }

    try {
      if (files.some((file) => file.full && file.full.length > STUDY_THRESHOLD)) {
        const ask = async (prompt: string) => {
          let out = "";
          const failure = await streamReply({
            messages: [{ role: "user", content: prompt }],
            facts: [],
            rules: [],
            lessons: [],
            signal: controller.signal,
            onDelta: (chunk) => {
              out += chunk;
            },
          });
          if (failure && !out) throw new Error(failure);
          return out;
        };
        sysLog("info", "study", `Studying ${files.filter((file) => file.full).length} big file(s) in parts`);
        const studied = await packAttachments(files, text, ask, (note) => mark("studying", note), controller.signal);
        if (controller.signal.aborted) throw new DOMException("Aborted", "AbortError");
        const body = `${text}${studied}`.trim();
        history[history.length - 1] = {
          role: "user",
          content: planning ? `${body}\n\n[Plan mode] Reply with a short plan and a markdown checklist of files. Do not emit a PROJECT block yet.` : body,
        };
      }
      if (checkpointed) {
        const last = history[history.length - 1];
        history[history.length - 1] = { ...last, content: `${last.content}${CORE_NOTE}` };
      }
      if (isImageAsk(text) && images.length === 0) {
        // Cloud pictures only when the person turned the toggle ON. Anything else draws locally.
        if (loadProviders().cloudPictures) {
          try {
            const response = await fetch("/api/image", {
              method: "POST",
              headers: { "content-type": "application/json" },
              signal: controller.signal,
              body: JSON.stringify({ prompt: text, cloud: true }),
            });
            if (response.ok) {
              const data = (await response.json()) as { url?: string };
              if (data.url) {
                patchMessage(projectId, chatId, botId, (message) => ({
                  ...message,
                  pending: false,
                  text: "Here it is.",
                  imageUrl: data.url,
                }));
                return;
              }
            }
          } catch (error) {
            if (controller.signal.aborted) throw error;
          }
          sysLog("warn", "image", "Cloud picture failed, drawing locally with Qwen");
        }
        const last = history[history.length - 1];
        history[history.length - 1] = {
          ...last,
          content: `${last.content}\n\n[Draw this as one complete svg block with a viewBox. No scripts, no external links.]`,
        };
      }

      let full = "";
      mark(planning ? "planning" : "generating", planning ? "Writing a plan" : "Writing code");
      const failure = await runModel(history, (chunk) => {
        full += chunk;
        patchMessage(projectId, chatId, botId, (message) => ({ ...message, text: full }));
      });
      if (!full.trim()) {
        if (failure && failure !== "offline") {
          patchMessage(projectId, chatId, botId, (message) => ({ ...message, pending: false, text: failure }));
          return;
        }
        finishLocal(projectId, chatId, botId, text || packed, planning);
        return;
      }

      // Tool loop: the model asks, Jellyfish runs the tool, the result goes back as outside data.
      const toolNotes: string[] = [];
      if (!planning) {
        const convo: Turn[] = [...history];
        for (let turn = 0; turn < MAX_TOOL_TURNS && !controller.signal.aborted; turn += 1) {
          const call = parseTools(full)[0];
          if (!call) break;
          const files = parseMessage(stripTools(full), false).project?.files ?? project.files;
          mark("tool", `Using ${call.name}`, call.arg.slice(0, 80));
          sysLog("info", "tool", toolLabel(call));
          const result = await executeTool(call, toolsCfg, files, controller.signal);
          toolNotes.push(`Used ${toolLabel(call)}`);
          convo.push({ role: "assistant", content: stripTools(full).slice(0, 3000) || `(using ${call.name})` });
          convo.push({ role: "user", content: wrapResult(call.name, call.arg, result) });
          let next = "";
          const toolError = await runModel(convo, (chunk) => {
            next += chunk;
            patchMessage(projectId, chatId, botId, (message) => ({ ...message, text: next }));
          });
          if (toolError || !next.trim()) {
            full = stripTools(full) || `(${toolError ?? "no reply"})`;
            break;
          }
          full = next;
        }
        if (toolNotes.length) full = `${toolNotes.map((note) => `*${note}*`).join("\n")}\n\n${stripTools(full)}`;
      }

      const first = parseMessage(full, false);
      let checks: CheckRound[] = [];
      if (!planning && first.project && !controller.signal.aborted) {
        const providers = loadProviders();
        const effects: Effects = {
          generate: (turns, onDelta, o) => runModel(turns, onDelta, o?.images, o?.plain),
          probe: (projectFiles) => probeProject(projectFiles),
          inspect: (projectFiles) => inspectProject(projectFiles),
          confirm: (title, detail) => askApproval(title, detail),
          aborted: () => controller.signal.aborted,
          step: mark,
          text: (partial) => patchMessage(projectId, chatId, botId, (message) => ({ ...message, text: partial })),
          checks: (rounds) => patchMessage(projectId, chatId, botId, (message) => ({ ...message, checks: rounds })),
          lesson: (note) => void addLesson(note, "code.sandbox"),
          log: (note) => sysLog("info", "build", note),
          between: answerSidecar,
        };
        const result = await runBuild(
          {
            request,
            history,
            full,
            project: first.project,
            checkpointed,
            verify: build.verify && rt.intent !== "explain",
            canSee: canSeeImages(providers.active, modelFor(providers, providers.active)),
            approveEveryStep: loadApproval() === "every",
          },
          effects,
        );
        full = result.full;
        checks = result.checks;
      }

      patchMessage(projectId, chatId, botId, (message) => ({ ...message, pending: false, text: full, checks: checks.length ? checks : message.checks }));
      if (planning) {
        mark("approval", "Waiting for your approval", "Press Approve to write the files");
        setPlanHold(true);
      } else applyParsed(full, text);
      // Side questions the build never reached (a plain chat reply, a short build): answer them now, one by one.
      while (sidecarRef.current.length && !controller.signal.aborted) await answerSidecar();
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError") {
        outcome = "stopped";
        patchMessage(projectId, chatId, botId, (message) => ({
          ...message,
          pending: false,
          text: message.text.trim() ? `${message.text}\n\n(stopped)` : "Stopped.",
        }));
      } else {
        outcome = "failed";
        finishLocal(projectId, chatId, botId, text || packed, planning);
      }
    } finally {
      if (sidecarRef.current.length) {
        sysLog("warn", "sidecar", `Cleared ${sidecarRef.current.length} waiting side question(s) because the run ended early`);
        setSidecar([]);
      }
      busyRef.current = false;
      endRun(outcome);
      abortRef.current = null;
      setStreaming(false);
      lastActive.current = Date.now();
    }
  }

  async function onAttach(list: FileList | null) {
    haltBackground();
    if (!list?.length) return;
    for (const file of Array.from(list).slice(0, 4)) {
      const result = await readUpload(file);
      if (result.error) setUploadNote(result.error);
      if (result.attachment) {
        const attachment = result.attachment;
        setPendingFiles((current) => [...current, attachment].slice(0, 4));
      }
    }
  }

  function applyProposal() {
    const patch = findPatch(project.files);
    const error = peekError();
    haltBackground();
    if (patch) {
      const next = project.files.map((file) => (file.path === patch.path ? { ...file, content: patch.after } : file));
      stageFiles(project.name, next, patch.summary);
      return;
    }
    if (error) void send(`Explain this error in simple words, then fix the code:\n${error}`, { plan: false });
  }

  function explainError(text: string) {
    fish.setPanel("chat");
    setConsoleOpen(false);
    void send(`Explain this error in simple words, then fix the code:\n${text}`, { plan: false });
  }

  function openSettings() {
    setGearTurn((turn) => turn + 1);
    setSettings(true);
    setDrawer(false);
  }

  function closeDrawer() {
    setDrawer(false);
  }

  if (!booted || !chat) {
    return (
      <main className="flex h-dvh flex-col items-center justify-center bg-bg text-fg">
        <p className="text-lg font-semibold tracking-tight">
          <span className="text-accent">Jellyfish</span> AI
        </p>
        <p className="mt-2 text-sm text-muted">Restoring your chats</p>
      </main>
    );
  }

  const previewFiles = project.artifact?.files.length ? project.artifact.files : project.files;
  const previewName = project.artifact?.name || project.name;

  const sidebarProps = {
    state,
    project,
    gearTurn,
    onNewChat: () => {
      fish.newChat();
      closeDrawer();
    },
    onSelectChat: (id: string) => {
      fish.selectChat(id);
      closeDrawer();
    },
    onNewProject: (name: string) => {
      fish.newProject(name);
      closeDrawer();
    },
    onSelectProject: (id: string) => {
      fish.selectProject(id);
      closeDrawer();
    },
    onDeleteProject: fish.deleteProject,
    onCode: () => {
      fish.setPanel("code");
      closeDrawer();
    },
    onLab: () => {
      fish.setPanel("lab");
      closeDrawer();
    },
    onArtifacts: () => {
      const open = !(state.artifactsOpen && state.panel === "chat");
      fish.setArtifactsOpen(open);
      closeDrawer();
    },
    onSettings: openSettings,
    memoryNote,
    summarizing,
    onAddFact: fish.remember,
    onEditFact: fish.editFact,
    onRemoveFact: fish.removeFact,
    onSummarize: () => void summarizeChat(),
    onDownloadKnowledge: () => void downloadKnowledge(),
    onRevert: revertSnapshot,
  };

  return (
    <main className="flex h-dvh overflow-hidden bg-bg text-fg">
      <div className="hidden md:flex">
        <Sidebar {...sidebarProps} collapsed={state.sidebarCollapsed} onToggleCollapse={() => fish.setSidebarCollapsed(!state.sidebarCollapsed)} />
      </div>
      {drawer ? (
        <div className="fixed inset-0 z-30 md:hidden">
          <button type="button" aria-label="Close menu" className="absolute inset-0 bg-black/60" onClick={closeDrawer} />
          <div className="relative h-full w-64">
            <Sidebar {...sidebarProps} collapsed={false} onToggleCollapse={closeDrawer} />
          </div>
        </div>
      ) : null}

      <div className="relative flex min-w-0 flex-1 flex-col">
        <header className="flex items-center gap-1 border-b border-line px-2">
          <button type="button" className="inline-flex size-11 items-center justify-center md:hidden" aria-label="Open menu" onClick={() => setDrawer(true)}>
            <Menu className="size-4" />
          </button>
          <p className="min-w-0 flex-1 truncate text-sm text-fg">{state.panel === "lab" ? "3D lab" : project.name}</p>
          <TokenMeter
            used={estimateTokens(
              (chat?.messages ?? []).map((message) => message.text).join("\n") + state.facts.join("\n"),
            )}
          />
          <button
            type="button"
            aria-label={consoleOpen ? "Hide console" : "Show console"}
            onClick={() => setConsoleOpen((open) => !open)}
            className={"inline-flex size-11 items-center justify-center " + (consoleOpen ? "text-accent" : "text-muted")}
          >
            <Terminal className="size-4" />
          </button>
          <button
            type="button"
            aria-label={state.artifactsOpen ? "Hide artifacts" : "Show artifacts"}
            onClick={() => fish.setArtifactsOpen(!state.artifactsOpen)}
            className={"inline-flex size-11 items-center justify-center " + (state.artifactsOpen ? "text-accent" : "text-muted")}
          >
            <PanelRight className="size-4" />
          </button>
          <button type="button" aria-label="Settings" onClick={openSettings} className="inline-flex size-11 items-center justify-center text-muted md:hidden">
            <Settings key={`gear-bar-${gearTurn}`} className={"size-4" + (gearTurn > 0 ? " gear-spin" : "")} />
          </button>
        </header>

        {state.panel === "lab" && !settings ? (
          <VoxelLab />
        ) : state.panel === "chat" ? (
          <div className="flex min-h-0 flex-1 flex-col md:flex-row">
            <div className={(state.artifactsOpen ? "hidden md:flex" : "flex") + " min-h-0 min-w-0 flex-1 flex-col"}>
              <ChatView
                chat={chat}
                projectName={project.name}
                draft={draft}
                streaming={streaming}
                activity={activity}
                attachments={pendingFiles}
                notice={uploadNote}
                proposal={proposal}
                planFirst={planFirst}
                planHold={planHold}
                sidecar={state.sidecarQueue}
                onSidecar={queueSidecar}
                onDraft={(value) => {
                  haltBackground();
                  setDraft(value);
                }}
                onSend={send}
                onStop={() => {
                  abortRef.current?.abort();
                  approval?.resolve(false);
                  setApproval(null);
                }}
                onAttach={(list) => void onAttach(list)}
                onRemove={(id) => setPendingFiles((current) => current.filter((item) => item.id !== id))}
                onApplyProposal={applyProposal}
                onDismissProposal={haltBackground}
                onPlanFirst={(on) => {
                  setPlanFirst(on);
                  try {
                    localStorage.setItem("jellyfish.planFirst", on ? "1" : "0");
                  } catch {
                    /* ignore */
                  }
                  if (!on) setPlanHold(false);
                }}
                onApprovePlan={() => {
                  setPlanHold(false);
                  const original = [...(chat?.messages ?? [])].reverse().find((message) => message.role === "user")?.text ?? "";
                  void send("Approved. Write the complete runnable project now. Use script tags for libraries. Never use import or export.", { plan: false, original });
                }}
                onOpen={(item) => stageFiles(item.name, item.files, "This replaces the open workspace files.")}
                onPreview={(item) => fish.showArtifact(item)}
                onZip={(item) => void downloadZip(item.name, item.files)}
              />
            </div>
            {state.artifactsOpen && !settings ? (
              <ArtifactPane
                name={previewName}
                files={previewFiles}
                onClose={() => fish.setArtifactsOpen(false)}
                onOpenCode={() => {
                  if (project.artifact) stageFiles(project.artifact.name, project.artifact.files, "This replaces the open workspace files.");
                  else fish.setPanel("code");
                }}
              />
            ) : null}
          </div>
        ) : settings ? (
          <div className="min-h-0 flex-1" />
        ) : (
          <IdeView
            projectId={project.id}
            files={project.files}
            activeFile={project.activeFile}
            runToken={state.runToken}
            theme={state.theme}
            onTheme={fish.setTheme}
            onChange={fish.updateFile}
            onSelect={fish.setActiveFile}
            onAdd={fish.addFile}
            onDelete={fish.deleteFile}
            onLoad={(files, run) => fish.loadWorkspace({ name: project.name, files }, run)}
            onZip={() => void downloadZip(project.name, project.files)}
            onExplain={explainError}
          />
        )}

        {approval ? (
          <div className={"fixed inset-x-0 bottom-0 z-50 border-t bg-surface p-4 " + (approval.danger ? "border-[#ff2d2d]" : "border-accent")}>
            <p className={"text-xs tracking-widest uppercase " + (approval.danger ? "text-[#ff2d2d]" : "text-accent")}>Jellyfish wants to: {approval.title}</p>
            {approval.why !== undefined ? (
              <p className="mt-2 text-sm text-fg">
                The AI says: {approval.why ? approval.why : "(it gave no reason for this command, so deny it unless you know why it is needed)"}
              </p>
            ) : null}
            <pre className="mt-2 max-h-32 overflow-auto font-mono text-sm break-all whitespace-pre-wrap text-fg">{approval.detail}</pre>
            {approval.danger ? <p className="mt-1 text-xs text-muted">It runs in this project's folder on your computer. Only allow what you understand.</p> : null}
            <div className="mt-3 flex gap-3">
              <button
                type="button"
                className="min-h-11 flex-1 bg-accent text-sm text-accent-fg"
                onClick={() => {
                  approval.resolve(true);
                  setApproval(null);
                }}
              >
                Run it
              </button>
              <button
                type="button"
                className="min-h-11 flex-1 border border-line text-sm text-fg"
                onClick={() => {
                  approval.resolve(false);
                  setApproval(null);
                }}
              >
                Deny
              </button>
            </div>
          </div>
        ) : null}
        {consoleOpen && state.panel === "chat" ? <ConsoleDock onExplain={explainError} onStress={runStress} /> : null}

        {settings ? (
          <SettingsView
            theme={state.theme}
            facts={state.facts}
            files={project.files}
            autonomous={autonomous}
            onTheme={fish.setTheme}
            primary={state.primary}
            secondary={state.secondary}
            rules={state.rules}
            onPalette={fish.setPalette}
            onAddRule={fish.addRule}
            onRemoveRule={fish.removeRule}
            onRemoveFact={fish.removeFact}
            onClearFacts={fish.clearFacts}
            onClearChats={fish.clearChats}
            onAutonomous={(on) => {
              setAutonomous(on);
              try {
                localStorage.setItem("jellyfish.autonomous", on ? "1" : "0");
              } catch {
                /* ignore */
              }
              haltBackground();
            }}
            onRewrite={(path, content) => fish.updateFile(path, content)}
            onClose={() => setSettings(false)}
          />
        ) : null}
        {diff ? <DiffViewer proposal={diff} onApprove={approveDiff} onReject={() => setDiff(null)} /> : null}
      </div>
    </main>
  );
}
