import { CONTEXT_LIMIT } from "@/lib/jellyfish/summary";

export function TokenMeter({ used }: { used: number }) {
  const pct = Math.min(100, Math.round((used / CONTEXT_LIMIT) * 100));
  const hot = pct >= 75;
  return (
    <div className="flex min-w-0 items-center gap-2" title={`${used.toLocaleString()} of ${CONTEXT_LIMIT.toLocaleString()} estimated tokens`}>
      <div className="h-1.5 w-14 shrink-0 bg-elev sm:w-20" aria-hidden="true">
        <div className={"h-full " + (hot ? "bg-danger" : "bg-accent")} style={{ width: `${pct}%` }} />
      </div>
      <span className={"shrink-0 text-xs " + (hot ? "text-danger" : "text-muted")}>{pct}%</span>
      {hot ? <span className="hidden truncate text-xs text-danger lg:inline">Start a new chat</span> : null}
    </div>
  );
}
