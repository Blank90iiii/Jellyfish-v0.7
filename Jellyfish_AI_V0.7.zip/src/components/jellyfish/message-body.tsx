import { useState, type ReactNode } from "react";
import { Copy, Download, Play } from "lucide-react";
import { parseMessage, splitCode, type Project } from "@/lib/jellyfish/parse";
import type { CheckRound } from "@/lib/jellyfish/verify";

const OFFLINE = "Couldn't reach the cloud brain. On-device answer:";

function Inline({ text }: { text: string }) {
  const nodes: ReactNode[] = [];
  const re = /(`[^`\n]+`)|(\*\*[^*\n]+\*\*)|(\[[^\]]+\]\(https?:\/\/[^)\s]+\))|(https?:\/\/[^\s)]+)/g;
  let last = 0;
  let match: RegExpExecArray | null;
  let key = 0;
  while ((match = re.exec(text))) {
    if (match.index > last) nodes.push(text.slice(last, match.index));
    const token = match[0];
    if (token.startsWith("`")) {
      nodes.push(
        <code key={key++} className="bg-elev px-1 font-mono text-sm">
          {token.slice(1, -1)}
        </code>,
      );
    } else if (token.startsWith("**")) {
      nodes.push(<strong key={key++}>{token.slice(2, -2)}</strong>);
    } else if (token.startsWith("[")) {
      const link = token.match(/^\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)$/);
      if (link) {
        nodes.push(
          <a key={key++} href={link[2]} target="_blank" rel="noreferrer" className="text-cute underline">
            {link[1]}
          </a>,
        );
      }
    } else {
      nodes.push(
        <a key={key++} href={token} target="_blank" rel="noreferrer" className="text-cute underline break-all">
          {token}
        </a>,
      );
    }
    last = match.index + token.length;
  }
  if (last < text.length) nodes.push(text.slice(last));
  return <>{nodes}</>;
}

function Prose({ text }: { text: string }) {
  const lines = text.split("\n");
  return (
    <div className="space-y-1">
      {lines.map((line, index) => {
        if (!line.trim()) return <div key={index} className="h-2" />;
        if (/<<<(?:FILE|PROJECT|END|REMEMBER|ACTION)\b/.test(line)) return null;
        if (line.startsWith("### "))
          return (
            <h3 key={index} className="pt-2 text-xl font-semibold text-fg">
              <Inline text={line.slice(4)} />
            </h3>
          );
        if (line.startsWith("- "))
          return (
            <p key={index} className="pl-4 leading-relaxed">
              <span className="mr-2 text-muted">•</span>
              <Inline text={line.slice(2)} />
            </p>
          );
        return (
          <p key={index} className="leading-relaxed">
            <Inline text={line} />
          </p>
        );
      })}
    </div>
  );
}

function svgUrl(source: string): string | null {
  const text = source.trim();
  if (!/^<svg[\s>]/i.test(text) || !/<\/svg>\s*$/i.test(text) || text.length > 200_000) return null;
  // An <img> never runs scripts, but strip them anyway so a saved copy is clean too.
  const clean = text.replace(/<script[\s\S]*?<\/script>/gi, "").replace(/\son\w+\s*=\s*("[^"]*"|'[^']*')/gi, "");
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(clean)}`;
}

function CodeBlock({ lang, value }: { lang: string; value: string }) {
  const [copied, setCopied] = useState(false);
  const picture = /^(svg|xml|html)?$/i.test(lang ?? "") ? svgUrl(value) : null;
  if (/<<<(?:FILE|PROJECT|END)\b/.test(value)) return null;
  return (
    <div className="my-3 overflow-hidden border border-line">
      <div className="flex items-center justify-between border-b border-line px-3 py-1.5">
        <span className="font-mono text-xs text-muted">{lang}</span>
        <button
          type="button"
          className="inline-flex min-h-8 items-center gap-1 px-2 text-xs text-muted hover:text-fg"
          onClick={() => {
            void navigator.clipboard?.writeText(value).then(() => {
              setCopied(true);
              setTimeout(() => setCopied(false), 1200);
            });
          }}
        >
          <Copy className="size-3.5" />
          {copied ? "Copied" : "Copy"}
        </button>
      </div>
      {picture ? (
        <div className="border-b border-line p-3">
          <img src={picture} alt="Picture drawn from code" className="mx-auto max-h-80 w-full bg-white object-contain" />
          <a href={picture} download="jellyfish.svg" className="mt-2 inline-block min-h-8 text-xs text-accent">
            Save as SVG
          </a>
        </div>
      ) : null}
      <pre className="overflow-x-auto p-3 font-mono text-sm leading-relaxed text-fg">
        <code>{value}</code>
      </pre>
    </div>
  );
}

function ChecksCard({ rounds }: { rounds: CheckRound[] }) {
  return (
    <div className="mt-4 border border-line">
      <p className="border-b border-line px-3 py-2 text-xs tracking-widest text-muted uppercase">Tested while building</p>
      {rounds.map((round, index) => {
        const failed = round.items.filter((item) => item.status === "fail").length;
        return (
          <div key={`${round.label}-${index}`} className="border-b border-line p-3 last:border-b-0">
            <p className={"text-sm " + (failed ? "text-danger" : "text-fg")}>
              {round.label} {failed ? `· ${failed} failed` : "· all passed"}
            </p>
            <div className="mt-2 flex gap-3">
              {round.shot ? <img src={round.shot} alt="What the running project looked like" className="h-32 w-auto shrink-0 border border-line bg-white object-contain" /> : null}
              <ul className="min-w-0 text-xs leading-relaxed">
                {round.items.map((item, i) => (
                  <li key={i} className={item.status === "fail" ? "text-danger" : item.status === "unsure" ? "text-muted" : "text-fg"}>
                    {item.status === "pass" ? "✓" : item.status === "fail" ? "✗" : "?"} {item.text}
                    {item.note ? <span className="text-muted"> — {item.note}</span> : null}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        );
      })}
    </div>
  );
}

export function MessageBody({
  raw,
  pending,
  imageUrl,
  checks,
  activity,
  onOpen,
  onPreview,
  onZip,
}: {
  raw: string;
  pending?: boolean;
  imageUrl?: string;
  checks?: CheckRound[];
  activity?: string;
  onOpen: (project: Project) => void;
  onPreview: (project: Project) => void;
  onZip: (project: Project) => void;
}) {
  const parsed = parseMessage(raw, !!pending);
  const offline = parsed.text.startsWith(OFFLINE);
  const body = offline ? parsed.text.slice(OFFLINE.length).trim() : parsed.text;
  const parts = splitCode(body);

  return (
    <div>
      {offline ? <p className="mb-2 text-sm text-muted">{OFFLINE}</p> : null}
      {parsed.thought ? (
        <details className="mb-3 border border-line">
          <summary className="px-3 py-2 text-sm text-muted">View Jellyfish's Thought Process</summary>
          <p className="px-3 pb-3 text-sm leading-relaxed whitespace-pre-wrap text-muted">{parsed.thought}</p>
        </details>
      ) : null}
      {pending && !parsed.text && !parsed.project && !imageUrl ? (
        <p className="flex items-center gap-2 text-muted">
          <span className="pulse-dot size-2 rounded-full bg-cute" />
          {activity || "Thinking"}
        </p>
      ) : null}
      {parts.map((part, index) =>
        part.type === "code" ? (
          <CodeBlock key={index} lang={part.lang} value={part.value} />
        ) : (
          <Prose key={index} text={part.value} />
        ),
      )}
      {imageUrl ? <img src={imageUrl} alt="" className="mt-3 max-h-80 w-full border border-line bg-bg object-contain" /> : null}
      {checks?.length ? <ChecksCard rounds={checks} /> : null}
      {parsed.project ? (
        <div className="mt-4 border border-line p-4">
          <p className="text-xs tracking-widest text-muted uppercase">Download zip</p>
          <p className="mt-1 font-medium text-fg">{parsed.project.name}</p>
          <ul className="mt-2 space-y-1">
            {parsed.project.files.map((file) => (
              <li key={file.path} className="font-mono text-sm text-muted">
                {file.path}
              </li>
            ))}
          </ul>
          <div className="mt-3 flex flex-wrap gap-2">
            <button
              type="button"
              className="inline-flex min-h-11 items-center gap-2 bg-accent px-4 text-sm text-accent-fg"
              onClick={() => onPreview(parsed.project as Project)}
            >
              <Play className="size-4" />
              Preview
            </button>
            <button
              type="button"
              className="inline-flex min-h-11 items-center gap-2 px-3 text-sm text-fg"
              onClick={() => onOpen(parsed.project as Project)}
            >
              Open in Code
            </button>
            <button
              type="button"
              className="inline-flex min-h-11 items-center gap-2 px-3 text-sm text-fg"
              onClick={() => onZip(parsed.project as Project)}
            >
              <Download className="size-4" />
              Download zip
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );
}
