# Changelog

## v0.7.0

Written blind (no npm install, no browser). Logic is unit tested; React rendering is NOT.

### Added
- File tree: `file-tree.tsx` replaces the file tabs in `ide-view.tsx`. Collapsible folders built from the flat path list by `filetree.ts`.
- Terminal WHY: the AI must write `<<<WHY reason>>>` right before any `<<<TOOL run`. Parsed in `parse.ts` and `tools.ts`, demanded in the local and server system prompts, and shown as "The AI says: ..." above the Run it / Deny bar (in `app.tsx`).
- Sidecar Q&A queue: type a question while the AI is building. It waits in `sidecarQueue`, is answered between build steps as a standalone prompt, appended to the chat, and the build resumes. Max 5 waiting, 500 characters each. Cleared if the run is stopped or fails. Logic in `sidecar.ts`; small second input in `chat-view.tsx`.
- Auto-snapshot: a full workspace snapshot (changed files only) is taken in `history.ts` right before every model call. Snapshot cap raised from 40 to 60.
- `jargon.ts`: 20 coding terms and `getJargon(term)`. Data only, no tooltip UI yet.
- Conductor `between` hook (optional effect) called between build steps; used by the sidecar.

### Hardened
- `parseMessage`: a repeated file path in one reply replaces the earlier copy (case-insensitive, `./` ignored); no duplicate paths. An empty later copy does not wipe an earlier one.
- `safeRelPath`: rejects empty, trailing-slash and trailing-dot paths; merges doubled slashes.

### Tests
- 70 tests (was 50): WHY parser, dedup, safe paths, file tree, jargon, sidecar queue, snapshot diffing, conductor `between`.

## v0.4.0

### Speed
- Ollama chat requests now send `keep_alive: -1` (in `streamOllama()`, `router.ts`), so the model stays loaded in memory and only the first reply pays the load time. Trade-off: the model's memory stays in use until Ollama is quit or the model is unloaded.
- Flash attention is NOT a code change. It is a Windows environment variable on the Ollama service (see FULL_GUIDE.txt section 13, Speed Backdoors).

### Tests
- New test checks the Ollama request body (`keep_alive: -1`, stream, `num_ctx` 8192, temperature 0.2, system message first). 50 tests.
- `router.ts` imports now carry `.ts` extensions so the test can import it.

### Docs
- FULL_GUIDE.txt section 4 and section 13: Standard (7B) is the shipped default; Pro (14B) is deferred until the laptop has 16 GB RAM confirmed; Speed Backdoors added; Q3 fallback documented as a future 8 GB path.

## v0.3.0

Pre-flight for the Windows PC. No features were removed.

### Build safety
- Monaco loader rewritten to the Vite recipe: the editor worker is imported with `?worker` and passed to `MonacoEnvironment.getWorker` (set before the editor is created). A failed load can be retried the next time an editor opens.
- `vite.config.ts`: `worker.format` is `"es"` so the Monaco worker bundles safely in `npm run build`.
- `package-lock.json` removed. It was generated without network access; `npm install` on your own computer creates a correct one.

### Cleanup
- Removed unused dependencies `zod` and `eslint-plugin-prettier`, and the dead `clearRun` and `LOCAL_DEFAULT_MODEL` exports. No unused imports or locals remain (checked with the TypeScript compiler). No stray `console.log` in app code.
- Bundle: Monaco stays in its own lazily loaded chunk.

### Docs and versions
- README.txt rewritten for v0.3.0: 49 tests, Monaco, local-first, Cloud Pictures, current file map.
- Version 0.3.0 in `package.json`, `desktop/package.json` and `version.ts`.

## v0.2.0

### Local-first
- Default brain is Qwen (Ollama). Settings from v0.1 (keys, models, URLs) are kept on first launch; the active brain resets to Qwen.
- New **Cloud Pictures** toggle in Settings (default OFF). The image route also refuses requests unless the toggle sent `cloud: true`. If the cloud picture fails, Qwen draws an SVG locally.

### IDE and UI
- Monaco editor (bundled, works offline) replaces the textarea; HTML/CSS/JS highlighting; one model per file. Falls back to a textarea if Monaco cannot load.
- Quick Day/Night toggle in the IDE toolbar; Monaco theme follows it.
- Tap-for-help "?" tooltips (IDE toolbar, Cloud Pictures, Connect). Fix: the Help button stops its click from bubbling and the outside-tap closer ignores the wrapper, so a second tap closes the bubble.

## v0.1.0

First numbered build. The old "step" numbering is retired.

### Cleanup
- Removed all Grok Build scaffolding: `.grok/`, `AGENTS.md`, `public/__grok/`, the PWA middleware, the hosted sign-in and app-data layers, the database and migrations, the multiplayer helper, the preview-embedding helpers, `vercel.json`, and 26 helper scripts.
- Removed outside web fonts. The app now works fully offline.
- Dependencies cut from 450 packages to 287 (53 unused ones gone).
- Dev server now listens on this computer only (127.0.0.1). The default build target is a plain Node server, which is what the desktop app packages.
- Lint is clean. A `.gitignore` was added.
- The model no longer claims "I am not Grok/ChatGPT/Claude". If asked, it says it is whichever model you chose in Settings.

### New
- **Conductor** (`conductor.ts`): plain-code routing (build, change, explain, image, chat) and the whole build pipeline (run, fix, inspect, judge, add the rest) in one tested module. No AI decides the order of steps.
- **Live telemetry panel** in the chat: what Jellyfish is doing right now, every step with its time, and a count of model calls.
- **Approval levels** (Settings): "Important things only" or "Every step". Terminal commands always ask.
- **Plan mode** now only applies to things that build, and the tests after approval compare against your original request (before, they used the approval message by mistake).
- **Eval runner** (Settings): 30 fixed requests, quick (5) or full run, scored first try vs final, with a saved history and a downloadable report.
- Version label in Settings.

### Carried over from before v0.1
- Fix loop, big-file study, stress test, System log, Safe mode, snippets, tool protocol, internet tools, terminal tool, SVG pictures, checkpoints with screenshots, Ollama local brain panel, desktop shell (unrun).
