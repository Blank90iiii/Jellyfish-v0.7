const { contextBridge } = require("electron");

// The page gets a tiny, read-only fact about where it runs. No Node access.
contextBridge.exposeInMainWorld("jellyfishDesktop", { isDesktop: true });
