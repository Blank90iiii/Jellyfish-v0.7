// Builds the Jellyfish server (node-server preset) and copies it into desktop/app.
// Run from the project root:  npm run desktop:prepare
const { execSync } = require("node:child_process");
const { cpSync, existsSync, rmSync } = require("node:fs");
const path = require("node:path");

const root = path.join(__dirname, "..", "..");
const target = path.join(__dirname, "..", "app");

console.log("Building the server (node-server preset)...");
execSync("npm run build", { cwd: root, stdio: "inherit", env: { ...process.env, NITRO_PRESET: "node-server" } });

const built = path.join(root, ".output");
if (!existsSync(path.join(built, "server", "index.mjs"))) {
  console.error("Build did not produce .output/server/index.mjs");
  process.exit(1);
}
rmSync(target, { recursive: true, force: true });
cpSync(built, path.join(target, ".output"), { recursive: true });
console.log("Copied to desktop/app/.output");
console.log("Next:  cd desktop && npm install && npm start      (try it)");
console.log("   or:  cd desktop && npm install && npm run dist   (Windows installer, run this on Windows)");
