/**
 * Jellyfish desktop shell (Electron).
 * 1. Starts the built Jellyfish server on a free local port.
 * 2. Starts Ollama if it is installed but not running.
 * 3. Opens a window on the local server. Nothing is exposed to the network.
 *
 * Status: written but not yet run on Windows. See README.txt section 8.
 */
const { app, BrowserWindow, shell } = require("electron");
const { spawn } = require("node:child_process");
const http = require("node:http");
const net = require("node:net");
const path = require("node:path");

let serverProcess = null;
let win = null;

function freePort() {
  return new Promise((resolve, reject) => {
    const probe = net.createServer();
    probe.listen(0, "127.0.0.1", () => {
      const { port } = probe.address();
      probe.close(() => resolve(port));
    });
    probe.on("error", reject);
  });
}

function get(url) {
  return new Promise((resolve) => {
    const request = http.get(url, (response) => {
      response.resume();
      resolve(response.statusCode || 0);
    });
    request.on("error", () => resolve(0));
    request.setTimeout(1500, () => {
      request.destroy();
      resolve(0);
    });
  });
}

async function waitFor(url, tries = 60) {
  for (let i = 0; i < tries; i += 1) {
    if ((await get(url)) > 0) return true;
    await new Promise((resolve) => setTimeout(resolve, 500));
  }
  return false;
}

async function ensureOllama() {
  if ((await get("http://127.0.0.1:11434/api/tags")) > 0) return;
  try {
    const child = spawn("ollama", ["serve"], { detached: true, stdio: "ignore", windowsHide: true });
    child.on("error", () => {});
    child.unref();
  } catch {
    /* Ollama is not installed. The app's Local brain panel explains how to install it. */
  }
}

async function start() {
  const port = await freePort();
  const entry = path.join(__dirname, "app", ".output", "server", "index.mjs");
  serverProcess = spawn(process.execPath, [entry], {
    env: {
      ...process.env,
      ELECTRON_RUN_AS_NODE: "1",
      NODE_ENV: "production",
      HOST: "127.0.0.1",
      PORT: String(port),
      JELLYFISH_TERMINAL: "1",
      JELLYFISH_DATA: path.join(app.getPath("userData"), "data"),
    },
    stdio: "ignore",
    windowsHide: true,
  });
  serverProcess.on("exit", () => {
    serverProcess = null;
  });

  void ensureOllama();
  const url = `http://127.0.0.1:${port}/`;
  const ready = await waitFor(url);

  win = new BrowserWindow({
    width: 1280,
    height: 860,
    backgroundColor: "#000000",
    title: "Jellyfish",
    webPreferences: { preload: path.join(__dirname, "preload.cjs"), contextIsolation: true, nodeIntegration: false, sandbox: true },
  });
  win.setMenuBarVisibility(false);
  // Links to other sites open in the normal browser, never inside the app.
  win.webContents.setWindowOpenHandler(({ url: target }) => {
    if (/^https?:\/\//i.test(target)) void shell.openExternal(target);
    return { action: "deny" };
  });
  win.webContents.on("will-navigate", (event, target) => {
    if (!target.startsWith(`http://127.0.0.1:${port}`)) {
      event.preventDefault();
      if (/^https?:\/\//i.test(target)) void shell.openExternal(target);
    }
  });
  if (ready) await win.loadURL(url);
  else await win.loadURL("data:text/html,<body style='background:#000;color:#fff;font-family:sans-serif;padding:2rem'><h2>Jellyfish could not start its local server.</h2></body>");
}

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on("second-instance", () => {
    if (win) {
      if (win.isMinimized()) win.restore();
      win.focus();
    }
  });
  app.whenReady().then(start);
  app.on("window-all-closed", () => app.quit());
  app.on("before-quit", () => {
    if (serverProcess) serverProcess.kill();
  });
}
